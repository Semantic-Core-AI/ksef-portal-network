import { type NextRequest, NextResponse } from "next/server"
import { renderToStream } from "@react-pdf/renderer"
import { KSEFReportPDF } from "@/lib/pdf-generator"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { revenue, volume, results, companyName } = body

    const pdfDocument = KSEFReportPDF({ revenue, volume, results, companyName })
    const stream = await renderToStream(pdfDocument)

    return new NextResponse(stream as any, {
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `attachment; filename="raport-ksef-${Date.now()}.pdf"`,
      },
    })
  } catch (error) {
    console.error("PDF generation error:", error)
    return NextResponse.json({ error: "Failed to generate PDF" }, { status: 500 })
  }
}
