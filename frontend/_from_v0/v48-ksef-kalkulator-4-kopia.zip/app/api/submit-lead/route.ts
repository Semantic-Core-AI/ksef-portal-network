import { NextResponse } from "next/server"

interface LeadSubmission {
  firstName: string
  email: string
  company?: string
  revenue: number
  invoiceVolume: number
  totalLosses: number
  implementationCost: number
  savings: number
  consent: boolean
}

export async function POST(request: Request) {
  try {
    const data: LeadSubmission = await request.json()

    // Validate required fields
    if (!data.firstName || !data.email || !data.consent) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(data.email)) {
      return NextResponse.json({ error: "Invalid email format" }, { status: 400 })
    }

    // Log the lead submission (in production, save to database)
    console.log("[v0] Lead submitted:", {
      firstName: data.firstName,
      email: data.email,
      company: data.company,
      revenue: data.revenue,
      totalLosses: data.totalLosses,
      timestamp: new Date().toISOString(),
    })

    // TODO: In production, implement:
    // 1. Save to database (Supabase, Neon, etc.)
    // 2. Send to CRM (HubSpot, Salesforce, etc.)
    // 3. Send email with PDF report
    // 4. Add to email marketing list (Mailchimp, SendGrid, etc.)
    // 5. Track analytics event

    // Example database save (uncomment when database is set up):
    /*
    const { data: savedLead, error } = await supabase
      .from('leads')
      .insert([
        {
          first_name: data.firstName,
          email: data.email,
          company: data.company,
          revenue: data.revenue,
          invoice_volume: data.invoiceVolume,
          total_losses: data.totalLosses,
          implementation_cost: data.implementationCost,
          savings: data.savings,
          consent: data.consent,
          created_at: new Date().toISOString(),
        }
      ])
      .select()

    if (error) {
      console.error('Database error:', error)
      return NextResponse.json(
        { error: 'Failed to save lead' },
        { status: 500 }
      )
    }
    */

    // Example email sending (uncomment when email service is set up):
    /*
    await sendEmail({
      to: data.email,
      subject: 'Twój raport KSeF jest gotowy!',
      template: 'ksef-report',
      data: {
        firstName: data.firstName,
        totalLosses: data.totalLosses,
        savings: data.savings,
        pdfUrl: 'https://...',
      }
    })
    */

    // Return success response
    return NextResponse.json({
      success: true,
      message: "Lead submitted successfully",
      data: {
        firstName: data.firstName,
        email: data.email,
      },
    })
  } catch (error) {
    console.error("[v0] Error submitting lead:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
