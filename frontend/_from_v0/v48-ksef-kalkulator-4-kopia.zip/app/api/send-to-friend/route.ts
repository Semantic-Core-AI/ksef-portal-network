import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { senderName, recipientEmail, recipientName, message, calculatorUrl } = body

    // TODO: Integrate with email service (SendGrid, Resend, etc.)
    console.log("Send to friend:", { senderName, recipientEmail, recipientName, message, calculatorUrl })

    // Simulate email sending
    await new Promise((resolve) => setTimeout(resolve, 1000))

    return NextResponse.json({ success: true, message: "Email sent successfully" })
  } catch (error) {
    console.error("Send to friend error:", error)
    return NextResponse.json({ error: "Failed to send email" }, { status: 500 })
  }
}
