"use client"

#
🚀 ULTIMATE MEGA PROMPT V0: KALKULATOR KSEF 3.0 [PART 2/2]

## ⚠️ WAŻNE: TO JEST CZĘŚĆ 2 Z 2 PROMPTÓW

\`\`\`
PART 1 (POPRZEDNI PROMPT) ZAWIERAŁ:
✅ Kompletny Design System 
✅ Intro Screen
✅ Faza 1: Twoja Firma (2 pytania)
✅ Faza 2: Scenariusz Katastrofy

TEN PROMPT (PART 2) ZAWIERA:
✅ Faza 3: Rozwiązanie (ROI comparison + reveal)
✅ Results Page (final summary)
✅ Multiple CTAs (konsultacja, PDF, webinar)
✅ Email capture form
✅ Social proof & testimonials
✅ Final integration instructions

INSTRUKCJE DLA v0:
1. Kontynuuj od miejsca gdzie skończył się PART 1
2. Dodaj Fazę 3 po Fazie 2 (disaster scenario)
3. Użyj TEGO SAMEGO Design System z PART 1
4. Połącz wszystko w płynny flow
5. Dodaj state management (useState, useContext)
\`\`\`

---

# FAZA 3: ROZWIĄZANIE - THE RELIEF & ROI REVEAL
═══════════════════════════════════════════════════════════════════════════════

## 💡 KONCEPCJA FAZY 3:

Po pokazaniu STRACHU (156k strat), teraz pokazujemy ULGĘ i NADZIEJĘ:
- Koszt wdrożenia to TYLKO 12k
- Oszczędzasz 144k = ROI 1,200%
- Visual comparison (straty vs inwestycja)
- What's included w pakiecie
- Multiple CTAs
do konwersji

---

#
#
🎯 FAZA 3: COMPLETE CODE

\`\`\`tsx
import { motion } from "framer-motion"
\
import { ArrowRight, CheckCircle2, Phone, Calendar, Download } from "lucide-react"
import CountUp from
\'react-countup\';

function Phase3Solution({ revenue, volume, losses, onFinish }) {
  // Calculate implementation cost
  const implementation = calculateImplementationCost(revenue, volume)
  \
  // Calculate savings & ROI
  const savings = losses.totalLoss - implementation.total
  const roi = Math.round((savings / implementation.total) * 100)
  const paybackMonths = Math.round((implementation.total / losses.totalLoss) * 12)

  return (
    <div className="min-h-screen hero-gradient relative overflow-hidden">
      {/* Background texture */}
      <div
        className="absolute inset-0 opacity-30 pointer-events-none"
        style={{
          backgroundImage: `repeating-linear-gradient(
            45deg,
            rgba(255, 255, 255, 0.03) 0px,
            rgba(255, 255, 255, 0.03) 10px,
            transparent 10px,
            transparent 20px
          )`,
        }}
      />

      <div className="relative z-10">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          {/* Progress */}
          <div className="mb-12">
            <div className="flex justify-between items-center mb-3">
              <span className="text-sm font-semibold text-green-600">KROK 3/3</span>
              <span className="text-sm text-gray-600">Twoje rozwiązanie</span>
            </div>
            <div className="h-3 bg-gray-200 rounded-full overflow-hidden">
              <motion.div
                initial={{ width: "66%" }}
                animate={{ width: "100%" }}
                transition={{ duration: 0.7, ease: "easeOut" }}
                className="h-full bg-gradient-to-r from-green-500 to-green-600 relative"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent animate-shimmer" />
              </motion.div>
            </div>
          </div>

          {/* ═══ RELIEF HEADER ═══ */}
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ type: "spring", duration: 0.6 }}
            className="bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-3xl p-12 mb-8 shadow-success-glow text-center relative overflow-hidden"
          >
            {/* Shimmer effect */}
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent animate-shimmer" />

            <div className="relative z-10">
              <div className="text-7xl mb-6">✅</div>

              <h2 className="font-display text-5xl font-black mb-6">MAMY ROZWIĄZANIE!</h2>

              <p className="text-2xl opacity-90 mb-8">Profesjonalne wdrożenie KSeF to inwestycja która zwraca się w:</p>

              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", delay: 0.3 }}
                className="bg-white/20 backdrop-blur rounded-2xl p-8 inline-block"
              >
                <div className="font-mono text-7xl font-black">
                  <CountUp end={paybackMonths} duration={2} suffix=" MIESIĄCE" />
                </div>
                <div className="text-lg mt-2 opacity-90">(często krócej!)</div>
              </motion.div>
            </div>
          </motion.div>

          {/* ═══ THE BIG COMPARISON ═══ */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="mb-8"
          >
            <div className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-3xl p-8 border-2 border-blue-200 shadow-card-xl">
              <h3 className="font-display text-3xl font-bold text-center mb-8 text-gray-900">
                💰 Porównanie: Działać vs Nie Działać
              </h3>

              <div className="grid md:grid-cols-2 gap-8 mb-8">
                {/* ═══ OPTION A: DOING NOTHING ═══ */}
                <div className="bg-white rounded-2xl p-8 border-4 border-red-500 relative overflow-hidden shadow-danger-glow">
                  {/* Badge */}
                  <div className="absolute top-0 right-0 bg-red-600 text-white px-6 py-2 text-sm font-bold rounded-bl-xl">
                    ❌ NIE WDRAŻAM
                  </div>

                  <div className="mt-8 mb-6">
                    <div className="text-5xl mb-4 text-center">😱</div>
                    <h4 className="text-2xl font-bold text-center mb-4">Scenariusz katastrofy</h4>
                  </div>

                  <div className="space-y-4 mb-6">
                    <div className="flex items-center gap-3">
                      <div className="w-6 h-6 rounded-full bg-red-100 flex items-center justify-center flex-shrink-0">
                        <span className="text-red-600 font-bold text-sm">✕</span>
                      </div>
                      <span className="text-gray-700 text-sm">Kary i sankcje</span>
                      <span className="ml-auto font-bold text-red-600 text-sm">
                        {losses.fines.toLocaleString()} PLN
                      </span>
                    </div>

                    <div className="flex items-center gap-3">
                      <div className="w-6 h-6 rounded-full bg-red-100 flex items-center justify-center flex-shrink-0">
                        <span className="text-red-600 font-bold text-sm">✕</span>
                      </div>
                      <span className="text-gray-700 text-sm">Stracony czas</span>
                      <span className="ml-auto font-bold text-red-600 text-sm">
                        {losses.timeWasted.toLocaleString()} PLN
                      </span>
                    </div>

                    <div className="flex items-center gap-3">
                      <div className="w-6 h-6 rounded-full bg-red-100 flex items-center justify-center flex-shrink-0">
                        <span className="text-red-600 font-bold text-sm">✕</span>
                      </div>
                      <span className="text-gray-700 text-sm">Wolniejszy VAT</span>
                      <span className="ml-auto font-bold text-red-600 text-sm">
                        {losses.vatDelay.toLocaleString()} PLN
                      </span>
                    </div>

                    <div className="flex items-center gap-3">
                      <div className="w-6 h-6 rounded-full bg-red-100 flex items-center justify-center flex-shrink-0">
                        <span className="text-red-600 font-bold text-sm">✕</span>
                      </div>
                      <span className="text-gray-700 text-sm">Utracone szanse</span>
                      <span className="ml-auto font-bold text-red-600 text-sm">
                        {losses.opportunity.toLocaleString()} PLN
                      </span>
                    </div>
                  </div>

                  <div className="border-t-2 border-red-300 pt-4">
                    <div className="flex justify-between items-center mb-4">
                      <span className="text-lg font-semibold">RAZEM STRAT:</span>
                      <div className="text-right">
                        <div className="text-4xl font-black text-red-600">{losses.totalLoss.toLocaleString()}</div>
                        <div className="text-sm text-red-600">PLN / rok</div>
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 p-4 bg-red-50 rounded-xl text-center">
                    <p className="text-sm text-red-700 font-semibold">
                      💀 To {Math.round((losses.totalLoss / revenue.value) * 100)}% Twoich rocznych przychodów!
                    </p>
                  </div>
                </div>

                {/* ═══ OPTION B: IMPLEMENTING KSEF ═══ */}
                <div className="bg-white rounded-2xl p-8 border-4 border-green-500 relative overflow-hidden shadow-success-glow">
                  {/* Badge */}
                  <div className="absolute top-0 right-0 bg-green-600 text-white px-6 py-2 text-sm font-bold rounded-bl-xl">
                    ✅ WDRAŻAM TERAZ
                  </div>

                  <div className="mt-8 mb-6">
                    <div className="text-5xl mb-4 text-center">🚀</div>
                    <h4 className="text-2xl font-bold text-center mb-4">Profesjonalne wdrożenie</h4>
                  </div>

                  <div className="space-y-4 mb-6">
                    <div className="flex items-center gap-3">
                      <CheckCircle2 className="w-6 h-6 text-green-600 flex-shrink-0" />
                      <span className="text-gray-700 text-sm">Wdrożenie techniczne</span>
                      <span className="ml-auto font-bold text-gray-900 text-sm">
                        {implementation.technical.toLocaleString()} PLN
                      </span>
                    </div>

                    <div className="flex items-center gap-3">
                      <CheckCircle2 className="w-6 h-6 text-green-600 flex-shrink-0" />
                      <span className="text-gray-700 text-sm">Szkolenia zespołu</span>
                      <span className="ml-auto font-bold text-gray-900 text-sm">
                        {implementation.training.toLocaleString()} PLN
                      </span>
                    </div>

                    <div className="flex items-center gap-3">
                      <CheckCircle2 className="w-6 h-6 text-green-600 flex-shrink-0" />
                      <span className="text-gray-700 text-sm">Konsultacje</span>
                      <span className="ml-auto font-bold text-gray-900 text-sm">
                        {implementation.consulting.toLocaleString()} PLN
                      </span>
                    </div>

                    <div className="flex items-center gap-3">
                      <CheckCircle2 className="w-6 h-6 text-green-600 flex-shrink-0" />
                      <span className="text-gray-700 text-sm">90 dni wsparcia</span>
                      <span className="ml-auto font-bold text-gray-900 text-sm">
                        {implementation.support.toLocaleString()} PLN
                      </span>
                    </div>
                  </div>

                  <div className="border-t-2 border-green-300 pt-4">
                    <div className="flex justify-between items-center mb-4">
                      <span className="text-lg font-semibold">INWESTYCJA:</span>
                      <div className="text-right">
                        <div className="text-4xl font-black text-green-600">
                          {implementation.total.toLocaleString()}
                        </div>
                        <div className="text-sm text-green-600">PLN (jednorazowo)</div>
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 p-4 bg-green-50 rounded-xl text-center">
                    <p className="text-sm text-green-700 font-semibold">
                      ✨ To tylko {Math.round((implementation.total / losses.totalLoss) * 100)}% potencjalnych strat!
                    </p>
                  </div>
                </div>
              </div>

              {/* ═══ VISUAL COMPARISON BAR ═══ */}
              <div className="relative h-32 bg-gray-100 rounded-2xl overflow-hidden mb-6">
                <div className="absolute inset-0 flex">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${(implementation.total / (implementation.total + losses.totalLoss)) * 100}%` }}
                    transition={{ duration: 1, delay: 1 }}
                    className="bg-gradient-to-r from-green-500 to-green-600 flex items-center justify-center text-white font-bold text-sm md:text-base px-4"
                  >
                    <div className="text-center">
                      <div>INWESTYCJA</div>
                      <div className="text-xs md:text-sm">{implementation.total.toLocaleString()} PLN</div>
                    </div>
                  </motion.div>

                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${(losses.totalLoss / (implementation.total + losses.totalLoss)) * 100}%` }}
                    transition={{ duration: 1, delay: 1.3 }}
                    className="bg-gradient-to-r from-red-500 to-red-600 flex items-center justify-center text-white font-bold text-sm md:text-base px-4"
                  >
                    <div className="text-center">
                      <div>STRATY BEZ WDROŻENIA</div>
                      <div className="text-xs md:text-sm">{losses.totalLoss.toLocaleString()} PLN</div>
                    </div>
                  </motion.div>
                </div>
              </div>

              {/* ═══ THE KICKER ═══ */}
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ delay: 2.5 }}
                className="bg-gradient-to-r from-ksef-gold-500/20 to-yellow-100 border-2 border-ksef-gold-500 rounded-2xl p-8 text-center"
              >
                <div className="text-5xl mb-4">💡</div>
                <h4 className="font-display text-3xl font-black mb-4 text-ksef-navy-800">
                  Oszczędzasz{" "}
                  <span className="text-green-600">
                    <CountUp end={savings} duration={2} separator=" " suffix=" PLN" />
                  </span>
                </h4>
                <p className="text-xl text-gray-700 mb-2">
                  Czyli <strong>{Math.round(savings / implementation.total)}x</strong> więcej niż wydajesz!
                </p>
                <p className="text-lg text-gray-600">
                  ROI: <strong className="text-green-600">+{roi}%</strong>
                </p>
              </motion.div>
            </div>
          </motion.div>

          {/* ═══ ROI BREAKDOWN ═══ */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 3 }}
            className="mb-8"
          >
            <div className="bg-white rounded-3xl p-8 border-2 border-gray-200 shadow-card-xl">
              <h3 className="font-display text-2xl font-bold mb-6 text-center">📊 Zwrot z inwestycji (ROI)</h3>

              <div className="grid md:grid-cols-3 gap-6 mb-8">
                <div className="text-center p-6 bg-blue-50 rounded-xl">
                  <div className="text-sm text-blue-600 font-semibold mb-2">INWESTYCJA</div>
                  <div className="text-4xl font-black text-blue-700">{implementation.total.toLocaleString()}</div>
                  <div className="text-sm text-blue-600 mt-1">PLN</div>
                </div>

                <div className="text-center p-6 bg-green-50 rounded-xl">
                  <div className="text-sm text-green-600 font-semibold mb-2">OSZCZĘDNOŚCI (ROK 1)</div>
                  <div className="text-4xl font-black text-green-700">{losses.totalLoss.toLocaleString()}</div>
                  <div className="text-sm text-green-600 mt-1">PLN</div>
                </div>

                <div className="text-center p-6 bg-gradient-to-br from-ksef-gold-500/10 to-yellow-100 rounded-xl border-2 border-ksef-gold-500">
                  <div className="text-sm text-ksef-gold-600 font-semibold mb-2">ROI</div>
                  <div className="text-4xl font-black text-ksef-navy-800">+{roi}%</div>
                  <div className="text-sm text-gray-600 mt-1">zwrotu</div>
                </div>
              </div>

              {/* Timeline ROI */}
              <div className="bg-gradient-to-r from-gray-50 to-blue-50 rounded-xl p-6">
                <h4 className="font-bold mb-4 text-center">Ile zarobisz w czasie:</h4>
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div>
                    <div className="text-sm text-gray-600 mb-1">6 miesięcy</div>
                    <div className="text-2xl font-bold text-green-600">
                      +{Math.round(losses.totalLoss / 2 - implementation.total).toLocaleString()}
                    </div>
                    <div className="text-xs text-gray-500">PLN</div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-600 mb-1">1 rok</div>
                    <div className="text-2xl font-bold text-green-600">+{savings.toLocaleString()}</div>
                    <div className="text-xs text-gray-500">PLN</div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-600 mb-1">3 lata</div>
                    <div className="text-2xl font-bold text-green-600">
                      +{(losses.totalLoss * 3 - implementation.total).toLocaleString()}
                    </div>
                    <div className="text-xs text-gray-500">PLN</div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* ═══ WHAT'S INCLUDED ═══ */}
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 3.5 }} className="mb-12">
            <div className="bg-white rounded-3xl p-8 border-2 border-gray-200 shadow-card-lg">
              <h3 className="font-display text-2xl font-bold mb-6 text-center">
                ✅ Co zawiera wdrożenie za {implementation.total.toLocaleString()} PLN?
              </h3>

              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0" />
                    <span className="text-gray-700">Pełna integracja z Twoim systemem księgowym</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0" />
                    <span className="text-gray-700">Testy w środowisku demo MF</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0" />
                    <span className="text-gray-700">Konfiguracja procesów i procedur</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0" />
                    <span className="text-gray-700">Szkolenia dla całego zespołu</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0" />
                    <span className="text-gray-700">Dokumentacja i instrukcje</span>
                  </div>
                </div>
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0" />
                    <span className="text-gray-700">90 dni wsparcia technicznego</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0" />
                    <span className="text-gray-700">Hotline priorytetowy</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0" />
                    <span className="text-gray-700">Audyt pierwszych 100 faktur</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0" />
                    <span className="text-gray-700">Setup RODO i compliance</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0" />
                    <span className="text-gray-700">5 sesji konsultacyjnych</span>
                  </div>
                </div>
              </div>

              <div className="mt-8 pt-6 border-t-2 border-gray-200">
                <div className="grid md:grid-cols-3 gap-6 text-center">
                  <div>
                    <div className="text-4xl mb-2">⚡</div>
                    <div className="font-semibold text-gray-700 mb-1">Czas wdrożenia</div>
                    <div className="text-3xl font-bold text-ksef-navy-800">6-8 tyg</div>
                  </div>
                  <div>
                    <div className="text-4xl mb-2">🎯</div>
                    <div className="font-semibold text-gray-700 mb-1">Sukces wdrożenia</div>
                    <div className="text-3xl font-bold text-green-600">98%</div>
                  </div>
                  <div>
                    <div className="text-4xl mb-2">⭐</div>
                    <div className="font-semibold text-gray-700 mb-1">Ocena klientów</div>
                    <div className="text-3xl font-bold text-yellow-500">4.9/5</div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* ═══ MEGA CTA SECTION ═══ */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 4 }}
          >
            <div className="bg-gradient-to-br from-ksef-navy-800 to-blue-900 text-white rounded-3xl p-12 shadow-card-2xl">
              <div className="text-center mb-8">
                <h3 className="font-display text-4xl font-black mb-4">Gotowy na wdrożenie?</h3>
                <p className="text-xl opacity-90">
                  Uratuj swoją firmę przed stratami {losses.totalLoss.toLocaleString()} PLN
                </p>
              </div>

              {/* Primary CTA */}
              <div className="max-w-2xl mx-auto mb-8">
                <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-8 mb-6 border border-white/20">
                  <div className="text-center mb-6">
                    <div className="text-4xl mb-3">📞</div>
                    <h4 className="text-2xl font-bold mb-2">Bezpłatna konsultacja (30 min)</h4>
                    <p className="opacity-90">Omówimy Twoją sytuację i przygotujemy szczegółową ofertę</p>
                  </div>

                  <ul className="space-y-3 mb-6 text-left max-w-md mx-auto">
                    <li className="flex items-center gap-3">
                      <CheckCircle2 className="w-5 h-5 flex-shrink-0" />
                      <span>Analiza Twojego systemu księgowego</span>
                    </li>
                    <li className="flex items-center gap-3">
                      <CheckCircle2 className="w-5 h-5 flex-shrink-0" />
                      <span>Plan wdrożenia dopasowany do Ciebie</span>
                    </li>
                    <li className="flex items-center gap-3">
                      <CheckCircle2 className="w-5 h-5 flex-shrink-0" />
                      <span>Odpowiedzi na wszystkie pytania</span>
                    </li>
                    <li className="flex items-center gap-3">
                      <CheckCircle2 className="w-5 h-5 flex-shrink-0" />
                      <span>Dokładna wycena (nie szacunek)</span>
                    </li>
                  </ul>

                  <div className="bg-ksef-gold-500/20 border border-ksef-gold-500 rounded-lg p-4 mb-6 text-center">
                    <span className="font-bold text-ksef-gold-400">🎁 BONUS: Audit 20 Twoich faktur gratis</span>
                  </div>

                  <button
                    onClick={onFinish}
                    className="w-full group relative inline-flex items-center justify-center px-12 py-6 text-xl font-bold text-ksef-navy-900 bg-gradient-to-r from-ksef-gold-500 via-ksef-gold-400 to-ksef-gold-500 bg-size-200 rounded-xl shadow-gold-glow transition-all duration-300 hover:scale-105 active:scale-95"
                  >
                    <div className="absolute inset-0 rounded-xl bg-gradient-to-r from-transparent via-white/30 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />

                    <span className="relative z-10 flex items-center gap-3">
                      Umów konsultację TERAZ 📅
                      <ArrowRight className="w-6 h-6" />
                    </span>
                  </button>
                </div>

                <p className="text-center text-sm opacity-75">
                  ⚡ Oddzwaniamy w ciągu 2h (pn-pt 9-19) • 🔒 Bez zobowiązań
                </p>
              </div>

              {/* Alternative CTAs */}
              <div className="grid md:grid-cols-3 gap-4">
                <button className="flex items-center justify-center gap-2 px-6 py-4 bg-white/10 border border-white/30 rounded-xl text-white hover:bg-white/20 transition-all">
                  <Download className="w-5 h-5" />
                  <span>Wyślij mi PDF</span>
                </button>

                <button className="flex items-center justify-center gap-2 px-6 py-4 bg-white/10 border border-white/30 rounded-xl text-white hover:bg-white/20 transition-all">
                  <Calendar className="w-5 h-5" />
                  <span>Darmowy webinar</span>
                </button>

                <button className="flex items-center justify-center gap-2 px-6 py-4 bg-white/10 border border-white/30 rounded-xl text-white hover:bg-white/20 transition-all">
                  <Phone className="w-5 h-5" />
                  <span>Zadzwoń teraz</span>
                </button>
              </div>
            </div>
          </motion.div>

          {/* Urgency footer */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 4.5 }}
            className="mt-8 text-center"
          >
            <div className="inline-block bg-red-50 border-2 border-red-300 rounded-xl px-8 py-4">
              <p className="text-red-700 font-semibold">
                ⏰ Każdy dzień opóźnienia = <strong>{losses.dailyLoss.toLocaleString()} PLN strat</strong>
              </p>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  )
}
\`\`\`

---

# RESULTS PAGE - FINAL SUMMARY + EMAIL CAPTURE
═══════════════════════════════════════════════════════════════════════════════

\`\`\`tsx
import { useState } from "react"
import { motion } from "framer-motion"
import { CheckCircle2, Mail, Linkedin, Facebook, Twitter, Link2, Gift } from "lucide-react"

function ResultsPage({ revenue, volume, losses, implementation }) {
  const [email, setEmail] = useState("")
  const [firstName, setFirstName] = useState("")
  const [company, setCompany] = useState("")
  const [isSubmitted, setIsSubmitted] = useState(false)

  const savings = losses.totalLoss - implementation.total
  const roi = Math.round((savings / implementation.total) * 100)

  const handleSubmit = async (e) => {
    e.preventDefault()
    // Handle email submission
    console.log({ email, firstName, company })
    setIsSubmitted(true)
  }

  return (
    <div className="min-h-screen hero-gradient relative overflow-hidden">
      {/* Background */}
      <div
        className="absolute inset-0 opacity-30 pointer-events-none"
        style={{
          backgroundImage: `repeating-linear-gradient(
            45deg,
            rgba(255, 255, 255, 0.03) 0px,
            rgba(255, 255, 255, 0.03) 10px,
            transparent 10px,
            transparent 20px
          )`,
        }}
      />

      <div className="relative z-10">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          {/* ═══ SUMMARY HEADER ═══ */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-12">
            <div className="inline-flex items-center gap-2 px-6 py-3 bg-green-100 border-2 border-green-300 rounded-full text-green-700 font-bold mb-6">
              <CheckCircle2 className="w-5 h-5" />
              Kalkulacja ukończona!
            </div>

            <h1 className="font-display text-5xl font-black text-gray-900 mb-6">Twoje Podsumowanie</h1>

            <p className="text-xl text-gray-700">Zobacz pełny raport i pobierz PDF z planem działania</p>
          </motion.div>

          {/* ═══ QUICK STATS ═══ */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="grid md:grid-cols-3 gap-6 mb-12"
          >
            <div className="bg-white rounded-2xl p-6 border-2 border-red-200 text-center shadow-card-lg">
              <div className="text-sm text-red-600 font-semibold mb-2">POTENCJALNE STRATY</div>
              <div className="text-4xl font-black text-red-600 mb-1">{losses.totalLoss.toLocaleString()}</div>
              <div className="text-sm text-gray-600">PLN / rok</div>
            </div>

            <div className="bg-white rounded-2xl p-6 border-2 border-blue-200 text-center shadow-card-lg">
              <div className="text-sm text-blue-600 font-semibold mb-2">KOSZT WDROŻENIA</div>
              <div className="text-4xl font-black text-blue-600 mb-1">{implementation.total.toLocaleString()}</div>
              <div className="text-sm text-gray-600">PLN (jednorazowo)</div>
            </div>

            <div className="bg-gradient-to-br from-ksef-gold-500/10 to-yellow-100 rounded-2xl p-6 border-2 border-ksef-gold-500 text-center shadow-gold-glow">
              <div className="text-sm text-ksef-gold-600 font-semibold mb-2">TWOJE OSZCZĘDNOŚCI</div>
              <div className="text-4xl font-black text-green-600 mb-1">{savings.toLocaleString()}</div>
              <div className="text-sm text-gray-600">PLN / rok</div>
            </div>
          </motion.div>

          {/* ═══ EMAIL CAPTURE - LEAD MAGNET ═══ */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.4 }}
            className="mb-12"
          >
            <div className="bg-gradient-to-br from-ksef-navy-800 to-blue-900 text-white rounded-3xl p-12 shadow-card-2xl">
              {!isSubmitted ? (
                <>
                  <div className="text-center mb-8">
                    <div className="text-6xl mb-4">📄</div>
                    <h3 className="font-display text-3xl font-bold mb-4">Pobierz pełny raport PDF</h3>
                    <p className="text-xl opacity-90">45-stronicowy raport spersonalizowany dla Twojej firmy</p>
                  </div>

                  {/* What's included */}
                  <div className="grid md:grid-cols-2 gap-6 mb-8">
                    <div className="bg-white/10 backdrop-blur rounded-xl p-6 border border-white/20">
                      <h4 className="font-bold mb-3 flex items-center gap-2">
                        <CheckCircle2 className="w-5 h-5" />
                        Co zawiera raport:
                      </h4>
                      <ul className="space-y-2 text-sm">
                        <li>✓ Szczegółowa analiza gotowości</li>
                        <li>✓ Plan wdrożenia krok po kroku</li>
                        <li>✓ Checklista 127 punktów</li>
                        <li>✓ Case studies firm jak Twoja</li>
                        <li>✓ Szacunek kosztów i ROI</li>
                        <li>✓ Szablony dokumentów</li>
                      </ul>
                    </div>

                    <div className="bg-white/10 backdrop-blur rounded-xl p-6 border border-white/20">
                      <h4 className="font-bold mb-3 flex items-center gap-2">
                        <Gift className="w-5 h-5" />
                        BONUSY:
                      </h4>
                      <ul className="space-y-2 text-sm">
                        <li>🎁 Webinar "KSeF Masterclass"</li>
                        <li>🎁 Dostęp do community</li>
                        <li>🎁 Newsletter z poradami</li>
                        <li>🎁 30 min konsultacji gratis</li>
                      </ul>
                    </div>
                  </div>

                  {/* Email form */}
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                      <input
                        type="text"
                        placeholder="Imię"
                        value={firstName}
                        onChange={(e) => setFirstName(e.target.value)}
                        required
                        className="px-6 py-4 rounded-xl bg-white/90 text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-ksef-gold-500"
                      />
                      <input
                        type="email"
                        placeholder="Email służbowy"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                        className="px-6 py-4 rounded-xl bg-white/90 text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-ksef-gold-500"
                      />
                    </div>

                    <input
                      type="text"
                      placeholder="Nazwa firmy (opcjonalnie)"
                      value={company}
                      onChange={(e) => setCompany(e.target.value)}
                      className="w-full px-6 py-4 rounded-xl bg-white/90 text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-ksef-gold-500"
                    />

                    <div className="flex items-start gap-3">
                      <input type="checkbox" id="consent" required className="mt-1 w-5 h-5 rounded" />
                      <label htmlFor="consent" className="text-sm opacity-90">
                        Zgadzam się na otrzymanie raportu PDF oraz newsletter z poradami KSeF (możesz się wypisać w
                        każdej chwili)
                      </label>
                    </div>

                    <button
                      type="submit"
                      className="w-full group relative inline-flex items-center justify-center px-12 py-6 text-xl font-bold text-ksef-navy-900 bg-gradient-to-r from-ksef-gold-500 via-ksef-gold-400 to-ksef-gold-500 bg-size-200 rounded-xl shadow-gold-glow transition-all duration-300 hover:scale-105 active:scale-95"
                    >
                      <div className="absolute inset-0 rounded-xl bg-gradient-to-r from-transparent via-white/30 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />

                      <span className="relative z-10 flex items-center gap-3">
                        <Mail className="w-6 h-6" />
                        Wyślij mi raport PDF (DARMOWY)
                      </span>
                    </button>
                  </form>

                  <p className="text-center text-sm opacity-75 mt-4">🔒 Twoje dane są bezpieczne. RODO compliant.</p>
                </>
              ) : (
                <div className="text-center py-12">
                  <div className="text-6xl mb-6">🎉</div>
                  <h3 className="text-3xl font-bold mb-4">Dziękujemy!</h3>
                  <p className="text-xl mb-6">
                    Raport PDF został wysłany na: <strong>{email}</strong>
                  </p>
                  <p className="opacity-90">Sprawdź swoją skrzynkę (również spam) 📧</p>
                </div>
              )}
            </div>
          </motion.div>

          {/* ═══ MULTI-CTA PANEL ═══ */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="grid md:grid-cols-3 gap-6 mb-12"
          >
            <div className="bg-white rounded-2xl p-6 border-2 border-gray-200 shadow-card hover:shadow-card-xl transition-shadow cursor-pointer">
              <div className="text-4xl mb-4">📞</div>
              <h4 className="font-bold text-lg mb-2">Bezpłatna konsultacja</h4>
              <p className="text-sm text-gray-600 mb-4">30 min z ekspertem - omówimy Twoją sytuację</p>
              <button className="w-full px-4 py-3 border-2 border-ksef-navy-800 text-ksef-navy-800 rounded-xl font-semibold hover:bg-ksef-navy-800 hover:text-white transition-all">
                Umów się →
              </button>
            </div>

            <div className="bg-white rounded-2xl p-6 border-2 border-gray-200 shadow-card hover:shadow-card-xl transition-shadow cursor-pointer">
              <div className="text-4xl mb-4">🎓</div>
              <h4 className="font-bold text-lg mb-2">Webinar KSeF</h4>
              <p className="text-sm text-gray-600 mb-4">Live Q&A z ekspertami - najbliższy w czwartek</p>
              <button className="w-full px-4 py-3 border-2 border-ksef-navy-800 text-ksef-navy-800 rounded-xl font-semibold hover:bg-ksef-navy-800 hover:text-white transition-all">
                Zapisz się →
              </button>
            </div>

            <div className="bg-white rounded-2xl p-6 border-2 border-gray-200 shadow-card hover:shadow-card-xl transition-shadow cursor-pointer">
              <div className="text-4xl mb-4">💰</div>
              <h4 className="font-bold text-lg mb-2">Kalkulator kosztów</h4>
              <p className="text-sm text-gray-600 mb-4">Ile będzie kosztować wdrożenie w Twojej firmie?</p>
              <button className="w-full px-4 py-3 border-2 border-ksef-navy-800 text-ksef-navy-800 rounded-xl font-semibold hover:bg-ksef-navy-800 hover:text-white transition-all">
                Oblicz →
              </button>
            </div>
          </motion.div>

          {/* ═══ SOCIAL SHARE ═══ */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8 }}
            className="text-center"
          >
            <p className="text-gray-600 mb-4">Podziel się tym kalkulatorem z innymi firmami:</p>
            <div className="flex justify-center gap-4">
              <button className="p-3 bg-[#0A66C2] text-white rounded-xl hover:scale-110 transition-transform">
                <Linkedin className="w-5 h-5" />
              </button>
              <button className="p-3 bg-[#1877F2] text-white rounded-xl hover:scale-110 transition-transform">
                <Facebook className="w-5 h-5" />
              </button>
              <button className="p-3 bg-[#1DA1F2] text-white rounded-xl hover:scale-110 transition-transform">
                <Twitter className="w-5 h-5" />
              </button>
              <button className="p-3 bg-gray-700 text-white rounded-xl hover:scale-110 transition-transform">
                <Link2 className="w-5 h-5" />
              </button>
            </div>
          </motion.div>

          {/* Footer - Retake */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.0 }}
            className="text-center mt-12"
          >
            <button
              onClick={() => window.location.reload()}
              className="text-gray-500 hover:text-gray-700 text-sm font-medium"
            >
              🔄 Zrób kalkulację ponownie
            </button>
          </motion.div>
        </div>
      </div>
    </div>
  )
}
\`\`\`

---

# FINAL INTEGRATION - STATE MANAGEMENT
═══════════════════════════════════════════════════════════════════════════════

\`\`\`tsx
import { useState } from "react"
import IntroScreen from "./components/IntroScreen"
import Question1Revenue from "./components/Question1Revenue"
import Question2InvoiceVolume from "./components/Question2InvoiceVolume"
import Phase2Disaster from "./components/Phase2Disaster"
import Phase3Solution from "./components/Phase3Solution"
import ResultsPage from "./components/ResultsPage"

export default function Calculator() {
  const [currentStep, setCurrentStep] = useState("intro") // intro, q1, q2, disaster, solution, results
  const [selectedRevenue, setSelectedRevenue] = useState(null)
  const [selectedVolume, setSelectedVolume] = useState(null)
  const [losses, setLosses] = useState(null)
  const [implementation, setImplementation] = useState(null)

  const handleStartCalculator = () => {
    setCurrentStep("q1")
  }

  const handleQ1Next = () => {
    setCurrentStep("q2")
  }

  const handleCalculate = () => {
    // Calculate losses
    const calculatedLosses = calculateLosses(selectedRevenue, selectedVolume)
    setLosses(calculatedLosses)

    // Calculate implementation cost
    const calculatedImplementation = calculateImplementationCost(selectedRevenue, selectedVolume)
    setImplementation(calculatedImplementation)

    // Move to disaster phase
    setCurrentStep("disaster")
  }

  const handleDisasterNext = () => {
    setCurrentStep("solution")
  }

  const handleSolutionFinish = () => {
    setCurrentStep("results")
  }

  return (
    <>
      {currentStep === "intro" && <IntroScreen onStart={handleStartCalculator} />}

      {currentStep === "q1" && (
        <Question1Revenue
          selectedRevenue={selectedRevenue}
          setSelectedRevenue={setSelectedRevenue}
          onNext={handleQ1Next}
        />
      )}

      {currentStep === "q2" && (
        <Question2InvoiceVolume
          selectedVolume={selectedVolume}
          setSelectedVolume={setSelectedVolume}
          onCalculate={handleCalculate}
        />
      )}

      {currentStep === "disaster" && (
        <Phase2Disaster revenue={selectedRevenue} volume={selectedVolume} losses={losses} onNext={handleDisasterNext} />
      )}

      {currentStep === "solution" && (
        <Phase3Solution
          revenue={selectedRevenue}
          volume={selectedVolume}
          losses={losses}
          implementation={implementation}
          onFinish={handleSolutionFinish}
        />
      )}

      {currentStep === "results" && (
        <ResultsPage
          revenue={selectedRevenue}
          volume={selectedVolume}
          losses={losses}
          implementation={implementation}
        />
      )}
    </>
  )
}
\`\`\`

---

# ✅ INSTRUKCJE DLA v0 - JAK POŁĄCZYĆ PART 1 + PART 2
═══════════════════════════════════════════════════════════════════════════════

## KROK 1: Wklej PART 1
do v0

\`\`\`
1. Otwórz v0.dev
2. Wklej cały PART 1
3. Kliknij "Generate"
4. v0 wygeneruje:
   - Design System (colors, gradients, animations)
   - IntroScreen component
   - Question1Revenue component  
   - Question2InvoiceVolume component
   - Phase2Disaster component
   - Calculation functions
\`\`\`

## KROK 2: Wklej PART 2 do v0

\`\`\`
1. W TYM SAMYM projekcie v0
2. Kliknij "Continue" lub "Add component"
3. Wklej cały PART 2
4. v0 doda:
   - Phase3Solution component
   - ResultsPage component
   - Final integration (Calculator.tsx)
   - State management
\`\`\`

## KROK 3: v0 automatycznie połączy

\`\`\`
v0 inteligentnie:
✅ Użyje Design System z PART 1
✅ Doda brakujące komponenty z PART 2
✅ Połączy flow (intro → q1 → q2 → disaster → solution → results)
✅ Doda state management
✅ Wygeneruje working app
\`\`\`

---

## ⚠️ JEŚLI COKOLWIEK PÓJDZIE ŹLE:

\`\`\`
Możesz powiedzieć v0:
"Use the design system from previous prompt (PART 1) 
and add Phase3Solution + ResultsPage components from this prompt (PART 2).
Connect all components in a single flow with state management."

v0 zrozumie i naprawnie połączy.
\`\`\`

---

# 🎯 COMPLETE! PART 2/2 GOTOWE!

To są WSZYSTKIE brakujące sekcje:
✅ Faza 3: Rozwiązanie (ROI comparison)
✅ Results Page (summary + email capture)
✅ Multiple CTAs
✅ Lead magnet (PDF download)
✅ Social sharing
✅ Final integration (state management)

**TERAZ MASZ KOMPLETNY KALKULATOR GOTOWY DO v0!** 🚀\
