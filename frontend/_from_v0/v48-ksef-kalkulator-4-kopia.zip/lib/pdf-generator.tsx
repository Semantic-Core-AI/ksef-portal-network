import { Document, Page, Text, View, StyleSheet } from "@react-pdf/renderer"
import { formatCurrency, formatPercentage, type CalculatorResults } from "./calculator-logic"

// Define styles for PDF
const styles = StyleSheet.create({
  page: {
    padding: 40,
    backgroundColor: "#ffffff",
    fontFamily: "Helvetica",
  },
  header: {
    marginBottom: 30,
    borderBottom: "2 solid #1e3a5f",
    paddingBottom: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: "bold",
    color: "#1e3a5f",
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 14,
    color: "#666666",
    marginBottom: 5,
  },
  section: {
    marginBottom: 25,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#1e3a5f",
    marginBottom: 15,
    borderBottom: "1 solid #d4af37",
    paddingBottom: 5,
  },
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 12,
    paddingHorizontal: 10,
  },
  label: {
    fontSize: 12,
    color: "#333333",
    flex: 1,
  },
  value: {
    fontSize: 12,
    fontWeight: "bold",
    color: "#1e3a5f",
    textAlign: "right",
  },
  highlightBox: {
    backgroundColor: "#f0f4f8",
    padding: 15,
    borderRadius: 8,
    marginBottom: 15,
    borderLeft: "4 solid #d4af37",
  },
  highlightTitle: {
    fontSize: 14,
    fontWeight: "bold",
    color: "#1e3a5f",
    marginBottom: 8,
  },
  highlightValue: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#d4af37",
    marginBottom: 5,
  },
  warningBox: {
    backgroundColor: "#fff5f5",
    padding: 15,
    borderRadius: 8,
    marginBottom: 15,
    borderLeft: "4 solid #e53e3e",
  },
  warningValue: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#e53e3e",
    marginBottom: 5,
  },
  successBox: {
    backgroundColor: "#f0fff4",
    padding: 15,
    borderRadius: 8,
    marginBottom: 15,
    borderLeft: "4 solid #38a169",
  },
  successValue: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#38a169",
    marginBottom: 5,
  },
  bulletPoint: {
    flexDirection: "row",
    marginBottom: 8,
    paddingLeft: 10,
  },
  bullet: {
    fontSize: 12,
    marginRight: 8,
    color: "#38a169",
  },
  bulletText: {
    fontSize: 11,
    color: "#333333",
    flex: 1,
  },
  footer: {
    position: "absolute",
    bottom: 30,
    left: 40,
    right: 40,
    textAlign: "center",
    fontSize: 10,
    color: "#999999",
    borderTop: "1 solid #e0e0e0",
    paddingTop: 10,
  },
  comparisonRow: {
    flexDirection: "row",
    gap: 15,
    marginBottom: 20,
  },
  comparisonBox: {
    flex: 1,
    padding: 15,
    borderRadius: 8,
    border: "2 solid #e0e0e0",
  },
  comparisonTitle: {
    fontSize: 14,
    fontWeight: "bold",
    marginBottom: 10,
    textAlign: "center",
  },
  timelineRow: {
    flexDirection: "row",
    justifyContent: "space-around",
    marginTop: 15,
  },
  timelineItem: {
    alignItems: "center",
  },
  timelineLabel: {
    fontSize: 10,
    color: "#666666",
    marginBottom: 5,
  },
  timelineValue: {
    fontSize: 14,
    fontWeight: "bold",
    color: "#38a169",
  },
})

interface PDFReportProps {
  revenue: { value: number; label: string }
  volume: { value: number; label: string }
  results: CalculatorResults
  companyName?: string
}

function KSeFPDFReportComponent({
  revenue,
  volume,
  results,
  companyName,
  generatedDate,
}: PDFReportProps & { generatedDate: string }) {
  return (
    <Document>
      {/* Page 1: Executive Summary */}
      <Page size="A4" style={styles.page}>
        <View style={styles.header}>
          <Text style={styles.title}>Raport Kalkulatora KSeF</Text>
          <Text style={styles.subtitle}>Analiza kosztów braku wdrożenia Krajowego Systemu e-Faktur</Text>
          {companyName && <Text style={styles.subtitle}>Firma: {companyName}</Text>}
          <Text style={styles.subtitle}>Data wygenerowania: {generatedDate}</Text>
        </View>

        {/* Executive Summary */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Podsumowanie Wykonawcze</Text>

          <View style={styles.warningBox}>
            <Text style={styles.highlightTitle}>Potencjalne straty bez wdrożenia KSeF:</Text>
            <Text style={styles.warningValue}>{formatCurrency(results.totalLosses)}</Text>
            <Text style={styles.subtitle}>rocznie</Text>
          </View>

          <View style={styles.highlightBox}>
            <Text style={styles.highlightTitle}>Koszt profesjonalnego wdrożenia:</Text>
            <Text style={styles.highlightValue}>{formatCurrency(results.implementationCost)}</Text>
            <Text style={styles.subtitle}>jednorazowa inwestycja</Text>
          </View>

          <View style={styles.successBox}>
            <Text style={styles.highlightTitle}>Twoje oszczędności (rok 1):</Text>
            <Text style={styles.successValue}>{formatCurrency(results.savings)}</Text>
            <Text style={styles.subtitle}>ROI: {formatPercentage(results.roiPercentage)}</Text>
          </View>
        </View>

        {/* Company Profile */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Profil Twojej Firmy</Text>
          <View style={styles.row}>
            <Text style={styles.label}>Roczne przychody:</Text>
            <Text style={styles.value}>{revenue.label}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Wolumen faktur:</Text>
            <Text style={styles.value}>{volume.label}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Kategoria firmy:</Text>
            <Text style={styles.value}>{revenue.value < 2000000 ? "Mała firma" : "Średnia/Duża firma"}</Text>
          </View>
        </View>

        <View style={styles.footer}>
          <Text>Raport wygenerowany przez Kalkulator KSeF | Strona 1</Text>
        </View>
      </Page>

      {/* Page 2: Detailed Loss Breakdown */}
      <Page size="A4" style={styles.page}>
        <View style={styles.header}>
          <Text style={styles.title}>Szczegółowa Analiza Strat</Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Rozbicie Potencjalnych Strat</Text>

          <View style={styles.row}>
            <Text style={styles.label}>Kary i sankcje za brak zgodności:</Text>
            <Text style={styles.value}>{formatCurrency(results.fines)}</Text>
          </View>

          <View style={styles.row}>
            <Text style={styles.label}>Stracony czas (manualne przetwarzanie):</Text>
            <Text style={styles.value}>{formatCurrency(results.timeWasted)}</Text>
          </View>

          <View style={styles.row}>
            <Text style={styles.label}>Opóźnienia w zwrotach VAT:</Text>
            <Text style={styles.value}>{formatCurrency(results.vatDelays)}</Text>
          </View>

          <View style={styles.row}>
            <Text style={styles.label}>Utracone możliwości biznesowe:</Text>
            <Text style={styles.value}>{formatCurrency(results.opportunityCost)}</Text>
          </View>

          <View style={{ ...styles.row, marginTop: 20, paddingTop: 15, borderTop: "2 solid #1e3a5f" }}>
            <Text style={{ ...styles.label, fontWeight: "bold", fontSize: 14 }}>SUMA STRAT ROCZNYCH:</Text>
            <Text style={{ ...styles.value, fontSize: 18, color: "#e53e3e" }}>
              {formatCurrency(results.totalLosses)}
            </Text>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Koszty Dzienne i Miesięczne</Text>

          <View style={styles.highlightBox}>
            <View style={styles.row}>
              <Text style={styles.label}>Dzienna strata:</Text>
              <Text style={styles.value}>{formatCurrency(Math.round(results.totalLosses / 365))}</Text>
            </View>
            <View style={styles.row}>
              <Text style={styles.label}>Miesięczna strata:</Text>
              <Text style={styles.value}>{formatCurrency(Math.round(results.totalLosses / 12))}</Text>
            </View>
          </View>

          <Text style={{ fontSize: 11, color: "#666666", marginTop: 10, fontStyle: "italic" }}>
            Każdy dzień zwłoki w wdrożeniu KSeF kosztuje Twoją firmę realnie pieniądze. Im szybciej rozpoczniesz
            wdrożenie, tym więcej zaoszczędzisz.
          </Text>
        </View>

        <View style={styles.footer}>
          <Text>Raport wygenerowany przez Kalkulator KSeF | Strona 2</Text>
        </View>
      </Page>

      {/* Page 3: ROI Analysis */}
      <Page size="A4" style={styles.page}>
        <View style={styles.header}>
          <Text style={styles.title}>Analiza Zwrotu z Inwestycji (ROI)</Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Porównanie Inwestycji</Text>

          <View style={styles.comparisonRow}>
            <View style={styles.comparisonBox}>
              <Text style={{ ...styles.comparisonTitle, color: "#1e3a5f" }}>Inwestycja</Text>
              <Text style={{ ...styles.highlightValue, textAlign: "center" }}>
                {formatCurrency(results.implementationCost)}
              </Text>
              <Text style={{ fontSize: 10, textAlign: "center", color: "#666666" }}>jednorazowo</Text>
            </View>

            <View style={styles.comparisonBox}>
              <Text style={{ ...styles.comparisonTitle, color: "#38a169" }}>Oszczędności (rok 1)</Text>
              <Text style={{ ...styles.successValue, textAlign: "center" }}>{formatCurrency(results.totalLosses)}</Text>
              <Text style={{ fontSize: 10, textAlign: "center", color: "#666666" }}>rocznie</Text>
            </View>
          </View>

          <View style={styles.successBox}>
            <Text style={styles.highlightTitle}>Zwrot z inwestycji (ROI):</Text>
            <Text style={styles.successValue}>{formatPercentage(results.roiPercentage)}</Text>
            <Text style={styles.subtitle}>
              Czyli zarabiasz {Math.round(results.roi)}x więcej niż wydajesz na wdrożenie
            </Text>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Projekcja Oszczędności w Czasie</Text>

          <View style={styles.timelineRow}>
            <View style={styles.timelineItem}>
              <Text style={styles.timelineLabel}>6 miesięcy</Text>
              <Text style={styles.timelineValue}>{formatCurrency(results.savings6Months)}</Text>
            </View>
            <View style={styles.timelineItem}>
              <Text style={styles.timelineLabel}>1 rok</Text>
              <Text style={styles.timelineValue}>{formatCurrency(results.savings1Year)}</Text>
            </View>
            <View style={styles.timelineItem}>
              <Text style={styles.timelineLabel}>3 lata</Text>
              <Text style={styles.timelineValue}>{formatCurrency(results.savings3Years)}</Text>
            </View>
          </View>

          <View style={{ marginTop: 20 }}>
            <Text style={{ fontSize: 11, color: "#666666", marginBottom: 10 }}>
              Inwestycja w KSeF zwraca się średnio w ciągu{" "}
              {Math.round((results.implementationCost / results.totalLosses) * 12)} miesięcy.
            </Text>
          </View>
        </View>

        <View style={styles.footer}>
          <Text>Raport wygenerowany przez Kalkulator KSeF | Strona 3</Text>
        </View>
      </Page>

      {/* Page 4: Implementation Plan */}
      <Page size="A4" style={styles.page}>
        <View style={styles.header}>
          <Text style={styles.title}>Plan Wdrożenia</Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Co Zawiera Profesjonalne Wdrożenie</Text>

          <View style={styles.bulletPoint}>
            <Text style={styles.bullet}>✓</Text>
            <Text style={styles.bulletText}>Pełna integracja z Twoim systemem księgowym</Text>
          </View>

          <View style={styles.bulletPoint}>
            <Text style={styles.bullet}>✓</Text>
            <Text style={styles.bulletText}>Testy w środowisku demo Ministerstwa Finansów</Text>
          </View>

          <View style={styles.bulletPoint}>
            <Text style={styles.bullet}>✓</Text>
            <Text style={styles.bulletText}>Konfiguracja procesów i procedur zgodnych z KSeF</Text>
          </View>

          <View style={styles.bulletPoint}>
            <Text style={styles.bullet}>✓</Text>
            <Text style={styles.bulletText}>Kompleksowe szkolenia dla całego zespołu</Text>
          </View>

          <View style={styles.bulletPoint}>
            <Text style={styles.bullet}>✓</Text>
            <Text style={styles.bulletText}>Szczegółowa dokumentacja i instrukcje obsługi</Text>
          </View>

          <View style={styles.bulletPoint}>
            <Text style={styles.bullet}>✓</Text>
            <Text style={styles.bulletText}>90 dni dedykowanego wsparcia technicznego</Text>
          </View>

          <View style={styles.bulletPoint}>
            <Text style={styles.bullet}>✓</Text>
            <Text style={styles.bulletText}>Priorytetowa linia wsparcia (hotline)</Text>
          </View>

          <View style={styles.bulletPoint}>
            <Text style={styles.bullet}>✓</Text>
            <Text style={styles.bulletText}>Audyt pierwszych 100 faktur w systemie</Text>
          </View>

          <View style={styles.bulletPoint}>
            <Text style={styles.bullet}>✓</Text>
            <Text style={styles.bulletText}>Setup zgodności z RODO i przepisami</Text>
          </View>

          <View style={styles.bulletPoint}>
            <Text style={styles.bullet}>✓</Text>
            <Text style={styles.bulletText}>5 sesji konsultacyjnych z ekspertami</Text>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Kluczowe Wskaźniki Wdrożenia</Text>

          <View style={styles.row}>
            <Text style={styles.label}>Średni czas wdrożenia:</Text>
            <Text style={styles.value}>6-8 tygodni</Text>
          </View>

          <View style={styles.row}>
            <Text style={styles.label}>Wskaźnik sukcesu wdrożeń:</Text>
            <Text style={styles.value}>98%</Text>
          </View>

          <View style={styles.row}>
            <Text style={styles.label}>Średnia ocena klientów:</Text>
            <Text style={styles.value}>4.9/5</Text>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Następne Kroki</Text>

          <View style={styles.highlightBox}>
            <Text style={{ fontSize: 12, marginBottom: 8, fontWeight: "bold" }}>
              Umów bezpłatną 30-minutową konsultację:
            </Text>
            <Text style={{ fontSize: 11, marginBottom: 5 }}>• Analiza Twojego systemu księgowego</Text>
            <Text style={{ fontSize: 11, marginBottom: 5 }}>• Plan wdrożenia dopasowany do Twojej firmy</Text>
            <Text style={{ fontSize: 11, marginBottom: 5 }}>• Odpowiedzi na wszystkie pytania</Text>
            <Text style={{ fontSize: 11, marginBottom: 5 }}>• Dokładna wycena (nie szacunek)</Text>
          </View>
        </View>

        <View style={styles.footer}>
          <Text>Raport wygenerowany przez Kalkulator KSeF | Strona 4</Text>
        </View>
      </Page>
    </Document>
  )
}

export function KSEFReportPDF({ revenue, volume, results, companyName }: PDFReportProps) {
  const generatedDate = new Date().toLocaleDateString("pl-PL", {
    year: "numeric",
    month: "long",
    day: "numeric",
  })

  return (
    <KSeFPDFReportComponent
      revenue={revenue}
      volume={volume}
      results={results}
      companyName={companyName}
      generatedDate={generatedDate}
    />
  )
}
