"use client"

import { createContext, useContext, useState, type ReactNode } from "react"
import { calculateKSEFImpact, type CalculatorInputs, type CalculatorResults } from "./calculator-logic"

type Step = "intro" | "q1" | "q2" | "loading" | "disaster" | "solution" | "results"

interface RevenueOption {
  value: number
  label: string
}

interface VolumeOption {
  value: number
  label: string
}

interface CalculatorContextType {
  // State
  currentStep: Step
  selectedRevenue: RevenueOption | null
  selectedVolume: VolumeOption | null
  calculationResults: CalculatorResults | null

  // Actions
  setCurrentStep: (step: Step) => void
  setSelectedRevenue: (revenue: RevenueOption) => void
  setSelectedVolume: (volume: VolumeOption) => void
  calculateResults: (inputs: CalculatorInputs) => void
  resetCalculator: () => void

  // Navigation helpers
  goToNextStep: () => void
  goToPreviousStep: () => void
}

const CalculatorContext = createContext<CalculatorContextType | undefined>(undefined)

export function CalculatorProvider({ children }: { children: ReactNode }) {
  const [currentStep, setCurrentStep] = useState<Step>("intro")
  const [selectedRevenue, setSelectedRevenue] = useState<RevenueOption | null>(null)
  const [selectedVolume, setSelectedVolume] = useState<VolumeOption | null>(null)
  const [calculationResults, setCalculationResults] = useState<CalculatorResults | null>(null)

  const calculateResults = (inputs: CalculatorInputs) => {
    const results = calculateKSEFImpact(inputs)
    setCalculationResults(results)
  }

  const resetCalculator = () => {
    setCurrentStep("intro")
    setSelectedRevenue(null)
    setSelectedVolume(null)
    setCalculationResults(null)
  }

  const stepOrder: Step[] = ["intro", "q1", "q2", "loading", "disaster", "solution", "results"]

  const goToNextStep = () => {
    const currentIndex = stepOrder.indexOf(currentStep)
    if (currentIndex < stepOrder.length - 1) {
      setCurrentStep(stepOrder[currentIndex + 1])
    }
  }

  const goToPreviousStep = () => {
    const currentIndex = stepOrder.indexOf(currentStep)
    if (currentIndex > 0) {
      setCurrentStep(stepOrder[currentIndex - 1])
    }
  }

  return (
    <CalculatorContext.Provider
      value={{
        currentStep,
        selectedRevenue,
        selectedVolume,
        calculationResults,
        setCurrentStep,
        setSelectedRevenue,
        setSelectedVolume,
        calculateResults,
        resetCalculator,
        goToNextStep,
        goToPreviousStep,
      }}
    >
      {children}
    </CalculatorContext.Provider>
  )
}

export function useCalculator() {
  const context = useContext(CalculatorContext)
  if (context === undefined) {
    throw new Error("useCalculator must be used within a CalculatorProvider")
  }
  return context
}
