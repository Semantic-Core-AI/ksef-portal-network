export interface CalculatorInputs {
  revenue: number
  invoiceVolume: number
}

export interface CalculatorResults {
  // Disaster phase
  fines: number
  timeWasted: number
  vatDelays: number
  opportunityCost: number
  totalLosses: number

  // Solution phase
  implementationCost: number
  savings: number
  roi: number
  roiPercentage: number

  // Timeline projections
  savings6Months: number
  savings1Year: number
  savings3Years: number
}

export function calculateKSEFImpact(inputs: CalculatorInputs): CalculatorResults {
  const { revenue, invoiceVolume } = inputs

  // Fine calculations based on revenue tier
  const baseFine = 5000 // Base fine in PLN
  const fineMultiplier = Math.min(revenue / 1000000, 50) // Scale with revenue
  const fines = baseFine * fineMultiplier * 12 // Annual fines

  // Time wasted calculations
  const hoursPerInvoice = 0.5 // Manual processing time
  const hourlyRate = 150 // Average hourly cost in PLN
  const timeWasted = invoiceVolume * hoursPerInvoice * hourlyRate * 12

  // VAT delay costs
  const vatDelayRate = 0.02 // 2% of revenue
  const vatDelays = revenue * vatDelayRate

  // Opportunity cost (lost business due to inefficiency)
  const opportunityRate = 0.05 // 5% of revenue
  const opportunityCost = revenue * opportunityRate

  // Total losses
  const totalLosses = fines + timeWasted + vatDelays + opportunityCost

  // Implementation cost (fixed + variable based on volume)
  const baseImplementationCost = 8000
  const volumeCost = Math.min(invoiceVolume / 100, 10) * 500
  const implementationCost = baseImplementationCost + volumeCost

  // Savings and ROI
  const savings = totalLosses - implementationCost
  const roi = savings / implementationCost
  const roiPercentage = roi * 100

  // Timeline projections
  const savings6Months = totalLosses / 2 - implementationCost
  const savings1Year = savings
  const savings3Years = totalLosses * 3 - implementationCost

  return {
    fines,
    timeWasted,
    vatDelays,
    opportunityCost,
    totalLosses,
    implementationCost,
    savings,
    roi,
    roiPercentage,
    savings6Months,
    savings1Year,
    savings3Years,
  }
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat("pl-PL", {
    style: "currency",
    currency: "PLN",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount)
}

export function formatPercentage(value: number): string {
  return `${Math.round(value)}%`
}
