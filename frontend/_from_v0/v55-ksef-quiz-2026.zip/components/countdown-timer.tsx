"use client"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"
import { getTimeUntilDeadline } from "@/lib/utils/date"

export function CountdownTimer() {
  const [timeLeft, setTimeLeft] = useState(getTimeUntilDeadline())

  useEffect(() => {
    const interval = setInterval(() => {
      setTimeLeft(getTimeUntilDeadline())
    }, 1000)

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="grid grid-cols-4 gap-4 max-w-2xl mx-auto">
      <TimeUnit value={timeLeft.days} label="Dni" />
      <TimeUnit value={timeLeft.hours} label="Godzin" />
      <TimeUnit value={timeLeft.minutes} label="Minut" />
      <TimeUnit value={timeLeft.seconds} label="Sekund" />
    </div>
  )
}

function TimeUnit({ value, label }: { value: number; label: string }) {
  return (
    <motion.div
      initial={{ scale: 0.9, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      className="bg-white rounded-2xl shadow-lg p-6 border-2 border-gray-200"
    >
      <motion.div
        key={value}
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.3 }}
        className="text-4xl md:text-5xl font-black text-[#1e2a5e] text-center mb-2"
      >
        {value.toString().padStart(2, "0")}
      </motion.div>
      <div className="text-sm text-gray-600 text-center font-semibold uppercase tracking-wide">{label}</div>
    </motion.div>
  )
}
