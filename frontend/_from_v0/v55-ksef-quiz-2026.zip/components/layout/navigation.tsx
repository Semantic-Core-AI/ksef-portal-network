import Link from "next/link"
import Image from "next/image"

export function Navigation() {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
      <div className="container mx-auto px-4 h-20 flex items-center justify-between">
        <Link href="/" className="flex items-center hover:opacity-80 transition-opacity">
          <Image
            src="/logo-navy.svg"
            alt="KSEF.EXPERT"
            width={400}
            height={100}
            className="h-20 w-auto dark:hidden"
            priority
          />
          <Image
            src="/logo-white.svg"
            alt="KSEF.EXPERT"
            width={400}
            height={100}
            className="h-20 w-auto hidden dark:block"
            priority
          />
        </Link>
      </div>
    </nav>
  )
}
