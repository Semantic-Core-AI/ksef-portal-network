"use client"

import { motion } from "framer-motion"
import type { StoryAct } from "@/lib/types"

interface StoryArcIndicatorProps {
  currentAct: string
  progress: number
  total: number
  color: StoryAct
}

const actColors: Record<StoryAct, string> = {
  setup: "bg-blue-500",
  conflict: "bg-orange-500",
  climax: "bg-red-500",
  resolution: "bg-green-500",
}

const actBgColors: Record<StoryAct, string> = {
  setup: "bg-blue-50",
  conflict: "bg-orange-50",
  climax: "bg-red-50",
  resolution: "bg-green-50",
}

export function StoryArcIndicator({ currentAct, progress, total, color }: StoryArcIndicatorProps) {
  const percentage = (progress / total) * 100

  return (
    <div className="mb-12">
      <div className="max-w-4xl mx-auto">
        {/* Act Label */}
        <div className="flex items-center justify-between mb-4">
          <div className={`inline-flex items-center gap-2 ${actBgColors[color]} rounded-full px-4 py-2`}>
            <div className={`w-2 h-2 rounded-full ${actColors[color]} animate-pulse`} />
            <span className="text-sm font-bold text-gray-700">{currentAct}</span>
          </div>
          <div className="text-sm font-semibold text-gray-600">
            Pytanie {progress} z {total}
          </div>
        </div>

        {/* Progress Bar */}
        <div className="relative h-3 bg-gray-200 rounded-full overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${percentage}%` }}
            transition={{ duration: 0.5, ease: "easeOut" }}
            className={`absolute inset-y-0 left-0 ${actColors[color]} rounded-full`}
          />
        </div>

        {/* Story Arc Visualization */}
        <div className="flex justify-between mt-6">
          <ActMarker label="Odkrycie" active={progress <= 2} color="setup" />
          <ActMarker label="Wyzwanie" active={progress >= 3 && progress <= 5} color="conflict" />
          <ActMarker label="Kryzys" active={progress >= 6 && progress <= 7} color="climax" />
          <ActMarker label="Transformacja" active={progress === 8} color="resolution" />
        </div>
      </div>
    </div>
  )
}

function ActMarker({ label, active, color }: { label: string; active: boolean; color: StoryAct }) {
  return (
    <div className="flex flex-col items-center">
      <div
        className={`w-3 h-3 rounded-full transition-all duration-300 ${
          active ? actColors[color] + " scale-125" : "bg-gray-300"
        }`}
      />
      <span className={`text-xs mt-2 font-medium ${active ? "text-gray-900" : "text-gray-400"}`}>{label}</span>
    </div>
  )
}
