"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { useQuizStore } from "@/lib/store"
import { getDailyChallengeQuestion } from "@/lib/streakUtils"
import { Button } from "@/components/ui/button"
import { Calendar, CheckCircle2, Sparkles } from "lucide-react"

export function DailyChallenge() {
  const { streakData, completeDailyChallenge } = useQuizStore()
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null)
  const [isCompleted, setIsCompleted] = useState(false)

  const today = new Date().toISOString().split("T")[0]
  const alreadyCompleted = streakData.dailyChallengeCompleted && streakData.dailyChallengeDate === today

  const challenge = getDailyChallengeQuestion()

  const handleSubmit = () => {
    if (selectedAnswer) {
      completeDailyChallenge()
      setIsCompleted(true)
    }
  }

  if (alreadyCompleted || isCompleted) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-gradient-to-br from-green-500 to-emerald-600 rounded-2xl p-8 shadow-lg text-white"
      >
        <div className="flex items-center gap-4 mb-4">
          <CheckCircle2 className="w-12 h-12" />
          <div>
            <h3 className="text-2xl font-black">Wyzwanie Ukończone!</h3>
            <p className="text-white/80">Wróć jutro po nowe pytanie</p>
          </div>
        </div>
        <div className="bg-white/20 rounded-xl p-4">
          <p className="text-sm">
            Świetna robota! Twoja passa trwa już <span className="font-bold">{streakData.currentStreak} dni</span>.
            Kontynuuj codzienne wyzwania aby odblokować ekskluzywne nagrody!
          </p>
        </div>
      </motion.div>
    )
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-2xl p-8 shadow-lg border-2 border-blue-100"
    >
      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-500 rounded-xl flex items-center justify-center">
          <Calendar className="w-6 h-6 text-white" />
        </div>
        <div>
          <h3 className="text-2xl font-black text-gray-900">Dzisiejsze Wyzwanie</h3>
          <p className="text-gray-600 text-sm">Odpowiedz aby kontynuować passę</p>
        </div>
      </div>

      <div className="mb-6">
        <p className="text-lg font-semibold text-gray-900 mb-4">{challenge.question}</p>
        <div className="space-y-3">
          {challenge.options.map((option, index) => (
            <motion.button
              key={index}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => setSelectedAnswer(option)}
              className={`w-full text-left p-4 rounded-xl border-2 transition-all ${
                selectedAnswer === option
                  ? "border-blue-500 bg-blue-50"
                  : "border-gray-200 hover:border-gray-300 bg-white"
              }`}
            >
              <div className="flex items-center gap-3">
                <div
                  className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                    selectedAnswer === option ? "border-blue-500 bg-blue-500" : "border-gray-300"
                  }`}
                >
                  {selectedAnswer === option && <div className="w-2 h-2 bg-white rounded-full" />}
                </div>
                <span className="font-medium text-gray-900">{option}</span>
              </div>
            </motion.button>
          ))}
        </div>
      </div>

      <Button
        onClick={handleSubmit}
        disabled={!selectedAnswer}
        className="w-full bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white font-bold py-6 rounded-xl disabled:opacity-50 disabled:cursor-not-allowed"
      >
        <Sparkles className="w-5 h-5 mr-2" />
        Potwierdź Odpowiedź
      </Button>
    </motion.div>
  )
}
