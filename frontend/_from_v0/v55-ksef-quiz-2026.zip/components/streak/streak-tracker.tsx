"use client"

import { useEffect } from "react"
import { motion } from "framer-motion"
import { useQuizStore } from "@/lib/store"
import { Flame, Trophy, Target, Zap } from "lucide-react"
import { pluralizeDays } from "@/lib/utils"

export function StreakTracker() {
  const { streakData, updateStreak } = useQuizStore()

  useEffect(() => {
    updateStreak()
  }, [updateStreak])

  const { currentStreak, longestStreak, milestones } = streakData

  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-gradient-to-r from-orange-500 to-red-500 rounded-2xl p-6 shadow-lg"
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="relative">
            <Flame className="w-12 h-12 text-white" />
            {currentStreak > 0 && (
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="absolute -top-2 -right-2 bg-white text-orange-500 rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold"
              >
                {currentStreak}
              </motion.div>
            )}
          </div>
          <div>
            <h3 className="text-2xl font-black text-white">
              {currentStreak} {pluralizeDays(currentStreak)} z rzędu!
            </h3>
            <p className="text-white/80 text-sm">
              Najdłuższa passa: {longestStreak} {pluralizeDays(longestStreak)}
            </p>
          </div>
        </div>

        <div className="flex gap-2">
          {milestones.day7 && (
            <motion.div
              initial={{ scale: 0, rotate: -180 }}
              animate={{ scale: 1, rotate: 0 }}
              className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center"
              title="7 dni!"
            >
              <Target className="w-5 h-5 text-white" />
            </motion.div>
          )}
          {milestones.day30 && (
            <motion.div
              initial={{ scale: 0, rotate: -180 }}
              animate={{ scale: 1, rotate: 0 }}
              className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center"
              title="30 dni!"
            >
              <Zap className="w-5 h-5 text-white" />
            </motion.div>
          )}
          {milestones.day90 && (
            <motion.div
              initial={{ scale: 0, rotate: -180 }}
              animate={{ scale: 1, rotate: 0 }}
              className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center"
              title="90 dni!"
            >
              <Trophy className="w-5 h-5 text-white" />
            </motion.div>
          )}
        </div>
      </div>

      {currentStreak >= 3 && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: "auto" }}
          className="mt-4 pt-4 border-t border-white/20"
        >
          <p className="text-white/90 text-sm">
            {currentStreak < 7 && `Jeszcze ${7 - currentStreak} dni do odblokowania bonusowego contentu!`}
            {currentStreak >= 7 &&
              currentStreak < 30 &&
              `Świetnie! ${30 - currentStreak} dni do certyfikatu KSeF Committed!`}
            {currentStreak >= 30 && "Gratulacje! Jesteś prawdziwym ekspertem KSeF!"}
          </p>
        </motion.div>
      )}
    </motion.div>
  )
}
