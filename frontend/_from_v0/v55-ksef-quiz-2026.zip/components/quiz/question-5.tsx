"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { StoryArcIndicator } from "@/components/story-arc-indicator"
import { Button } from "@/components/ui/button"
import {
  ArrowRight,
  Users,
  Zap,
  BarChart3,
  Building2,
  Handshake,
  Clock,
  DollarSign,
  AlertTriangle,
  Lightbulb,
} from "lucide-react"
import { TEAMS } from "@/lib/constants"
import type { TeamType } from "@/lib/types"

interface Question5Props {
  onAnswer: (answer: TeamType, score?: number) => void
}

const teams = [
  {
    id: "solo" as TeamType,
    icon: Zap,
    title: "Ja i tylko ja",
    subtitle: "Solo warrior - wszystko na moich barkach",
    stats: ["1 osoba (Ty)", "Wszystkie decyzje", "Zero delegacji"],
    thought: "💭 'Może jednak potrzebuję pomocy...'",
  },
  {
    id: "small" as TeamType,
    icon: BarChart3,
    title: "Mamy księgową",
    subtitle: "1-2 osoby w księgowości",
    stats: ["1-2 osoby", "Dział księgowości", "Będzie dużo roboty"],
    thought: "👍 'Księgowa ma doświadczenie'",
  },
  {
    id: "department" as TeamType,
    icon: Building2,
    title: "Dział księgowości",
    subtitle: "3-5 osób - możemy się podzielić",
    stats: ["3-5 osób", "Możemy się podzielić", "Backup na urlopy"],
    thought: "✅ 'Profesjonalne podejście'",
  },
  {
    id: "outsourced" as TeamType,
    icon: Handshake,
    title: "Zewnętrzne biuro rachunkowe",
    subtitle: "Oni ogarnią wszystko",
    stats: ["Certified biuro", "Ich odpowiedzialność", "Mniejsze zaangażowanie"],
    thought: "📞 'Dzwonię do biura...'",
  },
]

export function Question5({ onAnswer }: Question5Props) {
  const [selected, setSelected] = useState<TeamType | null>(null)

  const handleSelect = (teamId: TeamType) => {
    setSelected(teamId)
  }

  const handleContinue = () => {
    if (selected) {
      const scoreMap: Record<TeamType, number> = {
        solo: 5,
        small: 15,
        department: 25,
        outsourced: 20,
      }
      onAnswer(selected, scoreMap[selected])
    }
  }

  const getRiskColor = (risk: string) => {
    if (risk === "LOW") return "text-green-600"
    if (risk === "MEDIUM") return "text-orange-600"
    return "text-red-600"
  }

  return (
    <div className="max-w-4xl mx-auto">
      <StoryArcIndicator currentAct="AKT 2: WYZWANIE" progress={5} total={8} color="conflict" />

      <div className="text-center mb-12">
        <Users className="w-20 h-20 text-[var(--ksef-navy)] mx-auto mb-4" />
        <h2 className="text-3xl font-bold mb-4 text-gray-900">Kto zajmie się KSeF w Twojej firmie?</h2>
        <p className="text-lg text-gray-600">
          Zbierasz zespół na meeting...
          <br />
          "Musimy wdrożyć KSeF. Kto się tym zajmie?"
        </p>
      </div>

      <div className="space-y-4 mb-8">
        {teams.map((team, index) => {
          const IconComponent = team.icon
          return (
            <motion.div
              key={team.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              onClick={() => handleSelect(team.id)}
              className={`
                cursor-pointer bg-white rounded-2xl p-6 border-2 transition-all duration-300
                ${selected === team.id ? "border-[var(--ksef-gold)] shadow-xl ring-4 ring-[var(--ksef-gold)]/20" : "border-gray-200 hover:border-gray-300 hover:shadow-lg"}
              `}
            >
              <div className="flex items-start gap-4">
                <IconComponent className="w-12 h-12 text-[var(--ksef-navy)]" />
                <div className="flex-1">
                  <h3 className="text-xl font-bold text-gray-900 mb-1">{team.title}</h3>
                  <p className="text-sm text-gray-600 mb-4 italic">{team.subtitle}</p>

                  <div className="grid grid-cols-3 gap-2 mb-4">
                    {team.stats.map((stat, i) => (
                      <div key={i} className="bg-gray-50 rounded-lg px-3 py-2 text-xs text-gray-700 text-center">
                        {stat}
                      </div>
                    ))}
                  </div>

                  <div className="text-sm text-gray-600">{team.thought}</div>
                </div>
              </div>
            </motion.div>
          )
        })}
      </div>

      {/* Live Impact Visualization */}
      <AnimatePresence mode="wait">
        {selected && (
          <motion.div
            key={selected}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="mt-8 bg-blue-50 rounded-2xl p-6 border-2 border-blue-200 mb-8"
          >
            <h4 className="font-bold text-blue-900 mb-4 flex items-center gap-2">
              <BarChart3 className="w-5 h-5" /> Wpływ na projekt:
            </h4>

            <div className="grid md:grid-cols-3 gap-4 mb-6">
              <div className="bg-white rounded-xl p-4">
                <div className="text-xs text-gray-600 mb-1 flex items-center gap-1">
                  <Clock className="w-3 h-3" /> Twoje zaangażowanie
                </div>
                <div className="text-lg font-bold text-gray-900">{TEAMS[selected].impact.time}</div>
              </div>
              <div className="bg-white rounded-xl p-4">
                <div className="text-xs text-gray-600 mb-1 flex items-center gap-1">
                  <DollarSign className="w-3 h-3" /> Koszt dodatkowy
                </div>
                <div className="text-lg font-bold text-gray-900">{TEAMS[selected].impact.cost || "0 PLN"}</div>
              </div>
              <div className="bg-white rounded-xl p-4">
                <div className="text-xs text-gray-600 mb-1 flex items-center gap-1">
                  <AlertTriangle className="w-3 h-3" /> Poziom ryzyka
                </div>
                <div className={`text-lg font-bold ${getRiskColor(TEAMS[selected].impact.risk)}`}>
                  {TEAMS[selected].impact.risk}
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-blue-200">
              <div className="text-sm text-blue-700 mb-2 flex items-center gap-2">
                <Lightbulb className="w-4 h-4" /> Jak to się ma do innych firm?
              </div>
              <div className="text-sm text-blue-600">
                {selected === "solo" && "78% firm które wdrażały solo zgłaszały wysoki poziom stresu. Rozważ pomoc."}
                {selected === "small" && "Najpopularniejszy wybór w firmach 5-20 osób. Dobry balans."}
                {selected === "department" && "Profesjonalne podejście - 92% sukces rate w tej kategorii."}
                {selected === "outsourced" && "Najniższy stress level, ale wyższe koszty długoterminowe."}
              </div>
            </div>

            <div className="mt-6 text-center">
              <Button size="lg" onClick={handleContinue} className="bg-[var(--ksef-navy)]">
                Dalej <ArrowRight className="ml-2" />
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
