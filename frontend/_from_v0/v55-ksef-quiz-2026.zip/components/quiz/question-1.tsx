"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { StoryArcIndicator } from "@/components/story-arc-indicator"
import { AvatarCard } from "@/components/quiz/avatar-card"
import { Zap, Briefcase, Home, Star, Building2, Fan as Fax } from "lucide-react"
import type { AvatarType } from "@/lib/types"

interface Question1Props {
  onAnswer: (answer: AvatarType, score?: number) => void
}

const avatars = [
  {
    id: "startup_ninja" as AvatarType,
    icon: Zap,
    title: "STARTUP NINJA",
    subtitle: "Mała, szybka, agile",
    description: "Mikrofirma, do 50 faktur/mies, wszystko DIY",
    stats: ["Excel/brak systemu", "1-3 osoby", "Home office"],
    trait: "WYZWANIE: Brak zasobów",
    superpower: "SUPERPOWER: Szybkość adaptacji",
    gradient: "from-purple-500 to-pink-500",
  },
  {
    id: "freelancer_solo" as AvatarType,
    icon: Briefcase,
    title: "FREELANCER SOLO",
    subtitle: "Ja, mój laptop i kawa",
    description: "JDG, do 30 faktur, usługi profesjonalne",
    stats: ["inFakt/Fakturownia", "Sam na wszystko", "Konsulting/IT"],
    trait: "WYZWANIE: Zero wsparcia",
    superpower: "SUPERPOWER: Minimalna biurokracja",
    gradient: "from-blue-500 to-cyan-500",
  },
  {
    id: "family_biz" as AvatarType,
    icon: Home,
    title: "RODZINNY BIZNES",
    subtitle: "Tradycja i stabilność",
    description: "5-20 osób, działamy od lat, sprawdzone metody",
    stats: ["Comarch/Symfonia", "Doświadczenie", "Handel/Usługi"],
    trait: "WYZWANIE: Opór przed zmianą",
    superpower: "SUPERPOWER: Lojalność klientów",
    gradient: "from-green-500 to-emerald-500",
  },
  {
    id: "rising_star" as AvatarType,
    icon: Star,
    title: "ROSNĄCA GWIAZDA",
    subtitle: "W fazie wzrostu",
    description: "20-50 osób, skalujemy, młody zespół",
    stats: ["E-commerce/B2B", "100+ faktur/mies", "Ambicje"],
    trait: "WYZWANIE: Chaos wzrostu",
    superpower: "SUPERPOWER: Budżet i energia",
    gradient: "from-orange-500 to-red-500",
  },
  {
    id: "corporation" as AvatarType,
    icon: Building2,
    title: "KORPORACJA",
    subtitle: "Struktura i procedury",
    description: "100+ osób, działy księgowe + IT, compliance",
    stats: ["SAP/ERP", "Budżet", "Procesy"],
    trait: "WYZWANIE: Długie decyzje",
    superpower: "SUPERPOWER: Zasoby i eksperci",
    gradient: "from-blue-700 to-blue-900",
  },
  {
    id: "oldschool" as AvatarType,
    icon: Fax,
    title: "OLDSCHOOL LEGACY",
    subtitle: "30 lat doświadczenia",
    description: "Starszy właściciel, Excel + papier, po co komputery?",
    stats: ["Technofobia", "Papier", "Stabilność"],
    trait: "WYZWANIE: Brak digitalizacji",
    superpower: "SUPERPOWER: Ustabilizowana baza",
    gradient: "from-gray-500 to-gray-700",
  },
]

export function Question1({ onAnswer }: Question1Props) {
  const [selected, setSelected] = useState<AvatarType | null>(null)

  const handleSelect = (avatarId: AvatarType) => {
    setSelected(avatarId)
    // Auto-advance after selection with slight delay
    setTimeout(() => {
      onAnswer(avatarId, 10)
    }, 800)
  }

  return (
    <div className="max-w-7xl mx-auto">
      <StoryArcIndicator currentAct="AKT 1: ODKRYCIE" progress={1} total={8} color="setup" />

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="text-center mb-12"
      >
        <h2 className="text-3xl md:text-4xl font-black mb-4 text-gray-900">Kim jesteś w tej historii?</h2>
        <p className="text-lg text-gray-600">Wybierz avatar który najlepiej opisuje Twoją firmę</p>
      </motion.div>

      <div className="grid md:grid-cols-3 gap-6 mb-8">
        {avatars.map((avatar, index) => (
          <motion.div
            key={avatar.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
          >
            <AvatarCard {...avatar} selected={selected === avatar.id} onClick={() => handleSelect(avatar.id)} />
          </motion.div>
        ))}
      </div>

      <p className="text-center text-sm text-gray-500">Wybierz ten który jest NAJBLIŻSZY Twojej sytuacji</p>
    </div>
  )
}
