"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { StoryArcIndicator } from "@/components/story-arc-indicator"
import { Button } from "@/components/ui/button"
import { ArrowRight, Calendar, User, ThumbsUp, MessageCircle, CheckCircle2, X, Lightbulb } from "lucide-react"
import { DndContext, closestCenter, KeyboardSensor, PointerSensor, useSensor, useSensors } from "@dnd-kit/core"
import { arrayMove, SortableContext, sortableKeyboardCoordinates, verticalListSortingStrategy } from "@dnd-kit/sortable"
import { SortableItem } from "@/components/quiz/sortable-item"

interface Question2Props {
  onAnswer: (answer: any, score?: number) => void
}

const items = [
  { id: "deadline", label: "Termin obowiązkowego wdrożenia", icon: Calendar, correctRank: 1 },
  { id: "system", label: "Jaki system księgowy potrzebuję", icon: User, correctRank: 2 },
  { id: "koszty", label: "Ile będzie kosztować wdrożenie", icon: ThumbsUp, correctRank: 3 },
  { id: "api", label: "Jak działa API KSeF", icon: MessageCircle, correctRank: 4 },
  { id: "procesy", label: "Jakie procesy muszę zmienić", icon: Lightbulb, correctRank: 5 },
]

export function Question2({ onAnswer }: Question2Props) {
  const [itemOrder, setItemOrder] = useState(items.map((item) => item.id))
  const [showFeedback, setShowFeedback] = useState(false)
  const [knowledgeScore, setKnowledgeScore] = useState(0)

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    }),
  )

  const handleDragEnd = (event: any) => {
    const { active, over } = event

    if (active.id !== over.id) {
      setItemOrder((items) => {
        const oldIndex = items.indexOf(active.id)
        const newIndex = items.indexOf(over.id)
        return arrayMove(items, oldIndex, newIndex)
      })
    }
  }

  const handleComplete = () => {
    // Calculate score based on ranking accuracy
    let score = 0
    itemOrder.forEach((id, index) => {
      const item = items.find((i) => i.id === id)
      if (item) {
        const diff = Math.abs(item.correctRank - (index + 1))
        score += Math.max(0, 20 - diff * 5)
      }
    })

    setKnowledgeScore(score)
    setShowFeedback(true)

    setTimeout(() => {
      onAnswer({ ranking: itemOrder }, score)
    }, 3000)
  }

  return (
    <div className="max-w-4xl mx-auto">
      <StoryArcIndicator currentAct="AKT 1: ODKRYCIE" progress={2} total={8} color="setup" />

      {/* Narrative setup */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-r from-blue-50 to-cyan-50 rounded-2xl p-8 mb-8 border-2 border-blue-200"
      >
        <div className="flex items-start gap-4">
          <Calendar className="w-12 h-12 text-blue-600" />
          <div>
            <div className="text-sm font-semibold text-blue-600 mb-2">26 PAŹDZIERNIKA 2025 • 98 DNI DO DEADLINE</div>
            <p className="text-lg font-medium text-gray-800 mb-3">Scrollujesz LinkedIn i widzisz post:</p>
            <div className="bg-white rounded-xl p-4 shadow-sm border-2 border-blue-200">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                  <User className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <div className="font-semibold">Jan Kowalski</div>
                  <div className="text-xs text-gray-500">CEO @ TechCorp</div>
                </div>
              </div>
              <p className="text-sm mb-2">Dziś ostatni dzień na przygotowanie do KSeF! A Ty jesteś gotowy?</p>
              <div className="flex items-center gap-3 text-xs text-gray-500">
                <span className="flex items-center gap-1">
                  <ThumbsUp className="w-3 h-3" /> 247
                </span>
                <span className="flex items-center gap-1">
                  <MessageCircle className="w-3 h-3" /> 89 komentarzy
                </span>
              </div>
            </div>
          </div>
        </div>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
        <h2 className="text-3xl font-bold mb-4 text-gray-900">Jak bardzo znasz KSeF?</h2>
        <p className="text-lg text-gray-600 mb-8">
          Przeciągnij elementy od "Znam najlepiej" (góra) do "Nie mam pojęcia" (dół)
        </p>

        {/* Drag & Drop Interface */}
        <div className="bg-white rounded-2xl p-8 shadow-lg border-2 border-gray-200 mb-8">
          <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
            <SortableContext items={itemOrder} strategy={verticalListSortingStrategy}>
              <div className="space-y-3">
                {itemOrder.map((id, index) => {
                  const item = items.find((i) => i.id === id)!
                  return <SortableItem key={id} id={id} label={item.label} icon={item.icon} index={index} />
                })}
              </div>
            </SortableContext>
          </DndContext>

          <div className="mt-6 flex justify-between text-sm font-semibold">
            <span className="flex items-center gap-2 text-green-600">
              <CheckCircle2 className="w-4 h-4" /> Znam doskonale
            </span>
            <span className="flex items-center gap-2 text-red-600">
              <X className="w-4 h-4" /> Nie mam pojęcia
            </span>
          </div>
        </div>

        {!showFeedback && (
          <div className="text-center">
            <Button size="lg" onClick={handleComplete} className="bg-[var(--ksef-navy)] hover:bg-[var(--ksef-navy)]/90">
              Sprawdź moją wiedzę <ArrowRight className="ml-2" />
            </Button>
          </div>
        )}

        {/* Real-time feedback */}
        <AnimatePresence>
          {showFeedback && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="mt-8 p-6 bg-blue-50 rounded-xl border-2 border-blue-200"
            >
              <div className="flex items-start gap-4">
                <Lightbulb className="w-10 h-10 text-blue-600" />
                <div>
                  <h4 className="font-bold text-blue-900 mb-2">Instant Insight:</h4>
                  <p className="text-blue-800">
                    {knowledgeScore < 40 && "Uwaga! Zostało 98 dni a podstawowa wiedza jest luka. Czas na akcję!"}
                    {knowledgeScore >= 40 &&
                      knowledgeScore < 70 &&
                      "Nieźle! Znasz basics, ale diabeł tkwi w szczegółach."}
                    {knowledgeScore >= 70 && "Wow! Jesteś dobrze poinformowany. To daje przewagę!"}
                  </p>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  )
}
