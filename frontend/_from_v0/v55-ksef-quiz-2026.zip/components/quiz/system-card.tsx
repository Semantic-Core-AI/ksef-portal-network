"use client"

import { motion } from "framer-motion"
import { CheckCircle2, AlertTriangle, type LucideIcon } from "lucide-react"
import { Badge } from "@/components/ui/badge"

interface SystemCardProps {
  id: string
  name: string
  icon: LucideIcon
  difficulty: string
  difficultyColor: string
  integrationCost: number
  time: string
  warning?: string
  badge?: string
  benefit?: string
  alert?: string
  selected: boolean
  onClick: () => void
}

export function SystemCard({
  name,
  icon: Icon,
  difficulty,
  difficultyColor,
  integrationCost,
  time,
  warning,
  badge,
  benefit,
  alert,
  selected,
  onClick,
}: SystemCardProps) {
  const difficultyColors: Record<string, string> = {
    green: "bg-green-100 text-green-700 border-green-300",
    red: "bg-red-100 text-red-700 border-red-300",
    orange: "bg-orange-100 text-orange-700 border-orange-300",
  }

  return (
    <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }} className="cursor-pointer" onClick={onClick}>
      <div
        className={`
        bg-white rounded-xl p-6 border-2 transition-all duration-300
        ${selected ? "border-[#c7a83b] shadow-xl ring-4 ring-[#c7a83b]/20" : "border-gray-200 hover:border-gray-300 hover:shadow-lg"}
      `}
      >
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center gap-3">
            <Icon className="w-10 h-10 text-[#1e2a5e]" strokeWidth={1.5} />
            <div>
              <h3 className="font-bold text-gray-900">{name}</h3>
              <div className="flex items-center gap-2 mt-1">
                <Badge className={`text-xs ${difficultyColors[difficultyColor]} border`}>{difficulty}</Badge>
                {badge && <Badge className="text-xs bg-blue-100 text-blue-700 border border-blue-300">{badge}</Badge>}
              </div>
            </div>
          </div>
          {selected && <CheckCircle2 className="w-6 h-6 text-[#c7a83b]" />}
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-600">Koszt integracji:</span>
            <span className="font-bold text-gray-900">{integrationCost.toLocaleString()} PLN</span>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-600">Czas wdrożenia:</span>
            <span className="font-bold text-gray-900">{time}</span>
          </div>
        </div>

        {warning && (
          <div className="mt-4 bg-red-50 border border-red-200 rounded-lg p-3 flex items-start gap-2">
            <AlertTriangle className="w-4 h-4 text-red-600 mt-0.5 flex-shrink-0" />
            <p className="text-xs text-red-700">{warning}</p>
          </div>
        )}

        {benefit && (
          <div className="mt-4 bg-green-50 border border-green-200 rounded-lg p-3 flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
            <p className="text-xs text-green-700">{benefit}</p>
          </div>
        )}

        {alert && (
          <div className="mt-4 bg-red-100 border-2 border-red-400 rounded-lg p-3">
            <p className="text-xs text-red-800 font-bold">{alert}</p>
          </div>
        )}
      </div>
    </motion.div>
  )
}
