"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { StoryArcIndicator } from "@/components/story-arc-indicator"
import { Button } from "@/components/ui/button"
import { ArrowRight, AlertTriangle, Clock, Calendar, MapPin } from "lucide-react"
import { DEADLINES } from "@/lib/constants"
import { getDaysUntilDeadline } from "@/lib/utils/date"
import type { DeadlineChoice } from "@/lib/types"

interface Question4Props {
  onAnswer: (answer: DeadlineChoice, score?: number) => void
}

export function Question4({ onAnswer }: Question4Props) {
  const [selected, setSelected] = useState<DeadlineChoice | null>(null)
  const daysUntilDeadline = getDaysUntilDeadline()

  const handleSelect = (deadlineId: DeadlineChoice) => {
    setSelected(deadlineId)
  }

  const handleContinue = () => {
    if (selected) {
      const scoreMap: Record<DeadlineChoice, number> = {
        november: 25,
        december: 20,
        mid_january: 10,
        late_january: 5,
        after_deadline: 0,
      }
      onAnswer(selected, scoreMap[selected])
    }
  }

  return (
    <div className="max-w-5xl mx-auto">
      <StoryArcIndicator currentAct="AKT 2: WYZWANIE" progress={4} total={8} color="conflict" />

      <div className="text-center mb-12">
        <Clock className="w-20 h-20 text-[var(--ksef-navy)] mx-auto mb-4" />
        <h2 className="text-3xl font-bold mb-4 text-gray-900">Kiedy chcesz być gotowy?</h2>
        <p className="text-lg text-gray-600">Kliknij na osi czasu kiedy planujesz zakończyć wdrożenie</p>
      </div>

      {/* Interactive Timeline */}
      <div className="relative mb-12">
        {/* Timeline bar */}
        <div className="relative h-24 bg-gradient-to-r from-green-200 via-yellow-200 via-orange-200 to-red-200 rounded-full overflow-hidden mb-16">
          {/* Current date marker */}
          <motion.div
            className="absolute top-0 bottom-0 w-1 bg-blue-600 z-10"
            style={{ left: "15%" }}
            animate={{ scale: [1, 1.2, 1] }}
            transition={{ repeat: Number.POSITIVE_INFINITY, duration: 2 }}
          >
            <div className="absolute -top-12 left-1/2 -translate-x-1/2 text-center whitespace-nowrap">
              <div className="text-xs font-semibold text-blue-600 flex items-center gap-1">
                <MapPin className="w-3 h-3" /> DZISIAJ
              </div>
              <div className="text-xs text-gray-600">26.10.2025</div>
            </div>
          </motion.div>

          {/* Deadline marker */}
          <div className="absolute top-0 bottom-0 w-1 bg-red-600 z-10" style={{ right: "0%" }}>
            <div className="absolute -top-12 left-1/2 -translate-x-1/2 text-center whitespace-nowrap">
              <div className="text-xs font-semibold text-red-600 flex items-center gap-1">
                <AlertTriangle className="w-3 h-3" /> DEADLINE
              </div>
              <div className="text-xs text-gray-600">01.02.2026</div>
            </div>
          </div>

          {/* Clickable zones */}
          <div className="absolute inset-0 flex">
            <TimelineZone
              id="november"
              label="Listopad"
              left="20%"
              width="20%"
              onClick={() => handleSelect("november")}
              selected={selected === "november"}
            />
            <TimelineZone
              id="december"
              label="Grudzień"
              left="40%"
              width="20%"
              onClick={() => handleSelect("december")}
              selected={selected === "december"}
            />
            <TimelineZone
              id="mid_january"
              label="Połowa Stycznia"
              left="60%"
              width="20%"
              onClick={() => handleSelect("mid_january")}
              selected={selected === "mid_january"}
            />
            <TimelineZone
              id="late_january"
              label="Koniec Stycznia"
              left="80%"
              width="15%"
              onClick={() => handleSelect("late_january")}
              selected={selected === "late_january"}
            />
            <TimelineZone
              id="after_deadline"
              label="Po 1 Lutego"
              left="95%"
              width="5%"
              onClick={() => handleSelect("after_deadline")}
              selected={selected === "after_deadline"}
            />
          </div>
        </div>

        {/* Days counter */}
        <div className="text-center">
          <div className="inline-block bg-white rounded-2xl shadow-lg px-8 py-4 border-2 border-gray-200">
            <div className="text-sm text-gray-600 mb-1">Zostało do deadline</div>
            <div className="text-5xl font-black text-red-600">{daysUntilDeadline}</div>
            <div className="text-sm text-gray-600 mt-1">dni</div>
          </div>
        </div>
      </div>

      {/* Selection feedback */}
      <AnimatePresence mode="wait">
        {selected && (
          <motion.div
            key={selected}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className={`
              rounded-2xl p-8 border-2 mb-8
              ${DEADLINES[selected].status === "comfortable" ? "bg-green-50 border-green-200" : ""}
              ${DEADLINES[selected].status === "good" ? "bg-blue-50 border-blue-200" : ""}
              ${DEADLINES[selected].status === "tight" ? "bg-orange-50 border-orange-200" : ""}
              ${DEADLINES[selected].status === "critical" ? "bg-red-50 border-red-200" : ""}
              ${DEADLINES[selected].status === "illegal" ? "bg-red-100 border-red-400" : ""}
            `}
          >
            <div className="flex items-start gap-4">
              <div className="text-5xl">
                {(() => {
                  const Icon = DEADLINES[selected].icon
                  return <Icon className="w-16 h-16" />
                })()}
              </div>
              <div className="flex-1">
                <h3 className="text-2xl font-bold mb-2">{DEADLINES[selected].label}</h3>
                <p className="text-lg mb-4">{DEADLINES[selected].message}</p>

                {DEADLINES[selected].timeline && (
                  <div className="bg-white rounded-lg p-4 mb-4">
                    <div className="text-sm font-semibold mb-2 flex items-center gap-2">
                      <Calendar className="w-4 h-4" /> Harmonogram:
                    </div>
                    <div className="text-sm text-gray-700">{DEADLINES[selected].timeline}</div>
                  </div>
                )}

                {DEADLINES[selected].urgencyCost > 0 && (
                  <div className="bg-white rounded-lg p-4 mb-4">
                    <div className="flex items-center justify-between">
                      <div className="text-sm font-semibold text-orange-600 flex items-center gap-2">
                        <AlertTriangle className="w-4 h-4" /> Dopłata za pilność:
                      </div>
                      <div className="text-2xl font-bold text-orange-700">
                        +{DEADLINES[selected].urgencyCost.toLocaleString()} PLN
                      </div>
                    </div>
                  </div>
                )}

                {DEADLINES[selected].warnings && (
                  <div className="mt-4 space-y-2">
                    {DEADLINES[selected].warnings!.map((warning, i) => (
                      <div key={i} className="flex items-center text-sm text-red-700">
                        <AlertTriangle className="w-4 h-4 mr-2 flex-shrink-0" />
                        {warning}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            <div className="mt-6 text-center">
              <Button size="lg" onClick={handleContinue} className="bg-[var(--ksef-navy)]">
                Rozumiem konsekwencje <ArrowRight className="ml-2" />
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

function TimelineZone({
  id,
  label,
  left,
  width,
  onClick,
  selected,
}: {
  id: string
  label: string
  left: string
  width: string
  onClick: () => void
  selected: boolean
}) {
  return (
    <button
      onClick={onClick}
      className={`
        absolute h-full cursor-pointer transition-all duration-300
        hover:bg-white/30 flex items-center justify-center
        ${selected ? "bg-white/50 ring-4 ring-white" : ""}
      `}
      style={{ left, width }}
    >
      <span className="text-xs font-bold text-gray-800 px-2 text-center">{label}</span>
    </button>
  )
}
