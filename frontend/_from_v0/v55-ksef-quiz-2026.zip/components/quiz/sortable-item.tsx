"use client"

import { useSortable } from "@dnd-kit/sortable"
import { CSS } from "@dnd-kit/utilities"
import { GripVertical } from "lucide-react"

interface SortableItemProps {
  id: string
  label: string
  index: number
}

export function SortableItem({ id, label, index }: SortableItemProps) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id })

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  }

  return (
    <div
      ref={setNodeRef}
      style={style}
      className={`
        flex items-center gap-3 bg-gray-50 rounded-xl p-4 border-2 border-gray-200
        cursor-move hover:bg-gray-100 hover:border-gray-300 transition-all
        ${isDragging ? "opacity-50 shadow-2xl scale-105" : ""}
      `}
      {...attributes}
      {...listeners}
    >
      <GripVertical className="w-5 h-5 text-gray-400" />
      <div className="flex-1 font-medium text-gray-900">{label}</div>
      <div className="w-8 h-8 rounded-full bg-white border-2 border-gray-300 flex items-center justify-center text-sm font-bold text-gray-600">
        {index + 1}
      </div>
    </div>
  )
}
