"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { StoryArcIndicator } from "@/components/story-arc-indicator"
import { SystemCard } from "@/components/quiz/system-card"
import { Button } from "@/components/ui/button"
import { ArrowRight, Laptop, CheckCircle2 } from "lucide-react"
import { SYSTEMS } from "@/lib/constants"
import type { SystemType } from "@/lib/types"

interface Question3Props {
  onAnswer: (answer: SystemType, score?: number) => void
}

export function Question3({ onAnswer }: Question3Props) {
  const [selected, setSelected] = useState<SystemType | null>(null)

  const handleSelect = (systemId: SystemType) => {
    setSelected(systemId)
  }

  const handleContinue = () => {
    if (selected) {
      const score =
        selected === "comarch" || selected === "symfonia" ? 20 : selected === "excel" || selected === "none" ? 5 : 15
      onAnswer(selected, score)
    }
  }

  return (
    <div className="max-w-4xl mx-auto">
      <StoryArcIndicator currentAct="AKT 2: WYZWANIE" progress={3} total={8} color="conflict" />

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
        <Laptop className="w-16 h-16 text-[var(--ksef-navy)] mb-4" />
        <h2 className="text-3xl font-bold mb-4 text-gray-900">Twój system księgowy</h2>
        <p className="text-lg text-gray-700">
          Dzwonisz do księgowej: "Jesteśmy gotowi na KSeF?"
          <br />
          Ona: "Hmm, musimy sprawdzić czy nasz system to obsługuje..."
        </p>
      </motion.div>

      <div className="grid md:grid-cols-2 gap-4 mb-8">
        {Object.entries(SYSTEMS).map(([id, system], index) => (
          <motion.div
            key={id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <SystemCard id={id} {...system} selected={selected === id} onClick={() => handleSelect(id as SystemType)} />
          </motion.div>
        ))}
      </div>

      {/* Live Cost Display */}
      <AnimatePresence mode="wait">
        {selected && (
          <motion.div
            key={selected}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="bg-gradient-to-r from-orange-50 to-red-50 rounded-2xl p-8 border-2 border-orange-200 mb-8"
          >
            <div className="flex items-center justify-between mb-4">
              <div>
                <div className="text-sm font-semibold text-orange-600 mb-1">KOSZT INTEGRACJI</div>
                <div className="text-4xl font-black text-orange-700">
                  {SYSTEMS[selected].integrationCost.toLocaleString()} PLN
                </div>
              </div>
              <div className="text-right">
                <div className="text-sm font-semibold text-orange-600 mb-1">CZAS WDROŻENIA</div>
                <div className="text-2xl font-bold text-orange-700">{SYSTEMS[selected].time}</div>
              </div>
            </div>

            {SYSTEMS[selected].warning && (
              <div className="bg-white rounded-lg p-4 border-l-4 border-red-500">
                <p className="text-sm text-red-700 font-medium">{SYSTEMS[selected].warning}</p>
              </div>
            )}

            {SYSTEMS[selected].benefit && (
              <div className="bg-white rounded-lg p-4 border-l-4 border-green-500 mt-3">
                <p className="text-sm text-green-700 font-medium flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4" /> {SYSTEMS[selected].benefit}
                </p>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {selected && (
        <div className="text-center">
          <Button size="lg" onClick={handleContinue} className="bg-[var(--ksef-navy)] hover:bg-[var(--ksef-navy)]/90">
            Kontynuuj <ArrowRight className="ml-2" />
          </Button>
        </div>
      )}
    </div>
  )
}
