"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { StoryArcIndicator } from "@/components/story-arc-indicator"
import { Button } from "@/components/ui/button"
import { ArrowRight, Frown, Briefcase, Phone, FileText, AlertCircle } from "lucide-react"
import type { CrisisChoice } from "@/lib/types"

interface Question7Props {
  onAnswer: (answer: CrisisChoice, score?: number) => void
}

const crisisOptions = [
  {
    id: "panic" as CrisisChoice,
    icon: Frown,
    title: "PANIKA! 'To wszystko gówno!'",
    subtitle: "Meltdown - tracisz kontrolę",
    consequence: {
      team: -20,
      stress: 30,
      reputation: -15,
      result: "Zespół traci wiarę. Klienci słyszą chaos. Szef zastanawia się nad zmianą lidera projektu.",
    },
  },
  {
    id: "backup" as CrisisChoice,
    icon: Briefcase,
    title: "Mamy plan B - wystawiam offline, prześlę później",
    subtitle: "Backup plan - procedury awaryjne",
    consequence: {
      team: 15,
      process: 20,
      reputation: 10,
      result: "Spokojnie informujesz klientów. Zespół wie co robić. Faktury pójdą jak system wróci. Profesjonalizm!",
    },
    badge: "✅ BEST CHOICE",
  },
  {
    id: "wait" as CrisisChoice,
    icon: Phone,
    title: "Dzwonię do supportu i czekam",
    subtitle: "Wait it out - bierna postawa",
    consequence: {
      timeline: -10,
      reputation: -5,
      result: "Klienci czekają 6 godzin. Część zrezygnowała. Support mówi 'awaria po naszej stronie, przykro nam'.",
    },
  },
  {
    id: "paper" as CrisisChoice,
    icon: FileText,
    title: "Wracam do papierowych faktur!",
    subtitle: "Regression - nielegalne po 1 lutego",
    consequence: {
      legal: -30,
      risk: 40,
      fine: 25000,
      result: "2 miesiące później: pismo z US. Wykryto faktury poza KSeF. KARA: 25,000 PLN. GAME OVER.",
    },
    warning: "🚨 NIELEGALNE!",
  },
]

export function Question7({ onAnswer }: Question7Props) {
  const [selected, setSelected] = useState<CrisisChoice | null>(null)
  const [timeLeft, setTimeLeft] = useState(30)
  const [timeExpired, setTimeExpired] = useState(false)

  useEffect(() => {
    if (timeLeft > 0 && !selected) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000)
      return () => clearTimeout(timer)
    } else if (timeLeft === 0 && !selected) {
      setTimeExpired(true)
    }
  }, [timeLeft, selected])

  const handleSelect = (crisisId: CrisisChoice) => {
    setSelected(crisisId)
  }

  const handleContinue = () => {
    if (selected) {
      const scoreMap: Record<CrisisChoice, number> = {
        panic: 5,
        backup: 30,
        wait: 10,
        paper: 0,
      }
      onAnswer(selected, scoreMap[selected])
    }
  }

  const getImpactLabel = (key: string) => {
    const labels: Record<string, string> = {
      team: "Zespół",
      stress: "Stres",
      reputation: "Reputacja",
      timeline: "Timeline",
      process: "Procesy",
      legal: "Legal",
      risk: "Ryzyko",
    }
    return labels[key] || key
  }

  return (
    <div className="max-w-4xl mx-auto">
      <StoryArcIndicator currentAct="AKT 3: KRYZYS" progress={7} total={8} color="climax" />

      {/* Crisis Header */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-gradient-to-r from-red-500 to-orange-500 text-white rounded-2xl p-8 mb-8 shadow-2xl"
      >
        <div className="flex items-start gap-4">
          <AlertCircle className="w-16 h-16 flex-shrink-0" />
          <div className="flex-1">
            <div className="text-sm font-bold uppercase tracking-wide mb-2">ALERT • 2 TYGODNIE PO WDROŻENIU</div>
            <h2 className="text-3xl font-black mb-4">SYSTEM KSEF PADŁ!</h2>
            <p className="text-lg opacity-90">
              Awaria trwa już 4 godziny. Masz 50 faktur do wystawienia DZISIAJ. Klienci dzwonią. Szef pyta co się
              dzieje.
            </p>
          </div>
        </div>
      </motion.div>

      {/* Scenario Simulation */}
      <div className="bg-gray-900 text-white rounded-2xl p-8 mb-8 font-mono text-sm">
        <div className="mb-4 flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-red-500 animate-pulse" />
          <div className="w-3 h-3 rounded-full bg-yellow-500 animate-pulse" style={{ animationDelay: "0.3s" }} />
          <div className="w-3 h-3 rounded-full bg-green-500 animate-pulse" style={{ animationDelay: "0.6s" }} />
        </div>

        <div className="space-y-2">
          <div className="text-red-400">&gt; System KSeF: CONNECTION TIMEOUT</div>
          <div className="text-yellow-400">&gt; Retry attempt #47... FAILED</div>
          <div className="text-gray-400">&gt; Queue: 50 faktur waiting...</div>
          <div className="text-red-400">&gt; Klient #1: 'Gdzie jest moja faktura?!"</div>
          <div className="text-red-400">&gt; Klient #2: 'Nie mogę zaksięgować!'</div>
          <div className="text-yellow-400">&gt; Szef: 'Co się dzieje???'</div>
          <div className="text-gray-400">&gt; ...</div>
          <div className="animate-pulse">_</div>
        </div>
      </div>

      {/* Decision Time */}
      <div className="mb-8">
        <h3 className="text-2xl font-bold mb-6 text-center text-gray-900">Co robisz? ⏰ Masz 30 sekund na decyzję</h3>

        {/* Timer */}
        {!selected && !timeExpired && (
          <div className="text-center mb-8">
            <div className="inline-block">
              <div className="relative w-24 h-24">
                <svg className="w-24 h-24 transform -rotate-90">
                  <circle
                    cx="48"
                    cy="48"
                    r="44"
                    stroke="currentColor"
                    strokeWidth="8"
                    fill="none"
                    className="text-gray-200"
                  />
                  <circle
                    cx="48"
                    cy="48"
                    r="44"
                    stroke="currentColor"
                    strokeWidth="8"
                    fill="none"
                    strokeDasharray={276.46}
                    strokeDashoffset={276.46 * (1 - timeLeft / 30)}
                    className={`transition-all duration-1000 ${timeLeft <= 10 ? "text-red-500" : "text-blue-500"}`}
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-3xl font-bold text-gray-900">{timeLeft}</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Options */}
        <div className="space-y-4">
          {crisisOptions.map((option, index) => (
            <motion.div
              key={option.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              onClick={() => !timeExpired && handleSelect(option.id)}
              className={`
                cursor-pointer bg-white rounded-2xl p-6 border-2 transition-all duration-300
                ${selected === option.id ? "border-[var(--ksef-gold)] shadow-xl ring-4 ring-[var(--ksef-gold)]/20" : "border-gray-200 hover:border-gray-300 hover:shadow-lg"}
                ${option.warning ? "border-red-300" : ""}
                ${timeExpired ? "opacity-50 cursor-not-allowed" : ""}
              `}
            >
              <div className="flex items-start gap-4">
                <option.icon className="w-10 h-10 flex-shrink-0 text-gray-700" />
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="text-lg font-bold text-gray-900">{option.title}</h3>
                    {option.badge && (
                      <span className="text-xs font-bold bg-green-100 text-green-700 px-2 py-1 rounded">
                        {option.badge}
                      </span>
                    )}
                    {option.warning && (
                      <span className="text-xs font-bold bg-red-100 text-red-700 px-2 py-1 rounded">
                        {option.warning}
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-gray-600 italic">{option.subtitle}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Consequence Visualization */}
      <AnimatePresence mode="wait">
        {selected && !timeExpired && (
          <motion.div key={selected} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mt-8">
            <div
              className={`rounded-2xl p-8 border-2 ${
                selected === "backup"
                  ? "bg-green-50 border-green-500"
                  : selected === "paper"
                    ? "bg-red-100 border-red-500"
                    : "bg-orange-50 border-orange-300"
              }`}
            >
              <h4 className="text-xl font-bold mb-4 text-gray-900">📊 Konsekwencje Twojej decyzji:</h4>

              <p className="text-lg mb-6 text-gray-800">
                {crisisOptions.find((o) => o.id === selected)?.consequence.result}
              </p>

              {crisisOptions.find((o) => o.id === selected)?.consequence.fine && (
                <div className="bg-red-200 border-2 border-red-600 rounded-lg p-4 mb-4">
                  <div className="text-red-900 font-bold">
                    💀 KARA FINANSOWA:{" "}
                    {crisisOptions.find((o) => o.id === selected)?.consequence.fine?.toLocaleString()} PLN
                  </div>
                </div>
              )}

              <div className="grid md:grid-cols-3 gap-4 mt-6">
                {Object.entries(crisisOptions.find((o) => o.id === selected)?.consequence || {})
                  .filter(([key]) => !["result", "fine"].includes(key))
                  .map(([key, value]) => (
                    <div key={key} className="bg-white rounded-lg p-4">
                      <div className="text-xs text-gray-600 uppercase mb-1">{getImpactLabel(key)}</div>
                      <div
                        className={`text-2xl font-bold ${typeof value === "number" && value > 0 ? "text-green-600" : "text-red-600"}`}
                      >
                        {typeof value === "number" ? (value > 0 ? "+" : "") + value : value}
                      </div>
                    </div>
                  ))}
              </div>

              <div className="mt-8 text-center">
                <Button size="lg" onClick={handleContinue} className="bg-[var(--ksef-navy)]">
                  {selected === "backup" ? "Profeska! Dalej" : "Rozumiem lekcję"} <ArrowRight className="ml-2" />
                </Button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Time expired */}
      {timeExpired && !selected && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="bg-red-100 border-2 border-red-500 rounded-2xl p-8 text-center"
        >
          <div className="text-5xl mb-4">⏰</div>
          <h3 className="text-2xl font-bold text-red-900 mb-4">Czas minął!</h3>
          <p className="text-lg text-red-800 mb-6">Bez decyzji = chaos. W kryzysie musisz działać SZYBKO.</p>
          <Button onClick={() => handleSelect("backup")} className="bg-red-600 hover:bg-red-700">
            Zobacz prawidłową odpowiedź
          </Button>
        </motion.div>
      )}
    </div>
  )
}
