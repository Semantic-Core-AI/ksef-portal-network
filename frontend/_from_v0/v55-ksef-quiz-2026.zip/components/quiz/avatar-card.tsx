"use client"

import { motion } from "framer-motion"
import { CheckCircle2, type LucideIcon } from "lucide-react"

interface AvatarCardProps {
  id: string
  icon: LucideIcon
  title: string
  subtitle: string
  description: string
  stats: string[]
  trait: string
  superpower: string
  gradient: string
  selected: boolean
  onClick: () => void
}

export function AvatarCard({
  icon: Icon,
  title,
  subtitle,
  description,
  stats,
  trait,
  superpower,
  gradient,
  selected,
  onClick,
}: AvatarCardProps) {
  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      className="cursor-pointer group"
      onClick={onClick}
    >
      <div
        className={`
        bg-gradient-to-br ${gradient} p-1 rounded-2xl
        transition-all duration-300
        ${selected ? "ring-4 ring-[#c7a83b] shadow-2xl" : "hover:shadow-xl"}
      `}
      >
        <div className="bg-white rounded-xl p-6 h-full relative">
          {selected && (
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              className="absolute -top-2 -right-2 w-8 h-8 bg-[#c7a83b] rounded-full flex items-center justify-center shadow-lg"
            >
              <CheckCircle2 className="w-5 h-5 text-white" />
            </motion.div>
          )}

          <div className="flex items-center justify-center mb-4">
            <Icon className="w-16 h-16 text-[#1e2a5e]" strokeWidth={1.5} />
          </div>

          <h3 className="text-xl font-bold text-center mb-2 text-gray-900">{title}</h3>

          <p className="text-sm text-gray-600 text-center mb-4 italic">{subtitle}</p>

          <p className="text-sm text-gray-700 mb-4 leading-relaxed">{description}</p>

          <div className="space-y-2 mb-4">
            {stats.map((stat, i) => (
              <div key={i} className="flex items-center text-xs text-gray-600">
                <CheckCircle2 className="w-4 h-4 mr-2 text-green-500 flex-shrink-0" />
                <span>{stat}</span>
              </div>
            ))}
          </div>

          <div className="border-t pt-4 space-y-2">
            <div className="text-xs">
              <span className="font-semibold text-red-600">{trait}</span>
            </div>
            <div className="text-xs">
              <span className="font-semibold text-green-600">{superpower}</span>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  )
}
