"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { StoryArcIndicator } from "@/components/story-arc-indicator"
import { Button } from "@/components/ui/button"
import { ArrowRight, CheckCircle2, XCircle } from "lucide-react"

interface Question6Props {
  onAnswer: (answer: any) => void
}

const statements = [
  {
    id: "q1",
    statement: "KSeF jest opcjonalny dla mikrofirm",
    answer: "FAŁSZ",
    explanation:
      "Obowiązkowy dla WSZYSTKICH (z nielicznymi wyjątkami). Mikrofirmy mają termin do 2027, ale lepiej przygotować się wcześniej.",
    fact: "📚 Art. 106e ust. 1 ustawy o VAT",
    color: "red",
  },
  {
    id: "q2",
    statement: "Mogę wystawiać papierowe faktury równolegle z KSeF",
    answer: "FAŁSZ",
    explanation: "TYLKO KSeF będzie ważny dla transakcji B2B (z wyjątkami B2C). Papierowe faktury stracą moc prawną.",
    fact: "📚 Po 1 lutego 2026 = tylko elektronicznie",
    color: "red",
  },
  {
    id: "q3",
    statement: "KSeF to tylko zmiana techniczna w systemie",
    answer: "FAŁSZ",
    explanation:
      "To transformacja procesów, szkoleń zespołu i mindset! Technologia to tylko 30%, reszta to ludzie i procesy.",
    fact: "💡 70% firm niedocenia tego aspektu",
    color: "red",
  },
  {
    id: "q4",
    statement: "Mój obecny system księgowy może nie obsługiwać KSeF",
    answer: "PRAWDA",
    explanation: "Starsze wersje systemów wymagają update'u lub wymiany. Excel definitywnie NIE obsłuży KSeF natywnie.",
    fact: "✅ Sprawdź certyfikację MF swojego systemu",
    color: "green",
  },
  {
    id: "q5",
    statement: "Mogę przetestować KSeF w środowisku demo przed go-live",
    answer: "PRAWDA",
    explanation:
      "Ministerstwo Finansów udostępnia środowisko testowe! To KLUCZOWE - tam uczysz się na błędach bez konsekwencji.",
    fact: "🧪 demo.ksef.gov.pl - dostępne już teraz!",
    color: "green",
  },
]

export function Question6({ onAnswer }: Question6Props) {
  const [flippedCards, setFlippedCards] = useState<Set<string>>(new Set())

  const handleFlip = (id: string) => {
    if (!flippedCards.has(id)) {
      setFlippedCards(new Set([...flippedCards, id]))
    }
  }

  const handleContinue = () => {
    onAnswer({ cardsFlipped: flippedCards.size, total: statements.length })
  }

  return (
    <div className="max-w-3xl mx-auto">
      <StoryArcIndicator currentAct="AKT 3: KRYZYS" progress={6} total={8} color="climax" />

      <div className="text-center mb-12">
        <div className="text-5xl mb-4">🧠</div>
        <h2 className="text-3xl font-bold mb-4 text-gray-900">Sprawdź swoją wiedzę</h2>
        <p className="text-lg text-gray-600 mb-2">Kliknij karty aby odkryć prawdę</p>
        <p className="text-sm text-gray-500">(nie oceniamy - tylko edukujemy! 📚)</p>
      </div>

      <div className="space-y-6 mb-12">
        {statements.map((item, index) => (
          <FlipCard
            key={item.id}
            {...item}
            isFlipped={flippedCards.has(item.id)}
            onFlip={() => handleFlip(item.id)}
            delay={index * 0.1}
          />
        ))}
      </div>

      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center">
        <div className="inline-block bg-white rounded-2xl shadow-lg px-12 py-8 border-2 border-[var(--ksef-gold)] mb-8">
          <div className="text-sm text-gray-600 mb-2">Odkryte karty:</div>
          <div className="text-6xl font-black text-[var(--ksef-navy)] mb-2">
            {flippedCards.size}/{statements.length}
          </div>
          <div className="text-sm text-gray-600">
            {flippedCards.size === statements.length ? "🎉 Wszystkie odkryte!" : "Kliknij pozostałe karty"}
          </div>
        </div>

        <Button
          size="lg"
          onClick={handleContinue}
          className="bg-[var(--ksef-gold)] hover:bg-[var(--ksef-gold)]/90 text-white"
          disabled={flippedCards.size < statements.length}
        >
          {flippedCards.size < statements.length ? "Odkryj wszystkie karty" : "Dalej w przygodę"}{" "}
          <ArrowRight className="ml-2" />
        </Button>
      </motion.div>
    </div>
  )
}

function FlipCard({
  statement,
  answer,
  explanation,
  fact,
  color,
  isFlipped,
  onFlip,
  delay,
}: {
  statement: string
  answer: string
  explanation: string
  fact: string
  color: string
  isFlipped: boolean
  onFlip: () => void
  delay: number
}) {
  const handleClick = () => {
    if (!isFlipped) {
      onFlip()
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay }}
      className="perspective-1000"
    >
      <div
        className={`relative h-48 transition-all duration-700 transform-style-3d cursor-pointer ${isFlipped ? "rotate-y-180" : ""}`}
        onClick={handleClick}
        style={{ transformStyle: "preserve-3d" }}
      >
        {/* Front */}
        <div
          className="absolute inset-0 backface-hidden"
          style={{ backfaceVisibility: "hidden", WebkitBackfaceVisibility: "hidden" }}
        >
          <div className="h-full bg-white rounded-xl border-2 border-gray-200 p-6 flex items-center justify-center hover:border-[var(--ksef-navy)] hover:shadow-lg transition-all">
            <div className="text-center">
              <p className="text-xl font-semibold text-gray-800 mb-4">{statement}</p>
              <div className="text-sm text-gray-500">Kliknij aby sprawdzić →</div>
            </div>
          </div>
        </div>

        {/* Back */}
        <div
          className="absolute inset-0 backface-hidden"
          style={{
            backfaceVisibility: "hidden",
            WebkitBackfaceVisibility: "hidden",
            transform: "rotateY(180deg)",
          }}
        >
          <div
            className={`h-full rounded-xl border-2 p-6 ${
              color === "green" ? "bg-green-50 border-green-500" : "bg-red-50 border-red-500"
            }`}
          >
            <div className="flex flex-col h-full">
              <div className="flex items-center justify-center gap-2 mb-4">
                {color === "green" ? (
                  <CheckCircle2 className="w-8 h-8 text-green-700" />
                ) : (
                  <XCircle className="w-8 h-8 text-red-700" />
                )}
                <span className={`text-2xl font-black ${color === "green" ? "text-green-700" : "text-red-700"}`}>
                  {answer === "PRAWDA" ? "PRAWDA" : "FAŁSZ"}
                </span>
              </div>
              <p className="text-sm text-gray-800 mb-3 leading-relaxed">{explanation}</p>
              <div className="mt-auto text-xs text-gray-600 italic">{fact}</div>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  )
}
