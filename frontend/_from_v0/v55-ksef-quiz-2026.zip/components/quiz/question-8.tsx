"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { StoryArcIndicator } from "@/components/story-arc-indicator"
import { Button } from "@/components/ui/button"
import { ArrowRight, Flame, Target, Handshake, Rocket, BookOpen, Frown, MessageCircle } from "lucide-react"
import type { VisionType } from "@/lib/types"

interface Question8Props {
  onAnswer: (answer: VisionType, score?: number) => void
}

const visions = [
  {
    id: "survivor" as VisionType,
    icon: Flame,
    title: "Męczyliśmy się, ale jakoś daliśmy radę",
    subtitle: "Survivor mindset",
    archetype: "THE SURVIVOR",
    personality: "Resilient, pragmatic, ale dużo stresu",
  },
  {
    id: "mentor" as VisionType,
    icon: Target,
    title: "Słuchaj, najważniejsze to NIE CZEKAĆ. Zacznij już. Zaufaj ekspertom.",
    subtitle: "Mentor - dzielisz się wiedzą",
    archetype: "THE PLANNER",
    personality: "Organized, helpful, process-driven",
    badge: "👨‍🏫 Mentor",
  },
  {
    id: "connector" as VisionType,
    icon: Handshake,
    title: "Mamy profesjonalny setup, mogę Cię polecić do naszego dostawcy",
    subtitle: "Collaborator - network thinking",
    archetype: "THE COLLABORATOR",
    personality: "Connected, team-oriented, resourceful",
  },
  {
    id: "innovator" as VisionType,
    icon: Rocket,
    title: "Wiesz co? Nie tylko wdrożyłem KSeF - zautomatyzowałem pół firmy!",
    subtitle: "Innovator - opportunity seeker",
    archetype: "THE INNOVATOR",
    personality: "Forward-thinking, automation-first, visionary",
    badge: "💡 Visionary",
  },
  {
    id: "leader" as VisionType,
    icon: BookOpen,
    title: "Zróbmy razem webinar! Podzielmy się wiedzą z innymi",
    subtitle: "Industry leader - thought leadership",
    archetype: "THE VISIONARY",
    personality: "Inspiring, generous, community-builder",
    badge: "🏆 Leader",
  },
  {
    id: "reluctant" as VisionType,
    icon: Frown,
    title: "Musiałem, ale szczerze? Wolałbym żeby tego nie było...",
    subtitle: "Reluctant - minimum effort",
    archetype: "THE RELUCTANT",
    personality: "Resistance to change, compliance-driven",
  },
]

export function Question8({ onAnswer }: Question8Props) {
  const [selected, setSelected] = useState<VisionType | null>(null)

  const handleSelect = (visionId: VisionType) => {
    setSelected(visionId)
  }

  const handleFinish = () => {
    if (selected) {
      const scoreMap: Record<VisionType, number> = {
        survivor: 15,
        mentor: 25,
        connector: 25,
        innovator: 30,
        leader: 30,
        reluctant: 5,
      }
      onAnswer(selected, scoreMap[selected])
    }
  }

  return (
    <div className="max-w-4xl mx-auto">
      <StoryArcIndicator currentAct="AKT 4: TRANSFORMACJA" progress={8} total={8} color="resolution" />

      {/* Future Vision Header */}
      <div className="text-center mb-12">
        <MessageCircle className="w-20 h-20 mx-auto mb-4 text-purple-600" />
        <h2 className="text-4xl font-bold mb-4 bg-gradient-to-r from-[var(--ksef-navy)] to-purple-600 bg-clip-text text-transparent">
          Rok po wdrożeniu KSeF...
        </h2>
        <p className="text-xl text-gray-700">Spotykasz kolegę przedsiębiorcę. On dopiero zaczyna.</p>
      </div>

      {/* Narrative setup */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-2xl p-8 mb-8 border-2 border-purple-200"
      >
        <div className="flex items-start gap-4">
          <div className="text-4xl">💬</div>
          <div className="flex-1">
            <p className="text-lg font-medium text-gray-800 mb-2">
              Kolega pyta: "Hej, jak Wam poszło z KSeF? Jakieś rady?"
            </p>
            <p className="text-base text-gray-600">Twoja odpowiedź określi Twój archetyp lidera...</p>
          </div>
        </div>
      </motion.div>

      {/* Vision Options */}
      <div className="space-y-4 mb-8">
        {visions.map((vision, index) => (
          <motion.div
            key={vision.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            onClick={() => handleSelect(vision.id)}
            className={`
              cursor-pointer bg-white rounded-2xl p-6 border-2 transition-all duration-300
              ${selected === vision.id ? "border-[var(--ksef-gold)] shadow-xl ring-4 ring-[var(--ksef-gold)]/20" : "border-gray-200 hover:border-gray-300 hover:shadow-lg"}
            `}
          >
            <div className="flex items-start gap-4">
              <vision.icon className="w-10 h-10 flex-shrink-0 text-gray-700" />
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <h3 className="text-lg font-bold text-gray-900">{vision.title}</h3>
                  {vision.badge && (
                    <span className="text-xs font-bold bg-[var(--ksef-gold)]/20 text-[var(--ksef-gold)] px-2 py-1 rounded">
                      {vision.badge}
                    </span>
                  )}
                </div>
                <p className="text-sm text-gray-600 italic mb-2">{vision.subtitle}</p>
                <div className="text-xs text-gray-500">
                  Archetyp: <span className="font-semibold">{vision.archetype}</span> • {vision.personality}
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Selection confirmation */}
      {selected && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center">
          <div className="bg-[var(--ksef-gold)]/10 border-2 border-[var(--ksef-gold)] rounded-2xl p-8">
            {(() => {
              const SelectedIcon = visions.find((v) => v.id === selected)?.icon
              return SelectedIcon ? <SelectedIcon className="w-20 h-20 mx-auto mb-4 text-gray-700" /> : null
            })()}
            <h3 className="text-2xl font-bold mb-2 text-gray-900">
              Wykryto: {visions.find((v) => v.id === selected)?.archetype}
            </h3>
            <p className="text-lg text-gray-700 mb-6">{visions.find((v) => v.id === selected)?.personality}</p>
            <Button
              size="lg"
              onClick={handleFinish}
              className="bg-gradient-to-r from-[var(--ksef-navy)] to-purple-600 hover:from-[var(--ksef-navy)]/90 hover:to-purple-600/90 text-white px-12 py-6 text-xl"
            >
              Pokaż mój pełny profil 🎭 <ArrowRight className="ml-2" />
            </Button>
          </div>
        </motion.div>
      )}
    </div>
  )
}
