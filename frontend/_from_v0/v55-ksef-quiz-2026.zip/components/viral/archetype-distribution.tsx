"use client"

import { motion } from "framer-motion"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts"
import { ARCHETYPES } from "@/lib/constants"
import { TrendingUp, Award } from "lucide-react"

interface ArchetypeDistributionProps {
  userArchetypeId: string
}

const DISTRIBUTION_DATA = [
  { id: "THE_PLANNER", name: "Planner", percentage: 28, count: 349 },
  { id: "THE_COLLABORATOR", name: "Collaborator", percentage: 24, count: 299 },
  { id: "THE_INNOVATOR", name: "Innovator", percentage: 18, count: 224 },
  { id: "THE_SURVIVOR", name: "Survivor", percentage: 15, count: 187 },
  { id: "THE_VISIONARY", name: "Visionary", percentage: 10, count: 125 },
  { id: "THE_RELUCTANT", name: "Reluctant", percentage: 5, count: 63 },
]

export function ArchetypeDistribution({ userArchetypeId }: ArchetypeDistributionProps) {
  const userArchetype = ARCHETYPES.find((a) => a.id === userArchetypeId)
  const userDistribution = DISTRIBUTION_DATA.find((d) => d.id === userArchetypeId)

  const isRare = userDistribution && userDistribution.percentage < 15

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="bg-white rounded-lg shadow-medium p-8"
    >
      <div className="text-center mb-6">
        <h2 className="font-serif text-3xl font-bold text-ksef-navy mb-2">Jakim typem lidera jesteś TY?</h2>
        <p className="text-muted-foreground">
          Rozkład typów liderów wśród {DISTRIBUTION_DATA.reduce((sum, d) => sum + d.count, 0).toLocaleString("pl-PL")}{" "}
          uczestników
        </p>
      </div>

      {isRare && (
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="mb-6 p-4 bg-gradient-to-r from-amber-50 to-orange-50 border-l-4 border-ksef-gold rounded-lg flex items-center gap-3"
        >
          <Award className="w-8 h-8 text-ksef-gold flex-shrink-0" />
          <div>
            <p className="font-bold text-ksef-navy">Gratulacje! Jesteś w elitarnej grupie!</p>
            <p className="text-sm text-muted-foreground">
              Tylko {userDistribution.percentage}% uczestników to {userArchetype?.name}. To rzadki archetyp!
            </p>
          </div>
        </motion.div>
      )}

      <div className="h-80 mb-6">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={DISTRIBUTION_DATA} margin={{ top: 20, right: 30, left: 20, bottom: 60 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
            <XAxis dataKey="name" angle={-45} textAnchor="end" height={80} tick={{ fill: "#64748b", fontSize: 12 }} />
            <YAxis
              label={{ value: "Procent uczestników (%)", angle: -90, position: "insideLeft", fill: "#64748b" }}
              tick={{ fill: "#64748b" }}
            />
            <Tooltip
              content={({ active, payload }) => {
                if (active && payload && payload.length) {
                  const data = payload[0].payload
                  const archetype = ARCHETYPES.find((a) => a.id === data.id)
                  return (
                    <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
                      <p className="font-bold text-ksef-navy mb-1">{archetype?.name}</p>
                      <p className="text-sm text-muted-foreground">
                        {data.percentage}% ({data.count} osób)
                      </p>
                    </div>
                  )
                }
                return null
              }}
            />
            <Bar dataKey="percentage" radius={[8, 8, 0, 0]}>
              {DISTRIBUTION_DATA.map((entry) => {
                const archetype = ARCHETYPES.find((a) => a.id === entry.id)
                const isUser = entry.id === userArchetypeId
                return (
                  <Cell
                    key={entry.id}
                    fill={isUser ? archetype?.color : `${archetype?.color}40`}
                    stroke={isUser ? archetype?.color : "transparent"}
                    strokeWidth={isUser ? 3 : 0}
                  />
                )
              })}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
        <TrendingUp className="w-4 h-4" />
        <span>Dane aktualizowane co godzinę</span>
      </div>
    </motion.div>
  )
}
