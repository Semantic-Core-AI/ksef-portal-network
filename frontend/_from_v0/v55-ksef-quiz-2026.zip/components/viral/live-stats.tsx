"use client"

import { useEffect, useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Flame, Users } from "lucide-react"

export function LiveStats() {
  const [weeklyCount, setWeeklyCount] = useState(1247)
  const [activeNow, setActiveNow] = useState(3)

  useEffect(() => {
    const weeklyInterval = setInterval(() => {
      setWeeklyCount((prev) => prev + Math.floor(Math.random() * 3))
    }, 15000)

    const activeInterval = setInterval(() => {
      setActiveNow(Math.floor(Math.random() * 8) + 1)
    }, 8000)

    return () => {
      clearInterval(weeklyInterval)
      clearInterval(activeInterval)
    }
  }, [])

  return (
    <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-orange-500/10 to-red-500/10 border border-orange-500/20 rounded-full"
      >
        <Flame className="w-5 h-5 text-orange-500" />
        <span className="font-bold text-ksef-navy">
          <AnimatePresence mode="wait">
            <motion.span
              key={weeklyCount}
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: -20, opacity: 0 }}
              transition={{ duration: 0.3 }}
            >
              {weeklyCount.toLocaleString("pl-PL")}
            </motion.span>
          </AnimatePresence>
        </span>
        <span className="text-muted-foreground text-sm">osób wzięło quiz w tym tygodniu</span>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.2 }}
        className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-green-500/10 to-emerald-500/10 border border-green-500/20 rounded-full"
      >
        <div className="relative">
          <Users className="w-5 h-5 text-green-500" />
          <motion.div
            className="absolute -top-1 -right-1 w-2 h-2 bg-green-500 rounded-full"
            animate={{ scale: [1, 1.5, 1] }}
            transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
          />
        </div>
        <span className="font-bold text-ksef-navy">
          <AnimatePresence mode="wait">
            <motion.span
              key={activeNow}
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: -20, opacity: 0 }}
              transition={{ duration: 0.3 }}
            >
              {activeNow}
            </motion.span>
          </AnimatePresence>
        </span>
        <span className="text-muted-foreground text-sm">
          {activeNow === 1 ? "osoba robi" : "osoby robią"} quiz teraz
        </span>
      </motion.div>
    </div>
  )
}
