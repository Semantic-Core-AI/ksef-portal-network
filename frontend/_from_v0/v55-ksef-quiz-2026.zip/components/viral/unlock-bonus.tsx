"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Lock, Unlock, Download, Share2 } from "lucide-react"
import { toast } from "sonner"

interface UnlockBonusProps {
  archetypeName: string
}

export function UnlockBonus({ archetypeName }: UnlockBonusProps) {
  const [unlocked, setUnlocked] = useState(false)

  const handleShare = () => {
    const shareText = `Właśnie odkryłem swój archetyp lidera: ${archetypeName}! Sprawdź quiz Misja KSeF 2026`
    const shareUrl = typeof window !== "undefined" ? window.location.origin : ""

    if (navigator.share) {
      navigator
        .share({
          title: "Misja KSeF 2026",
          text: shareText,
          url: shareUrl,
        })
        .then(() => {
          setUnlocked(true)
          toast.success("Dziękujemy za udostępnienie! PDF odblokowany")
        })
        .catch(() => {
          // User cancelled share
        })
    } else {
      // Fallback - open LinkedIn share
      const linkedinUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareUrl)}`
      window.open(linkedinUrl, "_blank", "width=600,height=400")
      setTimeout(() => {
        setUnlocked(true)
        toast.success("PDF odblokowany! Dziękujemy za udostępnienie")
      }, 2000)
    }
  }

  const handleDownload = () => {
    toast.success("Pobieranie raportu PDF...")
    console.log("[v0] Downloading PDF report for archetype:", archetypeName)
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-gradient-to-br from-amber-50 to-orange-50 border-2 border-ksef-gold rounded-lg p-8"
    >
      <div className="text-center mb-6">
        <div className="inline-flex items-center justify-center w-16 h-16 bg-ksef-gold/20 rounded-full mb-4">
          {unlocked ? <Unlock className="w-8 h-8 text-ksef-gold" /> : <Lock className="w-8 h-8 text-ksef-gold" />}
        </div>
        <h3 className="font-serif text-2xl font-bold text-ksef-navy mb-2">
          {unlocked ? "Bonus odblokowany!" : "Odblokuj pełny raport PDF"}
        </h3>
        <p className="text-muted-foreground">
          {unlocked
            ? "Pobierz szczegółowy raport z planem działania i dodatkowymi insightami"
            : "Udostępnij wynik na LinkedIn aby otrzymać 15-stronicowy raport PDF z planem działania"}
        </p>
      </div>

      {unlocked ? (
        <Button
          onClick={handleDownload}
          size="lg"
          className="w-full bg-ksef-gold hover:bg-ksef-gold/90 text-ksef-navy font-bold"
        >
          <Download className="w-5 h-5 mr-2" />
          Pobierz raport PDF
        </Button>
      ) : (
        <Button
          onClick={handleShare}
          size="lg"
          className="w-full bg-ksef-gold hover:bg-ksef-gold/90 text-ksef-navy font-bold"
        >
          <Share2 className="w-5 h-5 mr-2" />
          Udostępnij na LinkedIn i odbierz PDF
        </Button>
      )}

      {!unlocked && (
        <p className="text-xs text-center text-muted-foreground mt-4">
          Raport zawiera: szczegółowy plan działania, checklisty, timeline wdrożenia, case studies
        </p>
      )}
    </motion.div>
  )
}
