"use client"

import { useState } from "react"
import { Share2, Copy, Check } from "lucide-react"
import { Button } from "@/components/ui/button"

interface SimpleShareProps {
  title: string
  text: string
  url?: string
}

export function SimpleShare({ title, text, url }: SimpleShareProps) {
  const [copied, setCopied] = useState(false)
  const shareUrl = url || (typeof window !== "undefined" ? window.location.href : "")

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title,
          text,
          url: shareUrl,
        })
      } catch (err) {
        console.log("Share cancelled")
      }
    } else {
      handleCopy()
    }
  }

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(`${text}\n\n${shareUrl}`)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch (err) {
      console.error("Failed to copy")
    }
  }

  return (
    <div className="flex gap-2">
      <Button onClick={handleShare} variant="outline" className="gap-2 bg-transparent">
        <Share2 className="w-4 h-4" />
        Udostępnij
      </Button>
      <Button onClick={handleCopy} variant="outline" size="icon">
        {copied ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
      </Button>
    </div>
  )
}
