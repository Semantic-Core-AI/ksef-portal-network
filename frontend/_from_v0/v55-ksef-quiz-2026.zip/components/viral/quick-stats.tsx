"use client"

import { motion } from "framer-motion"
import { Users, TrendingUp, Award } from "lucide-react"

export function QuickStats() {
  // Mock data - w produkcji z API
  const stats = {
    totalUsers: 1247,
    thisWeek: 342,
    topArchetype: "Innowator",
  }

  return (
    <div className="grid grid-cols-3 gap-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="bg-white/5 backdrop-blur-sm rounded-xl p-4 border border-white/10"
      >
        <Users className="w-5 h-5 text-blue-400 mb-2" />
        <div className="text-2xl font-bold text-white">{stats.totalUsers.toLocaleString()}</div>
        <div className="text-xs text-white/60">Użytkowników</div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="bg-white/5 backdrop-blur-sm rounded-xl p-4 border border-white/10"
      >
        <TrendingUp className="w-5 h-5 text-green-400 mb-2" />
        <div className="text-2xl font-bold text-white">{stats.thisWeek}</div>
        <div className="text-xs text-white/60">W tym tygodniu</div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="bg-white/5 backdrop-blur-sm rounded-xl p-4 border border-white/10"
      >
        <Award className="w-5 h-5 text-yellow-400 mb-2" />
        <div className="text-lg font-bold text-white">{stats.topArchetype}</div>
        <div className="text-xs text-white/60">Najpopularniejszy</div>
      </motion.div>
    </div>
  )
}
