"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { UserPlus, Send, Copy, CheckCircle2 } from "lucide-react"
import { toast } from "sonner"

interface ChallengeColleagueProps {
  archetypeName: string
  userScore: number
}

export function ChallengeColleague({ archetypeName, userScore }: ChallengeColleagueProps) {
  const [open, setOpen] = useState(false)
  const [email, setEmail] = useState("")
  const [message, setMessage] = useState(
    `Cześć! Właśnie ukończyłem quiz "Misja KSeF 2026" i odkryłem, że jestem ${archetypeName}. Ciekawe, jaki archetyp lidera jesteś Ty? Sprawdź się i porównajmy wyniki!`,
  )
  const [sent, setSent] = useState(false)

  const challengeUrl = typeof window !== "undefined" ? `${window.location.origin}?ref=challenge` : ""

  const handleSend = () => {
    console.log("[v0] Sending challenge to:", email)
    setSent(true)
    toast.success("Wyzwanie wysłane!")
    setTimeout(() => {
      setOpen(false)
      setSent(false)
      setEmail("")
    }, 2000)
  }

  const handleCopyLink = () => {
    navigator.clipboard.writeText(challengeUrl)
    toast.success("Link skopiowany do schowka!")
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="lg" className="bg-gradient-to-r from-ksef-blue to-ksef-navy hover:opacity-90 text-white">
          <UserPlus className="w-5 h-5 mr-2" />
          Wyzwij kolegę
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-serif text-2xl text-ksef-navy">Wyzwij kolegę do quizu</DialogTitle>
        </DialogHeader>

        <AnimatePresence mode="wait">
          {!sent ? (
            <motion.div
              key="form"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-4"
            >
              <div>
                <label className="text-sm font-medium text-ksef-navy mb-2 block">Email kolegi</label>
                <Input
                  type="email"
                  placeholder="jan.kowalski@firma.pl"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="border-gray-300"
                />
              </div>

              <div>
                <label className="text-sm font-medium text-ksef-navy mb-2 block">Wiadomość</label>
                <Textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  rows={4}
                  className="border-gray-300 resize-none"
                />
              </div>

              <div className="flex gap-2">
                <Button onClick={handleSend} disabled={!email} className="flex-1 bg-ksef-blue hover:bg-ksef-blue/90">
                  <Send className="w-4 h-4 mr-2" />
                  Wyślij wyzwanie
                </Button>
                <Button
                  onClick={handleCopyLink}
                  variant="outline"
                  className="border-ksef-navy text-ksef-navy bg-transparent"
                >
                  <Copy className="w-4 h-4" />
                </Button>
              </div>

              <p className="text-xs text-muted-foreground text-center">Lub skopiuj link i wyślij samodzielnie</p>
            </motion.div>
          ) : (
            <motion.div
              key="success"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              className="py-8 text-center"
            >
              <CheckCircle2 className="w-16 h-16 text-green-500 mx-auto mb-4" />
              <h3 className="font-bold text-xl text-ksef-navy mb-2">Wyzwanie wysłane!</h3>
              <p className="text-muted-foreground">Twój kolega otrzymał zaproszenie do quizu</p>
            </motion.div>
          )}
        </AnimatePresence>
      </DialogContent>
    </Dialog>
  )
}
