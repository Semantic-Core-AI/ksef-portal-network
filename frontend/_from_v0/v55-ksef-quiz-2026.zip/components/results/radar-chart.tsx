"use client"

import { Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, ResponsiveContainer, Legend } from "recharts"
import { Card } from "@/components/ui/card"
import type { QuizScores } from "@/lib/types"

interface RadarChartComponentProps {
  scores: QuizScores
  color: string
}

export function RadarChartComponent({ scores, color }: RadarChartComponentProps) {
  const data = [
    {
      dimension: "Wiedza",
      value: scores.knowledge,
      average: 65,
      fullMark: 100,
    },
    {
      dimension: "Przygotowanie",
      value: scores.preparation,
      average: 60,
      fullMark: 100,
    },
    {
      dimension: "Technologia",
      value: scores.technology,
      average: 55,
      fullMark: 100,
    },
    {
      dimension: "Zespół",
      value: scores.team,
      average: 70,
      fullMark: 100,
    },
    {
      dimension: "Mindset",
      value: scores.mindset,
      average: 60,
      fullMark: 100,
    },
  ]

  const totalUser = data.reduce((sum, item) => sum + item.value, 0)
  const totalAverage = data.reduce((sum, item) => sum + item.average, 0)
  const difference = totalUser - totalAverage
  const percentDiff = Math.round((difference / totalAverage) * 100)

  const getBenchmarkText = () => {
    if (percentDiff > 20) {
      return {
        text: "Jesteś znacznie powyżej średniej!",
        subtext: `Twoje kompetencje są o ${percentDiff}% wyższe niż przeciętnego uczestnika. Gratulacje!`,
        color: "text-green-600",
      }
    } else if (percentDiff > 0) {
      return {
        text: "Jesteś powyżej średniej",
        subtext: `Twoje wyniki są o ${percentDiff}% lepsze od średniej. Dobra robota!`,
        color: "text-blue-600",
      }
    } else if (percentDiff > -20) {
      return {
        text: "Jesteś blisko średniej",
        subtext: `Masz solidne podstawy. Kilka ulepszeń i będziesz w czołówce!`,
        color: "text-amber-600",
      }
    } else {
      return {
        text: "Jest przestrzeń do rozwoju",
        subtext: `Nie martw się - każdy zaczynał od podstaw. Skup się na action plan!`,
        color: "text-orange-600",
      }
    }
  }

  const benchmark = getBenchmarkText()

  return (
    <Card className="p-6 shadow-medium">
      <h3 className="font-serif text-2xl font-bold text-ksef-navy mb-2 text-center">Twój profil kompetencji</h3>
      <p className="text-sm text-muted-foreground text-center mb-6">
        Porównanie Twoich wyników ze średnią innych uczestników
      </p>
      <ResponsiveContainer width="100%" height={400}>
        <RadarChart data={data}>
          <PolarGrid stroke="#e5e7eb" strokeWidth={1} />
          <PolarAngleAxis
            dataKey="dimension"
            tick={{ fill: "#1e2a5e", fontSize: 14, fontWeight: 600, fontFamily: "Inter" }}
          />
          <PolarRadiusAxis angle={90} domain={[0, 100]} tick={{ fill: "#6b7280", fontSize: 12 }} tickCount={6} />
          <Radar
            name="Średnia"
            dataKey="average"
            stroke="#9ca3af"
            fill="#9ca3af"
            fillOpacity={0.2}
            strokeWidth={2}
            strokeDasharray="5 5"
          />
          <Radar name="Twoje wyniki" dataKey="value" stroke={color} fill={color} fillOpacity={0.6} strokeWidth={3} />
          <Legend wrapperStyle={{ paddingTop: "20px" }} iconType="circle" />
        </RadarChart>
      </ResponsiveContainer>

      <div className="mt-6 p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg border border-blue-200">
        <div className={`text-lg font-bold ${benchmark.color} mb-1`}>{benchmark.text}</div>
        <div className="text-sm text-gray-600">{benchmark.subtext}</div>
      </div>

      <div className="mt-6 grid grid-cols-5 gap-4">
        {data.map((item) => (
          <div key={item.dimension} className="text-center">
            <div className="text-2xl font-bold mb-1" style={{ color }}>
              {item.value}
            </div>
            <div className="text-xs text-muted-foreground mb-1">{item.dimension}</div>
            <div className="text-xs text-gray-400">śr: {item.average}</div>
          </div>
        ))}
      </div>
    </Card>
  )
}
