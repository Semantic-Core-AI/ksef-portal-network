"use client"

import { Button } from "@/components/ui/button"
import { Facebook, Linkedin, Twitter, Share2 } from "lucide-react"
import { toast } from "sonner"

interface SocialShareProps {
  archetypeName: string
}

export function SocialShare({ archetypeName }: SocialShareProps) {
  const shareText = `Właśnie odkryłem swój archetyp lidera w quizie Misja KSeF 2026! Jestem ${archetypeName}. Sprawdź, jaki jesteś Ty!`
  const shareUrl = typeof window !== "undefined" ? window.location.origin : ""

  const handleShare = (platform: string) => {
    let url = ""

    switch (platform) {
      case "linkedin":
        url = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareUrl)}`
        break
      case "facebook":
        url = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}&quote=${encodeURIComponent(shareText)}`
        break
      case "twitter":
        url = `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(shareUrl)}`
        break
      case "copy":
        navigator.clipboard.writeText(`${shareText} ${shareUrl}`)
        toast.success("Link skopiowany do schowka!")
        return
    }

    if (url) {
      window.open(url, "_blank", "width=600,height=400")
    }
  }

  return (
    <div className="space-y-4">
      <h3 className="font-serif text-xl font-bold text-ksef-navy text-center">Podziel się wynikami</h3>
      <div className="flex flex-wrap justify-center gap-3">
        <Button onClick={() => handleShare("linkedin")} className="bg-[#0077b5] hover:bg-[#006399] text-white">
          <Linkedin className="w-4 h-4 mr-2" />
          LinkedIn
        </Button>
        <Button onClick={() => handleShare("facebook")} className="bg-[#1877f2] hover:bg-[#0c63d4] text-white">
          <Facebook className="w-4 h-4 mr-2" />
          Facebook
        </Button>
        <Button onClick={() => handleShare("twitter")} className="bg-[#1da1f2] hover:bg-[#0c85d0] text-white">
          <Twitter className="w-4 h-4 mr-2" />
          Twitter
        </Button>
        <Button
          onClick={() => handleShare("copy")}
          variant="outline"
          className="border-ksef-navy text-ksef-navy hover:bg-ksef-navy hover:text-white"
        >
          <Share2 className="w-4 h-4 mr-2" />
          Kopiuj link
        </Button>
      </div>
    </div>
  )
}
