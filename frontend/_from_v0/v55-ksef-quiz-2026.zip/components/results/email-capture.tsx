"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { FileDown, Mail, CheckCircle2 } from "lucide-react"
import { toast } from "sonner"

interface EmailCaptureProps {
  archetypeName: string
}

export function EmailCapture({ archetypeName }: EmailCaptureProps) {
  const [email, setEmail] = useState("")
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      toast.error("Podaj prawidłowy adres email")
      return
    }

    setIsLoading(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500))

    setIsSubmitted(true)
    setIsLoading(false)
    toast.success("Dziękujemy! Sprawdź swoją skrzynkę email.")
  }

  if (isSubmitted) {
    return (
      <Card className="p-8 bg-gradient-to-br from-green-50 to-emerald-50 border-green-200">
        <div className="text-center space-y-4">
          <div className="flex justify-center">
            <div className="p-4 bg-green-100 rounded-full">
              <CheckCircle2 className="w-12 h-12 text-green-600" />
            </div>
          </div>
          <h3 className="font-serif text-2xl font-bold text-ksef-navy">Dziękujemy!</h3>
          <p className="text-muted-foreground leading-relaxed">
            Twój spersonalizowany raport PDF został wysłany na adres <strong>{email}</strong>. Sprawdź swoją skrzynkę
            email (również spam).
          </p>
        </div>
      </Card>
    )
  }

  return (
    <Card className="p-8 bg-gradient-to-br from-ksef-navy/5 to-ksef-gold/5">
      <div className="space-y-6">
        <div className="text-center space-y-2">
          <div className="flex justify-center mb-4">
            <div className="p-4 bg-ksef-gold/20 rounded-full">
              <FileDown className="w-10 h-10 text-ksef-gold" />
            </div>
          </div>
          <h3 className="font-serif text-2xl font-bold text-ksef-navy">Pobierz szczegółowy raport PDF</h3>
          <p className="text-muted-foreground leading-relaxed">
            Otrzymaj spersonalizowany plan działania dla archetypu <strong>{archetypeName}</strong> z konkretnymi
            krokami przygotowania do KSeF 2026.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="flex-1 relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input
                type="email"
                placeholder="twoj@email.pl"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="pl-10 h-12"
                required
              />
            </div>
            <Button
              type="submit"
              disabled={isLoading}
              className="bg-ksef-gold hover:bg-ksef-gold/90 text-ksef-navy font-semibold h-12 px-8"
            >
              {isLoading ? (
                <>
                  <span className="animate-spin mr-2">⏳</span>
                  Wysyłanie...
                </>
              ) : (
                <>
                  <FileDown className="w-4 h-4 mr-2" />
                  Pobierz raport
                </>
              )}
            </Button>
          </div>
          <p className="text-xs text-muted-foreground text-center">
            Twoje dane są bezpieczne. Nie spamujemy. Możesz wypisać się w każdej chwili.
          </p>
        </form>
      </div>
    </Card>
  )
}
