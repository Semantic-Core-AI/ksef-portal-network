"use client"

import { motion } from "framer-motion"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import type { Archetype } from "@/lib/types"

interface ArchetypeCardProps {
  archetype: Archetype
  isHighlighted?: boolean
}

export function ArchetypeCard({ archetype, isHighlighted = false }: ArchetypeCardProps) {
  const Icon = archetype.icon

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
      <Card
        className={`p-6 transition-all duration-300 ${
          isHighlighted ? "ring-2 ring-[#c7a83b] shadow-xl scale-105" : "hover:shadow-lg"
        }`}
        style={{
          backgroundColor: isHighlighted ? `${archetype.color}15` : undefined,
        }}
      >
        <div className="flex items-start gap-4">
          <div className="p-3 rounded-lg" style={{ backgroundColor: `${archetype.color}20` }}>
            <Icon className="w-6 h-6" style={{ color: archetype.color }} strokeWidth={1.5} />
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <h3 className="font-serif text-2xl font-bold text-[#1e2a5e]">{archetype.name}</h3>
              {isHighlighted && <Badge className="bg-[#c7a83b] text-[#1e2a5e]">Twój typ</Badge>}
            </div>
            <p className="text-gray-600 italic leading-relaxed mb-4">{archetype.tagline}</p>
            <div className="space-y-3">
              <div>
                <h4 className="font-semibold text-sm text-[#1e2a5e] mb-2">Mocne strony:</h4>
                <ul className="space-y-1">
                  {archetype.strengths.map((strength, i) => (
                    <li key={i} className="text-sm text-gray-600 flex items-start">
                      <span className="mr-2">•</span>
                      <span>{strength}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-sm text-[#1e2a5e] mb-2">Do poprawy:</h4>
                <ul className="space-y-1">
                  {archetype.improvements.map((improvement, i) => (
                    <li key={i} className="text-sm text-gray-600 flex items-start">
                      <span className="mr-2">•</span>
                      <span>{improvement}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </Card>
    </motion.div>
  )
}
