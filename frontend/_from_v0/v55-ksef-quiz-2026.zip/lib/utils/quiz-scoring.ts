import type { QuizAnswer, QuizScores } from "../types"
import { ARCHETYPES } from "../constants"

export function calculateArchetype(answers: Record<number, QuizAnswer>): QuizScores {
  const dimensions = calculateDimensions(answers)
  const totalScore = calculateTotalScore(answers)

  // Calculate distance to each archetype
  const distances = ARCHETYPES.map((archetype) => {
    const distance = calculateDistance(dimensions, archetype.dimensions)
    return { archetype: archetype.id, distance }
  })

  // Return closest archetype with full scores
  distances.sort((a, b) => a.distance - b.distance)

  return {
    archetype: distances[0].archetype,
    knowledge: dimensions.knowledge,
    preparation: dimensions.preparation,
    technology: dimensions.technology,
    team: dimensions.team,
    mindset: dimensions.mindset,
    totalScore,
  }
}

function calculateDimensions(answers: Record<number, QuizAnswer>) {
  const dimensions = {
    knowledge: 50,
    preparation: 50,
    technology: 50,
    team: 50,
    mindset: 50,
  }

  // Q1: Avatar - affects preparation and team
  if (answers[1]) {
    const avatar = answers[1].answer
    if (avatar === "startup_ninja") {
      dimensions.mindset += 20
      dimensions.preparation -= 10
      dimensions.technology += 10
    } else if (avatar === "corporation") {
      dimensions.preparation += 20
      dimensions.team += 15
      dimensions.technology += 10
    } else if (avatar === "oldschool") {
      dimensions.mindset -= 20
      dimensions.knowledge -= 15
      dimensions.technology -= 25
    } else if (avatar === "freelancer_solo") {
      dimensions.team -= 15
      dimensions.mindset += 10
    } else if (avatar === "family_biz") {
      dimensions.team += 10
      dimensions.mindset -= 10
    } else if (avatar === "rising_star") {
      dimensions.mindset += 15
      dimensions.technology += 15
    }
  }

  // Q2: Knowledge ranking - affects knowledge dimension
  if (answers[2]) {
    const score = answers[2].score || 0
    dimensions.knowledge = Math.min(100, 30 + score)
  }

  // Q3: System choice - affects preparation and technology
  if (answers[3]) {
    const system = answers[3].answer
    if (system === "comarch" || system === "symfonia") {
      dimensions.preparation += 15
      dimensions.technology += 10
    } else if (system === "sap") {
      dimensions.technology += 20
      dimensions.preparation += 10
    } else if (system === "excel" || system === "none") {
      dimensions.preparation -= 20
      dimensions.technology -= 15
    }
  }

  // Q4: Deadline - affects preparation and mindset
  if (answers[4]) {
    const deadline = answers[4].answer
    if (deadline === "november" || deadline === "december") {
      dimensions.preparation += 20
      dimensions.mindset += 10
    } else if (deadline === "late_january" || deadline === "after_deadline") {
      dimensions.preparation -= 25
      dimensions.mindset -= 15
    }
  }

  // Q5: Team - affects team dimension
  if (answers[5]) {
    const team = answers[5].answer
    if (team === "solo") {
      dimensions.team -= 20
    } else if (team === "department") {
      dimensions.team += 25
    } else if (team === "outsourced") {
      dimensions.team += 20
      dimensions.preparation += 10
    } else if (team === "small") {
      dimensions.team += 10
    }
  }

  // Q6: Knowledge quiz - affects knowledge
  if (answers[6]) {
    const result = answers[6].answer
    const score = result?.score || 0
    dimensions.knowledge += (score / 5) * 30
  }

  // Q7: Crisis - affects mindset and preparation
  if (answers[7]) {
    const crisis = answers[7].answer
    if (crisis === "backup") {
      dimensions.mindset += 25
      dimensions.preparation += 15
    } else if (crisis === "panic") {
      dimensions.mindset -= 20
    } else if (crisis === "paper") {
      dimensions.mindset -= 30
      dimensions.knowledge -= 20
    } else if (crisis === "wait") {
      dimensions.mindset -= 10
    }
  }

  // Q8: Vision - affects mindset and team
  if (answers[8]) {
    const vision = answers[8].answer
    if (vision === "leader") {
      dimensions.mindset += 30
      dimensions.team += 15
    } else if (vision === "innovator") {
      dimensions.mindset += 30
      dimensions.technology += 20
    } else if (vision === "mentor") {
      dimensions.mindset += 20
      dimensions.team += 10
    } else if (vision === "connector") {
      dimensions.team += 20
      dimensions.mindset += 15
    } else if (vision === "reluctant") {
      dimensions.mindset -= 25
    } else if (vision === "survivor") {
      dimensions.mindset += 5
    }
  }

  // Clamp all values between 0 and 100
  Object.keys(dimensions).forEach((key) => {
    dimensions[key as keyof typeof dimensions] = Math.max(0, Math.min(100, dimensions[key as keyof typeof dimensions]))
  })

  return dimensions
}

function calculateDistance(a: (typeof ARCHETYPES)[0]["dimensions"], b: (typeof ARCHETYPES)[0]["dimensions"]): number {
  return Math.sqrt(
    Math.pow(a.knowledge - b.knowledge, 2) +
      Math.pow(a.preparation - b.preparation, 2) +
      Math.pow(a.technology - b.technology, 2) +
      Math.pow(a.team - b.team, 2) +
      Math.pow(a.mindset - b.mindset, 2),
  )
}

export function calculateTotalScore(answers: Record<number, QuizAnswer>): number {
  return Object.values(answers).reduce((sum, answer) => sum + (answer.score || 0), 0)
}
