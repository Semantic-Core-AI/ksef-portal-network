import { create } from "zustand"
import { persist } from "zustand/middleware"
import type { QuizState, QuizAnswer, QuestionId, ArchetypeType, UserProfile, StreakData } from "./types"
import { analyzeUserProfile } from "./profileAnalyzer"
import { calculateStreak } from "./streakUtils"

interface QuizStore extends QuizState {
  setAnswer: (questionId: QuestionId, answer: any, score?: number) => void
  nextQuestion: () => void
  previousQuestion: () => void
  setArchetype: (archetype: ArchetypeType) => void
  startQuiz: () => void
  completeQuiz: () => void
  resetQuiz: () => void
  userProfile: UserProfile | null
  updateUserProfile: () => void
  streakData: StreakData
  updateStreak: () => void
  completeDailyChallenge: () => void
}

const initialState: QuizState = {
  currentQuestion: 1,
  answers: {} as Record<QuestionId, QuizAnswer>,
  totalScore: 0,
  archetype: null,
  startedAt: null,
  completedAt: null,
}

const initialStreakData: StreakData = {
  currentStreak: 0,
  longestStreak: 0,
  lastVisitDate: null,
  dailyChallengeCompleted: false,
  dailyChallengeDate: null,
  totalVisits: 0,
  milestones: {
    day7: false,
    day30: false,
    day90: false,
  },
}

export const useQuizStore = create<QuizStore>()(
  persist(
    (set, get) => ({
      ...initialState,
      userProfile: null,
      streakData: initialStreakData,

      setAnswer: (questionId, answer, score = 0) => {
        set((state) => {
          const newAnswer: QuizAnswer = {
            questionId,
            answer,
            score,
            timestamp: Date.now(),
          }

          return {
            answers: {
              ...state.answers,
              [questionId]: newAnswer,
            },
            totalScore: state.totalScore + score,
          }
        })
        get().updateUserProfile()
      },

      nextQuestion: () => {
        set((state) => ({
          currentQuestion: Math.min(8, state.currentQuestion + 1) as QuestionId,
        }))
      },

      previousQuestion: () => {
        set((state) => ({
          currentQuestion: Math.max(1, state.currentQuestion - 1) as QuestionId,
        }))
      },

      setArchetype: (archetype) => {
        set({ archetype })
      },

      startQuiz: () => {
        set({ startedAt: Date.now() })
      },

      completeQuiz: () => {
        set({ completedAt: Date.now() })
      },

      updateUserProfile: () => {
        const answers = get().answers
        const profile = analyzeUserProfile(answers)
        set({ userProfile: profile })
      },

      updateStreak: () => {
        const currentStreakData = get().streakData
        const newStreakData = calculateStreak(currentStreakData)
        set({ streakData: newStreakData })
      },

      completeDailyChallenge: () => {
        const today = new Date().toISOString().split("T")[0]
        set((state) => ({
          streakData: {
            ...state.streakData,
            dailyChallengeCompleted: true,
            dailyChallengeDate: today,
          },
        }))
      },

      resetQuiz: () => {
        set({ ...initialState, userProfile: null })
      },
    }),
    {
      name: "ksef-quiz-storage",
    },
  ),
)
