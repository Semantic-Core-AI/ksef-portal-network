import type { Archetype } from "./types"
import {
  Flame,
  Target,
  Rocket,
  Handshake,
  Frown,
  Trophy,
  BarChart3,
  Building2,
  FileText,
  CheckCircle2,
  ThumbsUp,
  Clock,
  AlertTriangle,
  Skull,
  Zap,
} from "lucide-react"

export const KSEF_DEADLINE = new Date("2026-02-01T00:00:00")

export const COLORS = {
  brand: {
    navy: "#1e3a5f",
    gold: "#d4af37",
    lightNavy: "#2d5a8f",
  },
  bg: {
    main: "#f8f9fa",
    card: "#ffffff",
    muted: "#f1f3f5",
  },
  arc: {
    setup: "#3b82f6",
    conflict: "#f59e0b",
    climax: "#ef4444",
    resolution: "#10b981",
  },
  archetypes: {
    survivor: "#f59e0b",
    planner: "#3b82f6",
    innovator: "#8b5cf6",
    collaborator: "#10b981",
    reluctant: "#6b7280",
    visionary: "#d4af37",
  },
} as const

export const ARCHETYPES: Archetype[] = [
  {
    id: "THE_SURVIVOR",
    name: "WOJOWNIK",
    tagline: "Przetrwałem gorsze rzeczy",
    icon: Flame,
    color: COLORS.archetypes.survivor,
    gradient: "from-orange-500 to-red-500",
    strengths: [
      "Nie poddajesz się łatwo",
      "Radzisz sobie w trudnych sytuacjach",
      "Masz stalowe nerwy",
      "Praktycznie myślisz",
    ],
    improvements: [
      "Zacznij planować wcześniej - będzie łatwiej",
      "Poproś kogoś o pomoc - nie musisz sam",
      "Zapobiegaj problemom zanim się pojawią",
      "Odpoczywaj czasem - wypalenie nie pomaga",
    ],
    actionPlan: [
      {
        title: "Przygotuj plan B",
        description: "Co zrobisz gdy coś pójdzie nie tak? Lepiej wiedzieć wcześniej niż improwizować.",
      },
      {
        title: "Znajdź kogoś kto pomoże",
        description: "Ekspert oszczędzi Ci mnóstwo nerwów i czasu. To się opłaca.",
      },
      {
        title: "Zautomatyzuj co się da",
        description: "Niech komputer robi nudne rzeczy, Ty zajmij się ważnymi sprawami.",
      },
    ],
    testimonials: [
      {
        avatar: "👨‍💼",
        name: "Marek K.",
        company: "Firma Transportowa",
        quote: "Było ciężko, ale dałem radę. Następnym razem zacznę wcześniej!",
      },
      {
        avatar: "👩‍💼",
        name: "Anna W.",
        company: "Sklep",
        quote: "Stres był ogromny, ale przeżyłam. Teraz już wiem jak to robić.",
      },
      {
        avatar: "👨‍🔧",
        name: "Piotr S.",
        company: "Budowlanka",
        quote: "Sam to ogarniałem - nie polecam, ale się udało.",
      },
    ],
    dimensions: {
      knowledge: 45,
      preparation: 40,
      technology: 35,
      team: 35,
      mindset: 50,
    },
  },
  {
    id: "THE_PLANNER",
    name: "PLANISTA",
    tagline: "Przygotowanie to połowa sukcesu",
    icon: Target,
    color: COLORS.archetypes.planner,
    gradient: "from-blue-500 to-cyan-500",
    strengths: [
      "Wszystko masz poukładane",
      "Robisz rzeczy krok po kroku",
      "Widzisz problemy zanim się pojawią",
      "Wszystko zapisujesz i dokumentujesz",
    ],
    improvements: [
      "Czasem trzeba zmienić plan - to OK",
      "Nie wszystko da się przewidzieć - pogódź się z tym",
      "Podejmuj decyzje szybciej, nie czekaj na ideał",
      "Zaufaj ludziom - nie musisz wszystkiego kontrolować",
    ],
    actionPlan: [
      {
        title: "Rozpisz wszystko na kartce",
        description: "Kto, co, kiedy. Im bardziej szczegółowo, tym lepiej będziesz spać.",
      },
      {
        title: "Zrób listy kontrolne",
        description: "Dla każdego kroku. Wtedy nic nie umknie i wszyscy wiedzą co robić.",
      },
      {
        title: "Dodaj zapas czasu",
        description: "Zawsze coś wyskoczy. Dodaj 20% więcej czasu niż myślisz że potrzebujesz.",
      },
    ],
    testimonials: [
      {
        avatar: "👨‍💼",
        name: "Tomasz L.",
        company: "Firma Doradcza",
        quote: "Plan był kluczem. Wszyscy wiedzieli co robić. Zero stresu.",
      },
      {
        avatar: "👩‍💼",
        name: "Katarzyna M.",
        company: "Firma IT",
        quote: "Zaczęliśmy pół roku wcześniej. Wszystko poszło gładko.",
      },
      {
        avatar: "👨‍🔧",
        name: "Michał B.",
        company: "Fabryka",
        quote: "Każdy wiedział swoją rolę. Profesjonalizm się opłacił.",
      },
    ],
    dimensions: {
      knowledge: 85,
      preparation: 95,
      technology: 70,
      team: 70,
      mindset: 75,
    },
  },
  {
    id: "THE_INNOVATOR",
    name: "INNOWATOR",
    tagline: "Zmiana to szansa",
    icon: Rocket,
    color: COLORS.archetypes.innovator,
    gradient: "from-purple-500 to-pink-500",
    strengths: [
      "Widzisz możliwości tam gdzie inni widzą problemy",
      "Nowe technologie Cię kręcą",
      "Kreatywnie rozwiązujesz problemy",
      "Automatyzujesz i usprawniasz wszystko",
    ],
    improvements: [
      "Nie wszystko musi być najnowsze - czasem sprawdzone jest lepsze",
      "Sprawdź czy zespół nadąża za Twoimi pomysłami",
      "Realistycznie szacuj czas i koszty",
      "Wytłumacz innym dlaczego to fajne - nie wszyscy to widzą",
    ],
    actionPlan: [
      {
        title: "Wykorzystaj KSeF do automatyzacji",
        description: "Połącz z innymi programami - zbuduj system który działa sam!",
      },
      {
        title: "Testuj w bezpiecznym miejscu",
        description: "Wypróbuj różne scenariusze zanim uruchomisz na prawdziwych danych.",
      },
      {
        title: "Podziel się wiedzą",
        description: "Napisz artykuł lub wystąp na konferencji - zbuduj swoją markę eksperta.",
      },
    ],
    testimonials: [
      {
        avatar: "👨‍💻",
        name: "Jakub P.",
        company: "Startup",
        quote: "KSeF był pretekstem do zautomatyzowania całej księgowości. Wow!",
      },
      {
        avatar: "👩‍💻",
        name: "Monika R.",
        company: "Sklep Internetowy",
        quote: "Nie tylko KSeF - zbudowaliśmy inteligentny system fakturowania!",
      },
      {
        avatar: "👨‍🔬",
        name: "Adam K.",
        company: "Software House",
        quote: "Wykorzystaliśmy API KSeF do własnego dashboardu. Game changer!",
      },
    ],
    dimensions: {
      knowledge: 90,
      preparation: 80,
      technology: 95,
      team: 75,
      mindset: 95,
    },
  },
  {
    id: "THE_COLLABORATOR",
    name: "WSPÓŁPRACOWNIK",
    tagline: "Razem jest lepiej",
    icon: Handshake,
    color: COLORS.archetypes.collaborator,
    gradient: "from-green-500 to-emerald-500",
    strengths: [
      "Budujesz świetne relacje z ludźmi",
      "Dobrze się komunikujesz",
      "Masz sieć kontaktów która pomaga",
      "Dzielisz się wiedzą i pomagasz innym",
    ],
    improvements: [
      "Czasem musisz sam podjąć decyzję",
      "Naucz się więcej o technologii",
      "Bądź bardziej stanowczy w rozmowach",
      "Działaj z własnej inicjatywy, nie czekaj",
    ],
    actionPlan: [
      {
        title: "Zbierz zespół",
        description: "Księgowość, IT, szef - wszyscy muszą być w temacie i zaangażowani.",
      },
      {
        title: "Znajdź dobrego partnera",
        description: "Certyfikowany dostawca programu to klucz - nie oszczędzaj na wsparciu.",
      },
      {
        title: "Spotykajcie się regularnie",
        description: "Co tydzień status projektu - przejrzystość buduje zaufanie w zespole.",
      },
    ],
    testimonials: [
      {
        avatar: "👨‍💼",
        name: "Robert N.",
        company: "Firma Rodzinna",
        quote: "Cały zespół był zaangażowany. To był nasz wspólny sukces!",
      },
      {
        avatar: "👩‍💼",
        name: "Ewa T.",
        company: "Agencja Marketingowa",
        quote: "Partner ogarniał technikalia, my skupiliśmy się na biznesie.",
      },
      {
        avatar: "👨‍🏫",
        name: "Paweł D.",
        company: "Doradztwo",
        quote: "Znajomości się opłaciły - porady od innych firm były bezcenne.",
      },
    ],
    dimensions: {
      knowledge: 70,
      preparation: 75,
      technology: 65,
      team: 95,
      mindset: 80,
    },
  },
  {
    id: "THE_RELUCTANT",
    name: "SCEPTYK",
    tagline: "Musiałem, więc zrobiłem",
    icon: Frown,
    color: COLORS.archetypes.reluctant,
    gradient: "from-gray-500 to-gray-700",
    strengths: [
      "Robisz to co trzeba",
      "Przestrzegasz przepisów",
      "Oszczędzasz gdzie się da",
      "Praktycznie podchodzisz do spraw",
    ],
    improvements: [
      "Pomyśl o przyszłości, nie tylko o dzisiaj",
      "Zobacz co dobrego może z tego wyniknąć",
      "Czasem warto zainwestować w rozwój",
      "Spróbuj być otwarty na nowe rzeczy",
    ],
    actionPlan: [
      {
        title: 'Zmień "muszę" na "mogę"',
        description: "KSeF to nie tylko obowiązek - to szansa żeby ułatwić sobie pracę.",
      },
      {
        title: "Znajdź małe korzyści",
        description: "Szybsze księgowanie, mniej błędów, oszczędność czasu - to się liczy!",
      },
      {
        title: "Pomyśl co dalej",
        description: "Po KSeF pomyśl co jeszcze można usprawnić w firmie.",
      },
    ],
    testimonials: [
      {
        avatar: "👨‍💼",
        name: "Jan K.",
        company: "Handel",
        quote: "Nie chciałem, ale musiałem. Teraz już działa, jakoś to jest.",
      },
      {
        avatar: "👩‍💼",
        name: "Maria S.",
        company: "Usługi",
        quote: "Minimum wysiłku, maksimum zgodności z prawem. Taki był plan.",
      },
      {
        avatar: "👨‍🔧",
        name: "Andrzej W.",
        company: "Rzemiosło",
        quote: "Wolałbym żeby tego nie było, ale prawo to prawo.",
      },
    ],
    dimensions: {
      knowledge: 40,
      preparation: 35,
      technology: 30,
      team: 45,
      mindset: 25,
    },
  },
  {
    id: "THE_VISIONARY",
    name: "WIZJONER",
    tagline: "Buduję przyszłość",
    icon: Trophy,
    color: COLORS.archetypes.visionary,
    gradient: "from-yellow-500 to-orange-500",
    strengths: [
      "Myślisz strategicznie o przyszłości",
      "Inspirujesz innych do działania",
      "Budujesz społeczność wokół siebie",
      "Jesteś liderem myśli w branży",
    ],
    improvements: [
      "Skup się też na wykonaniu, nie tylko na wizji",
      "Zwracaj uwagę na małe szczegóły",
      "Realistycznie oceniaj ryzyko",
      "Znajdź balans między marzeniami a rzeczywistością",
    ],
    actionPlan: [
      {
        title: "Podziel się wiedzą publicznie",
        description: "Webinary, artykuły, wystąpienia - buduj pozycję eksperta w branży.",
      },
      {
        title: "Stwórz case study",
        description: "Opisz swoje doświadczenie jako przykład dla innych firm.",
      },
      {
        title: "Pomagaj innym",
        description: "Pomóż innym firmom przejść przez zmianę - buduj dziedzictwo.",
      },
    ],
    testimonials: [
      {
        avatar: "👨‍💼",
        name: "Krzysztof Z.",
        company: "Lider Branży",
        quote: "Organizujemy webinary dla branży. Dzielenie się wiedzą to nasza misja.",
      },
      {
        avatar: "👩‍💼",
        name: "Agnieszka P.",
        company: "Firma Doradcza",
        quote: "Stworzyliśmy framework KSeF. Teraz pomagamy innym firmom.",
      },
      {
        avatar: "👨‍🏫",
        name: "Marcin H.",
        company: "Firma Tech",
        quote: "Nie tylko wdrożyliśmy - zbudowaliśmy narzędzia dla całej branży!",
      },
    ],
    dimensions: {
      knowledge: 95,
      preparation: 90,
      technology: 85,
      team: 90,
      mindset: 100,
    },
  },
]

export const SYSTEMS = {
  excel: {
    name: "Excel / Google Sheets",
    icon: BarChart3,
    difficulty: "TRUDNE",
    difficultyColor: "red",
    integrationCost: 4500,
    time: "3-4 tygodnie",
    warning: "Wymaga specjalnej integracji - duże ryzyko błędów",
  },
  comarch: {
    name: "Comarch ERP Optima",
    icon: Building2,
    difficulty: "ŁATWE",
    difficultyColor: "green",
    integrationCost: 1200,
    time: "1 tydzień",
    badge: "Certyfikowany przez Ministerstwo",
    benefit: "Gotowe moduły - włączasz i działa",
  },
  symfonia: {
    name: "Symfonia",
    icon: Building2,
    difficulty: "ŁATWE",
    difficultyColor: "green",
    integrationCost: 1500,
    time: "1-2 tygodnie",
    badge: "Certyfikowany przez Ministerstwo",
  },
  wapro: {
    name: "Wapro",
    icon: Building2,
    difficulty: "ŁATWE",
    difficultyColor: "green",
    integrationCost: 1400,
    time: "1-2 tygodnie",
    badge: "Gotowe moduły",
  },
  sap: {
    name: "SAP",
    icon: Building2,
    difficulty: "TRUDNE",
    difficultyColor: "red",
    integrationCost: 8500,
    time: "4-6 tygodni",
    warning: "Potrzebujesz specjalisty SAP",
    badge: "Dla dużych firm",
  },
  none: {
    name: "Nie mam programu / Papier",
    icon: FileText,
    difficulty: "BARDZO TRUDNE",
    difficultyColor: "red",
    integrationCost: 5500,
    time: "3-6 tygodni",
    warning: "Musisz NAJPIERW kupić program do faktur!",
    alert: "Bez programu NIE da się zrobić KSeF!",
  },
} as const

export const DEADLINES = {
  november: {
    label: "Listopad 2025",
    icon: CheckCircle2,
    status: "comfortable",
    message: "Super! Macie mnóstwo czasu na spokojne przygotowanie.",
    timeline: "Testy w listopadzie, szkolenia w grudniu, start w styczniu z zapasem czasu",
    urgencyCost: 0,
  },
  december: {
    label: "Grudzień 2025",
    icon: ThumbsUp,
    status: "good",
    message: "Dobry timing. Zdążycie przed świętami.",
    timeline: "Przygotowanie w grudniu, testy w styczniu, spokojny start",
    urgencyCost: 0,
  },
  mid_january: {
    label: "Połowa Stycznia 2026",
    icon: Clock,
    status: "tight",
    message: "Ciasno! Tylko 2 tygodnie zapasu przed deadline.",
    timeline: "Intensywne przygotowanie, minimalne testy, ryzyko opóźnień",
    urgencyCost: 1500,
    warnings: ["Brak czasu na błędy", "Stres dla zespołu", "Dopłata za pilność"],
  },
  late_january: {
    label: "Koniec Stycznia 2026",
    icon: AlertTriangle,
    status: "critical",
    message: "BARDZO RYZYKOWNE! Dni przed deadline.",
    timeline: "Panika, zero testów, modlitwa żeby zadziałało",
    urgencyCost: 3500,
    warnings: [
      "Ogromne ryzyko że nie zdążycie",
      "Brak czasu na testy",
      "Bardzo wysoka dopłata za pilność",
      "Możliwe kary za spóźnienie",
    ],
  },
  after_deadline: {
    label: "Po 1 Lutego 2026",
    icon: Skull,
    status: "illegal",
    message: "TO NIELEGALNE! Nie możesz wystawiać faktur!",
    timeline: "GAME OVER - kary, sankcje, problemy z urzędem",
    urgencyCost: 5000,
    warnings: [
      "Kary finansowe od Urzędu Skarbowego",
      "Nie możesz wystawiać faktur firmom",
      "Problemy z kontrahentami",
      "Strata reputacji",
    ],
  },
} as const

export const TEAMS = {
  solo: {
    label: "Ja sam/sama",
    icon: Zap,
    impact: {
      stress: 20,
      time: "120 godzin Twojego czasu",
      risk: "WYSOKIE RYZYKO",
    },
  },
  small: {
    label: "Mamy księgową",
    icon: BarChart3,
    impact: {
      team: 10,
      time: "60 godzin + szkolenie",
      risk: "ŚREDNIE RYZYKO",
    },
  },
  department: {
    label: "Dział księgowości",
    icon: Building2,
    impact: {
      team: 20,
      process: 10,
      cost: "Szkolenie dla 5 osób",
      risk: "NISKIE RYZYKO",
    },
  },
  outsourced: {
    label: "Zewnętrzne biuro rachunkowe",
    icon: Handshake,
    impact: {
      team: 15,
      cost: "+1000 zł miesięcznie",
      stress: -10,
      risk: "NISKIE RYZYKO",
    },
  },
} as const
