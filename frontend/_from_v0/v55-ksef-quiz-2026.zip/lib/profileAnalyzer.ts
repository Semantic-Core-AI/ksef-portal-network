import type { UserProfile } from "./types"

export function analyzeUserProfile(answers: Record<string, any>): UserProfile {
  const q1Answer = answers[1]
  let knowledgeLevel: "low" | "medium" | "high" = "medium"

  if (q1Answer?.answer?.id === "clueless") {
    knowledgeLevel = "low"
  } else if (q1Answer?.answer?.id === "expert") {
    knowledgeLevel = "high"
  }

  const q4Answer = answers[4]
  let preparationLevel: "low" | "medium" | "high" = "medium"

  if (q4Answer?.answer === "after_deadline" || q4Answer?.answer === "late_january") {
    preparationLevel = "low"
  } else if (q4Answer?.answer === "november" || q4Answer?.answer === "december") {
    preparationLevel = "high"
  }

  const q3Answer = answers[3]
  const techSavvy = q3Answer?.answer !== "excel" && q3Answer?.answer !== "none"

  const q5Answer = answers[5]
  let teamSize: "solo" | "small" | "large" = "small"

  if (q5Answer?.answer === "solo") {
    teamSize = "solo"
  } else if (q5Answer?.answer === "department" || q5Answer?.answer === "outsourced") {
    teamSize = "large"
  }

  return { knowledgeLevel, preparationLevel, techSavvy, teamSize }
}

export function getPersonalizedInsights(profile: UserProfile): string[] {
  const insights: string[] = []

  if (profile.knowledgeLevel === "low") {
    insights.push("Zalecamy rozpoczęcie od podstawowego szkolenia KSeF")
  }

  if (profile.preparationLevel === "low") {
    insights.push("UWAGA: Bardzo mało czasu! Rozważ pomoc zewnętrznego konsultanta")
  }

  if (!profile.techSavvy) {
    insights.push("Wybierz certyfikowany system z gotowym wsparciem KSeF")
  }

  if (profile.teamSize === "solo") {
    insights.push("Solo wdrożenie jest ryzykowne - rozważ wsparcie eksperta")
  }

  return insights
}
