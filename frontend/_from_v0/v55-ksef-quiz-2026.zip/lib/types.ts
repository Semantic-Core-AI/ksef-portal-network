// Core types for KSeF Quiz 2026

export type QuestionId = 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8

export type AvatarType =
  | "startup_ninja"
  | "freelancer_solo"
  | "family_biz"
  | "rising_star"
  | "corporation"
  | "oldschool"

export type SystemType = "excel" | "comarch" | "symfonia" | "wapro" | "sap" | "none"

export type DeadlineChoice = "november" | "december" | "mid_january" | "late_january" | "after_deadline"

export type TeamType = "solo" | "small" | "department" | "outsourced"

export type CrisisChoice = "panic" | "backup" | "wait" | "paper"

export type VisionType = "survivor" | "mentor" | "connector" | "innovator" | "leader" | "reluctant"

export type ArchetypeType =
  | "THE_SURVIVOR"
  | "THE_PLANNER"
  | "THE_INNOVATOR"
  | "THE_COLLABORATOR"
  | "THE_RELUCTANT"
  | "THE_VISIONARY"

export type StoryAct = "setup" | "conflict" | "climax" | "resolution"

export interface QuizAnswer {
  questionId: QuestionId
  answer: any
  score?: number
  timestamp: number
}

export interface QuizState {
  currentQuestion: QuestionId
  answers: Record<QuestionId, QuizAnswer>
  totalScore: number
  archetype: ArchetypeType | null
  startedAt: number | null
  completedAt: number | null
}

import type { LucideIcon } from "lucide-react"

export interface Archetype {
  id: ArchetypeType
  name: string
  tagline: string
  icon: LucideIcon
  color: string
  gradient: string
  strengths: string[]
  improvements: string[]
  actionPlan: ActionItem[]
  testimonials: Testimonial[]
  dimensions: DimensionScores
}

export interface ActionItem {
  title: string
  description: string
}

export interface Testimonial {
  avatar: string
  name: string
  company: string
  quote: string
}

export interface DimensionScores {
  knowledge: number // Wiedza
  preparation: number // Przygotowanie
  technology: number // Technologia
  team: number // Zespół
  mindset: number // Mindset
}

export interface QuizScores {
  archetype: ArchetypeType
  knowledge: number
  preparation: number
  technology: number
  team: number
  mindset: number
  totalScore: number
}

export interface KnowledgeRanking {
  [key: string]: number
}

export interface UserProfile {
  knowledgeLevel: "beginner" | "intermediate" | "advanced"
  preparationLevel: "not_started" | "planning" | "in_progress" | "ready"
  techSavviness: "low" | "medium" | "high"
  teamSize: "solo" | "small" | "medium" | "large"
}

export interface StreakData {
  currentStreak: number
  longestStreak: number
  lastVisitDate: string | null
  dailyChallengeCompleted: boolean
  dailyChallengeDate: string | null
  totalVisits: number
  milestones: {
    day7: boolean
    day30: boolean
    day90: boolean
  }
}
