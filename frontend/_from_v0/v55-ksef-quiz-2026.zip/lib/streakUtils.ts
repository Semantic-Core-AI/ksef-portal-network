import type { StreakData } from "./types"

export function calculateStreak(currentData: StreakData): StreakData {
  const today = new Date()
  const todayStr = today.toISOString().split("T")[0]

  // First visit ever
  if (!currentData.lastVisitDate) {
    return {
      ...currentData,
      currentStreak: 1,
      longestStreak: 1,
      lastVisitDate: todayStr,
      totalVisits: 1,
    }
  }

  const lastVisit = new Date(currentData.lastVisitDate)
  const daysDiff = Math.floor((today.getTime() - lastVisit.getTime()) / (1000 * 60 * 60 * 24))

  // Same day visit - no change
  if (daysDiff === 0) {
    return currentData
  }

  // Consecutive day visit - increment streak
  if (daysDiff === 1) {
    const newStreak = currentData.currentStreak + 1
    const newLongest = Math.max(newStreak, currentData.longestStreak)

    // Check milestones
    const milestones = {
      day7: newStreak >= 7 || currentData.milestones.day7,
      day30: newStreak >= 30 || currentData.milestones.day30,
      day90: newStreak >= 90 || currentData.milestones.day90,
    }

    return {
      ...currentData,
      currentStreak: newStreak,
      longestStreak: newLongest,
      lastVisitDate: todayStr,
      totalVisits: currentData.totalVisits + 1,
      milestones,
    }
  }

  // Streak broken - reset to 1
  return {
    ...currentData,
    currentStreak: 1,
    lastVisitDate: todayStr,
    totalVisits: currentData.totalVisits + 1,
  }
}

export function getDailyChallengeQuestion() {
  const challenges = [
    {
      question: "Ile faktur rocznie wystawia Twoja firma?",
      options: ["< 100", "100-1000", "1000-10000", "> 10000"],
      correctAnswer: null, // No correct answer, just data collection
    },
    {
      question: "Czy Twój system księgowy jest gotowy na KSeF?",
      options: ["Tak, w pełni", "Częściowo", "Nie", "Nie wiem"],
      correctAnswer: null,
    },
    {
      question: "Kiedy planujesz rozpocząć wdrożenie KSeF?",
      options: ["Już rozpoczęliśmy", "W ciągu miesiąca", "W ciągu 3 miesięcy", "Jeszcze nie wiem"],
      correctAnswer: null,
    },
    {
      question: "Jaki jest największy problem w przygotowaniach do KSeF?",
      options: ["Brak wiedzy", "Brak czasu", "Brak budżetu", "Brak wsparcia zespołu"],
      correctAnswer: null,
    },
    {
      question: "Czy szkoliłeś już zespół w zakresie KSeF?",
      options: ["Tak, wszyscy przeszkoleni", "Częściowo", "Nie, ale planuję", "Nie planuję"],
      correctAnswer: null,
    },
  ]

  // Get question based on day of year to ensure same question for everyone on same day
  const dayOfYear = Math.floor(
    (Date.now() - new Date(new Date().getFullYear(), 0, 0).getTime()) / (1000 * 60 * 60 * 24),
  )
  return challenges[dayOfYear % challenges.length]
}
