import type { QuestionId } from "./types"

export interface AdaptiveQuestion {
  id: string
  difficulty: "easy" | "medium" | "hard"
  category: "knowledge" | "preparation" | "technology" | "team" | "mindset"
  prerequisite?: string // requires answer from previous question
  component: QuestionId
}

export const QUESTION_POOL: AdaptiveQuestion[] = [
  // Always ask these core questions
  { id: "q1-identity", difficulty: "easy", category: "knowledge", component: 1 },
  { id: "q2-priorities", difficulty: "easy", category: "mindset", component: 2 },
  { id: "q3-system", difficulty: "medium", category: "technology", component: 3 },
  { id: "q4-deadline", difficulty: "medium", category: "preparation", component: 4 },
  { id: "q5-team", difficulty: "medium", category: "team", component: 5 },
  { id: "q6-learning", difficulty: "medium", category: "mindset", component: 6 },
  { id: "q7-crisis", difficulty: "hard", category: "preparation", component: 7 },
  { id: "q8-vision", difficulty: "medium", category: "mindset", component: 8 },
]

export interface UserProfile {
  knowledgeLevel: "low" | "medium" | "high"
  preparationLevel: "low" | "medium" | "high"
  techSavvy: boolean
  teamSize: "solo" | "small" | "large"
}

export function analyzeUserProfile(answers: Record<string, any>): UserProfile {
  // Analyze Q1 answer for knowledge level
  const q1Answer = answers[1]
  let knowledgeLevel: "low" | "medium" | "high" = "medium"

  if (q1Answer?.answer?.id === "clueless") {
    knowledgeLevel = "low"
  } else if (q1Answer?.answer?.id === "expert") {
    knowledgeLevel = "high"
  }

  // Analyze Q4 answer for preparation level
  const q4Answer = answers[4]
  let preparationLevel: "low" | "medium" | "high" = "medium"

  if (q4Answer?.answer === "after_deadline" || q4Answer?.answer === "late_january") {
    preparationLevel = "low"
  } else if (q4Answer?.answer === "november" || q4Answer?.answer === "december") {
    preparationLevel = "high"
  }

  // Analyze Q3 answer for tech savviness
  const q3Answer = answers[3]
  const techSavvy = q3Answer?.answer !== "excel" && q3Answer?.answer !== "none"

  // Analyze Q5 answer for team size
  const q5Answer = answers[5]
  let teamSize: "solo" | "small" | "large" = "small"

  if (q5Answer?.answer === "solo") {
    teamSize = "solo"
  } else if (q5Answer?.answer === "department" || q5Answer?.answer === "outsourced") {
    teamSize = "large"
  }

  return { knowledgeLevel, preparationLevel, techSavvy, teamSize }
}

export function selectNextQuestion(currentQuestion: number, answers: Record<string, any>): QuestionId {
  // For now, keep linear progression (8 core questions)
  // In future, this can branch based on user profile
  const profile = analyzeUserProfile(answers)

  // Linear progression for MVP
  return Math.min(8, currentQuestion + 1) as QuestionId
}

export function getPersonalizedInsights(profile: UserProfile): string[] {
  const insights: string[] = []

  if (profile.knowledgeLevel === "low") {
    insights.push("Zalecamy rozpoczęcie od podstawowego szkolenia KSeF")
  }

  if (profile.preparationLevel === "low") {
    insights.push("UWAGA: Bardzo mało czasu! Rozważ pomoc zewnętrznego konsultanta")
  }

  if (!profile.techSavvy) {
    insights.push("Wybierz certyfikowany system z gotowym wsparciem KSeF")
  }

  if (profile.teamSize === "solo") {
    insights.push("Solo wdrożenie jest ryzykowne - rozważ wsparcie eksperta")
  }

  return insights
}
