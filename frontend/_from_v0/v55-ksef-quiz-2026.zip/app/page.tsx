"use client"

import type React from "react"

import { motion } from "framer-motion"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { CountdownTimer } from "@/components/countdown-timer"
import { useQuizStore } from "@/lib/store"
import { ArrowRight, Zap, Target, Users, TrendingUp, Shield, Sparkles } from "lucide-react"
import { formatDeadlineDate } from "@/lib/utils/date"
import { LiveStats } from "@/components/viral/live-stats"
import { StreakTracker } from "@/components/streak/streak-tracker"
import { DailyChallenge } from "@/components/streak/daily-challenge"

export default function HomePage() {
  const router = useRouter()
  const { startQuiz, resetQuiz } = useQuizStore()

  const handleStartQuiz = () => {
    resetQuiz()
    startQuiz()
    router.push("/quiz/1")
  }

  return (
    <div className="min-h-screen bg-[#1e2a5e] relative">
      {/* Diagonal Line Texture Pattern */}
      <div
        className="absolute inset-0 opacity-[0.07]"
        style={{
          backgroundImage: `
            repeating-linear-gradient(
              45deg,
              transparent,
              transparent 35px,
              rgba(255, 255, 255, 0.5) 35px,
              rgba(255, 255, 255, 0.5) 37px
            )
          `,
        }}
      />

      {/* Gradient Overlay - Navy to darker blue */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#1e2a5e] via-[#1a2550] to-[#162042]" />

      {/* Content */}
      <div className="relative z-10">
        {/* Hero Section */}
        <section className="relative overflow-hidden">
          {/* Background decoration */}
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <div className="absolute -top-40 -right-40 w-80 h-80 bg-[#c7a83b] rounded-full opacity-20 blur-3xl animate-float" />
            <div
              className="absolute -bottom-40 -left-40 w-80 h-80 bg-cyan-400 rounded-full opacity-20 blur-3xl animate-float"
              style={{ animationDelay: "1s" }}
            />
          </div>

          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-16">
            {/* Badge */}
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="text-center mb-8"
            >
              <div className="inline-flex items-center gap-2 bg-red-100 border-2 border-red-300 rounded-full px-6 py-3 text-red-700 font-bold text-sm">
                <Zap className="w-4 h-4" />
                DEADLINE: {formatDeadlineDate()}
              </div>
            </motion.div>

            {/* Main Headline */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="text-center mb-12"
            >
              <h1 className="text-5xl md:text-7xl font-black mb-6 leading-tight">
                <span className="block text-white">Jakim typem lidera</span>
                <span className="block bg-gradient-to-r from-[#c7a83b] to-orange-400 bg-clip-text text-transparent">
                  jesteś TY?
                </span>
              </h1>
              <p className="text-xl md:text-2xl text-blue-100 max-w-3xl mx-auto leading-relaxed">
                Odkryj swój styl przywództwa i zobacz <span className="font-bold text-[#c7a83b]">jak najłatwiej</span>{" "}
                przygotować firmę na KSeF. Dostaniesz gotowy plan krok po kroku!
              </p>
            </motion.div>

            {/* Countdown Timer */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="mb-12"
            >
              <div className="text-center mb-6">
                <p className="text-lg font-semibold text-blue-100">Zostało do obowiązkowego wdrożenia:</p>
              </div>
              <CountdownTimer />
            </motion.div>

            {/* Live Stats */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.25 }}
              className="mb-8"
            >
              <LiveStats />
            </motion.div>

            {/* Streak Tracker */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="mb-8 max-w-2xl mx-auto"
            >
              <StreakTracker />
            </motion.div>

            {/* CTA Button */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.35 }}
              className="text-center mb-16"
            >
              <Button
                size="lg"
                onClick={handleStartQuiz}
                className="bg-gradient-to-r from-[#c7a83b] to-orange-500 hover:from-[#c7a83b]/90 hover:to-orange-500/90 text-[#1e2a5e] px-12 py-8 text-xl font-bold rounded-2xl shadow-2xl hover:shadow-3xl transition-all duration-300 hover:scale-105 animate-pulse-glow"
              >
                Rozpocznij Misję <ArrowRight className="ml-3 w-6 h-6" />
              </Button>
              <p className="text-sm text-blue-200 mt-4">8 pytań • 4 minuty • Gotowy plan co robić</p>
            </motion.div>

            {/* Social Proof */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="text-center"
            >
              <div className="flex items-center justify-center gap-2 text-blue-100">
                <div className="flex -space-x-2">
                  {["👨‍💼", "👩‍💼", "👨‍🔧", "👩‍💻", "👨‍🏫"].map((avatar, i) => (
                    <div
                      key={i}
                      className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-sm border-2 border-white/30 flex items-center justify-center text-lg"
                    >
                      {avatar}
                    </div>
                  ))}
                </div>
                <p className="text-sm font-medium">
                  <span className="font-bold text-[#c7a83b]">2,847</span> liderów już odkryło swój typ przywództwa
                </p>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Daily Challenge Section */}
        <section className="py-20 bg-gradient-to-br from-blue-50 to-purple-50">
          <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="text-center mb-12"
            >
              <h2 className="text-4xl md:text-5xl font-black text-gray-900 mb-4">Dzisiejsze Wyzwanie</h2>
              <p className="text-xl text-gray-600">
                Odpowiedz poprawnie i zdobądź punkty. Wracaj codziennie po więcej!
              </p>
            </motion.div>
            <DailyChallenge />
          </div>
        </section>

        {/* Features Section */}
        <section className="py-20 bg-white/95 backdrop-blur-sm">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="text-center mb-16"
            >
              <h2 className="text-4xl md:text-5xl font-black text-[#1e2a5e] mb-4">Odkryj Swój Typ Lidera</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Zapomnij o nudnych formularzach! To przygoda gdzie odkrywasz swój unikalny styl przywództwa.
              </p>
            </motion.div>

            <div className="grid md:grid-cols-3 gap-8">
              <FeatureCard
                icon={<Target className="w-8 h-8" />}
                title="8 Różnych Zadań"
                description="Przeciągaj karty, przesuwaj suwaki, układaj na osi czasu. Każde pytanie to nowa zabawa!"
                color="blue"
                delay={0}
              />
              <FeatureCard
                icon={<Users className="w-8 h-8" />}
                title="6 Typów Osobowości"
                description="Odkryj który typ to Ty! Każdy ma swoje supermoce i wyzwania."
                color="purple"
                delay={0.1}
              />
              <FeatureCard
                icon={<TrendingUp className="w-8 h-8" />}
                title="Twój Plan Działania"
                description="Konkretne kroki co zrobić jutro, za tydzień i za miesiąc. Bez gadania, same fakty."
                color="green"
                delay={0.2}
              />
              <FeatureCard
                icon={<Shield className="w-8 h-8" />}
                title="Zobacz Jak Wypadasz"
                description="Wykres pokazuje Twoje mocne strony i gdzie możesz się poprawić."
                color="orange"
                delay={0.3}
              />
              <FeatureCard
                icon={<Sparkles className="w-8 h-8" />}
                title="Darmowy Raport PDF"
                description="Wszystko w jednym pliku - możesz go zapisać, wydrukować, pokazać szefowi."
                color="gold"
                delay={0.4}
              />
              <FeatureCard
                icon={<Zap className="w-8 h-8" />}
                title="Wyniki od Razu"
                description="Nie czekasz! Zaraz po ostatnim pytaniu widzisz swój typ i plan."
                color="red"
                delay={0.5}
              />
            </div>
          </div>
        </section>

        {/* Story Arc Preview */}
        <section className="py-20 bg-gradient-to-br from-blue-900 via-[#1e2a5e] to-blue-950 text-white relative">
          {/* Subtle texture overlay */}
          <div
            className="absolute inset-0 opacity-5"
            style={{
              backgroundImage: `radial-gradient(circle at 2px 2px, white 1px, transparent 0)`,
              backgroundSize: "32px 32px",
            }}
          />
          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="text-center mb-12"
            >
              <h2 className="text-4xl md:text-5xl font-black mb-4">Twoja Historia w 4 Rozdziałach</h2>
              <p className="text-xl text-blue-200 max-w-3xl mx-auto">
                Quiz to jak dobry film - zaczyna się spokojnie, potem robi się ciekawiej, aż do wielkiego finału!
              </p>
            </motion.div>

            <div className="grid grid-cols-12 gap-6 max-w-6xl mx-auto">
              {/* Act 1 - Top Left, Medium */}
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0 }}
                className="col-span-12 md:col-span-5 group"
              >
                <div className="relative overflow-hidden rounded-3xl p-1 h-full">
                  <div className="absolute inset-0 bg-gradient-to-br from-blue-400 via-blue-500 to-cyan-500 opacity-100 group-hover:opacity-90 transition-opacity" />
                  <div className="relative bg-white/10 backdrop-blur-sm rounded-2xl p-8 h-full flex flex-col justify-between min-h-[240px]">
                    <div>
                      <div className="flex items-center justify-between mb-4">
                        <div className="text-xs font-bold text-white/70 uppercase tracking-widest bg-white/20 px-3 py-1 rounded-full">
                          AKT 1
                        </div>
                        <div className="text-6xl font-black text-white/20">01</div>
                      </div>
                      <h3 className="text-3xl font-black text-white mb-3 leading-tight">ODKRYCIE</h3>
                      <p className="text-white/90 text-base leading-relaxed">
                        Kim jesteś? Co już wiesz o KSeF? Zaczynamy od podstaw.
                      </p>
                    </div>
                    <div className="flex items-center justify-between mt-6 pt-4 border-t border-white/20">
                      <div className="text-sm font-semibold text-white/80">Pytania 1-2</div>
                      <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
                        <ArrowRight className="w-5 h-5 text-white" />
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>

              {/* Act 2 - Top Right, Medium */}
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.1 }}
                className="col-span-12 md:col-span-7 group"
              >
                <div className="relative overflow-hidden rounded-3xl p-1 h-full">
                  <div className="absolute inset-0 bg-gradient-to-br from-orange-400 via-orange-500 to-red-500 opacity-100 group-hover:opacity-90 transition-opacity" />
                  <div className="relative bg-white/10 backdrop-blur-sm rounded-2xl p-8 h-full flex flex-col justify-between min-h-[240px]">
                    <div>
                      <div className="flex items-center justify-between mb-4">
                        <div className="text-xs font-bold text-white/70 uppercase tracking-widest bg-white/20 px-3 py-1 rounded-full">
                          AKT 2
                        </div>
                        <div className="text-6xl font-black text-white/20">02</div>
                      </div>
                      <h3 className="text-3xl font-black text-white mb-3 leading-tight">WYZWANIE</h3>
                      <p className="text-white/90 text-base leading-relaxed">
                        Jaki masz program do faktur? Kiedy chcesz zacząć? Kto Ci pomoże?
                      </p>
                    </div>
                    <div className="flex items-center justify-between mt-6 pt-4 border-t border-white/20">
                      <div className="text-sm font-semibold text-white/80">Pytania 3-5</div>
                      <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
                        <Target className="w-5 h-5 text-white" />
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>

              {/* Act 3 - Bottom Left, LARGE (Hero/Climax) */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="col-span-12 md:col-span-7 group"
              >
                <div className="relative overflow-hidden rounded-3xl p-1 h-full">
                  <div className="absolute inset-0 bg-gradient-to-br from-red-400 via-pink-500 to-rose-600 opacity-100 group-hover:opacity-90 transition-opacity animate-pulse-slow" />
                  <div className="relative bg-white/10 backdrop-blur-sm rounded-2xl p-10 h-full flex flex-col justify-between min-h-[280px]">
                    <div>
                      <div className="flex items-center justify-between mb-6">
                        <div className="text-xs font-bold text-white/70 uppercase tracking-widest bg-white/20 px-4 py-2 rounded-full flex items-center gap-2">
                          <Zap className="w-3 h-3" />
                          AKT 3 - CLIMAX
                        </div>
                        <div className="text-7xl font-black text-white/20">03</div>
                      </div>
                      <h3 className="text-4xl md:text-5xl font-black text-white mb-4 leading-tight">KRYZYS</h3>
                      <p className="text-white/90 text-lg leading-relaxed max-w-md">
                        Sprawdzamy czy jesteś gotowy! Co zrobisz gdy coś pójdzie nie tak?
                      </p>
                    </div>
                    <div className="flex items-center justify-between mt-8 pt-6 border-t border-white/20">
                      <div className="text-base font-semibold text-white/80">Pytania 6-7</div>
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-white animate-pulse" />
                        <div
                          className="w-2 h-2 rounded-full bg-white/70 animate-pulse"
                          style={{ animationDelay: "0.2s" }}
                        />
                        <div
                          className="w-2 h-2 rounded-full bg-white/50 animate-pulse"
                          style={{ animationDelay: "0.4s" }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>

              {/* Act 4 - Bottom Right, Medium */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.3 }}
                className="col-span-12 md:col-span-5 group"
              >
                <div className="relative overflow-hidden rounded-3xl p-1 h-full">
                  <div className="absolute inset-0 bg-gradient-to-br from-green-400 via-emerald-500 to-teal-500 opacity-100 group-hover:opacity-90 transition-opacity" />
                  <div className="relative bg-white/10 backdrop-blur-sm rounded-2xl p-8 h-full flex flex-col justify-between min-h-[280px]">
                    <div>
                      <div className="flex items-center justify-between mb-4">
                        <div className="text-xs font-bold text-white/70 uppercase tracking-widest bg-white/20 px-3 py-1 rounded-full">
                          AKT 4
                        </div>
                        <div className="text-6xl font-black text-white/20">04</div>
                      </div>
                      <h3 className="text-3xl font-black text-white mb-3 leading-tight">TRANSFORMACJA</h3>
                      <p className="text-white/90 text-base leading-relaxed">
                        Jak będzie wyglądać Twoja firma za rok? Marzenia stają się planami!
                      </p>
                    </div>
                    <div className="flex items-center justify-between mt-6 pt-4 border-t border-white/20">
                      <div className="text-sm font-semibold text-white/80">Pytanie 8</div>
                      <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
                        <Sparkles className="w-5 h-5 text-white" />
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Final CTA */}
        <section className="py-20 bg-gradient-to-br from-white/95 to-blue-50/95 backdrop-blur-sm">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <h2 className="text-4xl md:text-5xl font-black text-[#1e2a5e] mb-6">Gotowy Zacząć?</h2>
              <p className="text-xl text-gray-600 mb-12">
                4 minuty które pokażą Ci najłatwiejszą drogę do KSeF. Zero stresu, same konkretne wskazówki!
              </p>
              <Button
                size="lg"
                onClick={handleStartQuiz}
                className="bg-gradient-to-r from-[#c7a83b] to-orange-500 hover:from-[#c7a83b]/90 hover:to-orange-500/90 text-white px-12 py-8 text-xl font-bold rounded-2xl shadow-2xl hover:shadow-3xl transition-all duration-300 hover:scale-105"
              >
                Zacznij Quiz Teraz <ArrowRight className="ml-3 w-6 h-6" />
              </Button>
            </motion.div>
          </div>
        </section>

        {/* Footer */}
        <footer className="bg-[#1e2a5e]/95 backdrop-blur-sm text-white py-8 border-t border-white/10">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <p className="text-sm text-blue-200">
              © 2025 KSeF Expert. Pomagamy polskim firmom przygotować się do KSeF.
            </p>
          </div>
        </footer>
      </div>
    </div>
  )
}

function FeatureCard({
  icon,
  title,
  description,
  color,
  delay,
}: {
  icon: React.ReactNode
  title: string
  description: string
  color: string
  delay: number
}) {
  const colorMap: Record<string, string> = {
    blue: "from-blue-500 to-cyan-500",
    purple: "from-purple-500 to-pink-500",
    green: "from-green-500 to-emerald-500",
    orange: "from-orange-500 to-red-500",
    gold: "from-yellow-500 to-orange-500",
    red: "from-red-500 to-pink-500",
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, delay }}
      className="group"
    >
      <div className="bg-white rounded-2xl p-8 shadow-lg border-2 border-gray-100 hover:border-gray-200 transition-all duration-300 hover:shadow-2xl hover:-translate-y-1 h-full">
        <div
          className={`w-16 h-16 rounded-xl bg-gradient-to-br ${colorMap[color]} flex items-center justify-center text-white mb-6 group-hover:scale-110 transition-transform duration-300`}
        >
          {icon}
        </div>
        <h3 className="text-xl font-bold text-[#1e2a5e] mb-3">{title}</h3>
        <p className="text-gray-600 leading-relaxed">{description}</p>
      </div>
    </motion.div>
  )
}

function StoryActCard({
  act,
  title,
  description,
  color,
  questions,
  delay,
}: {
  act: string
  title: string
  description: string
  color: string
  questions: string
  delay: number
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, delay }}
      className="group"
    >
      <div className="relative overflow-hidden rounded-2xl p-1">
        <div
          className={`absolute inset-0 bg-gradient-to-br ${color} opacity-100 group-hover:opacity-90 transition-opacity`}
        />
        <div className="relative bg-white/10 backdrop-blur-sm rounded-xl p-6 h-full">
          <div className="text-xs font-bold text-white/80 mb-2 uppercase tracking-wider">{act}</div>
          <h3 className="text-2xl font-black text-white mb-3">{title}</h3>
          <p className="text-white/90 text-sm mb-4 leading-relaxed">{description}</p>
          <div className="text-xs font-semibold text-white/70">{questions}</div>
        </div>
      </div>
    </motion.div>
  )
}
