"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { motion } from "framer-motion"
import Confetti from "react-confetti"
import { useQuizStore } from "@/lib/store"
import { calculateArchetype } from "@/lib/utils/quiz-scoring"
import { ARCHETYPES } from "@/lib/constants"
import { getPersonalizedInsights } from "@/lib/profileAnalyzer"
import { Button } from "@/components/ui/button"
import { ArchetypeCard } from "@/components/results/archetype-card"
import { RadarChartComponent } from "@/components/results/radar-chart"
import { SocialShare } from "@/components/results/social-share"
import { EmailCapture } from "@/components/results/email-capture"
import {
  RotateCcw,
  Download,
  Calendar,
  Video,
  Calculator,
  CheckCircle2,
  Users,
  MessageCircle,
  Lightbulb,
} from "lucide-react"
import { LiveStats } from "@/components/viral/live-stats"
import { ArchetypeDistribution } from "@/components/viral/archetype-distribution"
import { ChallengeColleague } from "@/components/viral/challenge-colleague"
import { UnlockBonus } from "@/components/viral/unlock-bonus"

export default function ResultsPage() {
  const router = useRouter()
  const { answers, resetQuiz, userProfile } = useQuizStore()
  const [showConfetti, setShowConfetti] = useState(true)
  const [windowSize, setWindowSize] = useState({ width: 0, height: 0 })

  console.log("[v0] Results page - answers:", answers)
  console.log("[v0] Results page - userProfile:", userProfile)

  useEffect(() => {
    setWindowSize({
      width: window.innerWidth,
      height: window.innerHeight,
    })

    const timer = setTimeout(() => setShowConfetti(false), 3000)
    return () => clearTimeout(timer)
  }, [])

  const scores = calculateArchetype(answers)
  console.log("[v0] Results page - calculated scores:", scores)

  const userArchetype = ARCHETYPES.find((a) => a.id === scores.archetype)
  console.log("[v0] Results page - userArchetype:", userArchetype)

  const personalizedInsights = userProfile ? getPersonalizedInsights(userProfile) : []
  console.log("[v0] Results page - personalizedInsights:", personalizedInsights)

  useEffect(() => {
    if (userArchetype) {
      document.title = `Jestem ${userArchetype.name} - Misja KSeF 2026`

      const metaDescription = document.querySelector('meta[name="description"]')
      if (metaDescription) {
        metaDescription.setAttribute(
          "content",
          `Odkryłem swój archetyp lidera: ${userArchetype.name}. ${userArchetype.tagline}`,
        )
      }

      const ogTitle = document.querySelector('meta[property="og:title"]')
      if (ogTitle) {
        ogTitle.setAttribute("content", `Jestem ${userArchetype.name} - Misja KSeF 2026`)
      }

      const ogDescription = document.querySelector('meta[property="og:description"]')
      if (ogDescription) {
        ogDescription.setAttribute("content", `${userArchetype.tagline}. Sprawdź jaki archetyp lidera jesteś Ty!`)
      }
    }
  }, [userArchetype])

  if (!userArchetype) {
    router.push("/")
    return null
  }

  const handleRestart = () => {
    resetQuiz()
    router.push("/")
  }

  const confettiColors = [userArchetype.color, "#1e2a5e", "#2c6aa8", "#c7a83b"]

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-amber-50">
      {showConfetti && (
        <Confetti
          width={windowSize.width}
          height={windowSize.height}
          recycle={false}
          numberOfPieces={200}
          colors={confettiColors}
          gravity={0.3}
        />
      )}

      <div className="container-custom section-spacing">
        {/* Live Stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="mb-12"
        >
          <LiveStats />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h1 className="font-serif text-5xl md:text-6xl font-bold text-ksef-navy mb-4">Gratulacje!</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            Odkryłeś swój typ lidera! Zobacz co to oznacza i co dalej robić.
          </p>
        </motion.div>

        <div className="space-y-12">
          {/* Main Archetype Card */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <ArchetypeCard archetype={userArchetype} isHighlighted={true} />
          </motion.div>

          {/* Radar Chart */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            <RadarChartComponent scores={scores} color={userArchetype.color} />
          </motion.div>

          {/* Archetype Distribution Chart */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.45 }}
          >
            <ArchetypeDistribution userArchetypeId={userArchetype.id} />
          </motion.div>

          {/* Personalized Insights Section */}
          {personalizedInsights.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.35 }}
              className="bg-gradient-to-br from-amber-50 to-orange-50 border-2 border-amber-200 rounded-lg shadow-medium p-8"
            >
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 rounded-full bg-amber-500 flex items-center justify-center">
                  <Lightbulb className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h2 className="font-serif text-2xl font-bold text-ksef-navy">Porady Dla Ciebie</h2>
                  <p className="text-sm text-muted-foreground">Na podstawie Twoich odpowiedzi</p>
                </div>
              </div>
              <div className="space-y-3">
                {personalizedInsights.map((insight, index) => (
                  <div key={index} className="flex items-start gap-3 p-4 bg-white rounded-lg border border-amber-200">
                    <CheckCircle2 className="w-5 h-5 text-amber-500 flex-shrink-0 mt-0.5" />
                    <p className="text-gray-700 leading-relaxed">{insight}</p>
                  </div>
                ))}
              </div>
            </motion.div>
          )}

          {/* Twój Plan Działania */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.5 }}
            className="bg-white rounded-lg shadow-medium p-8"
          >
            <h2 className="font-serif text-3xl font-bold text-ksef-navy mb-2 text-center">Twój Plan Działania</h2>
            <p className="text-muted-foreground text-center mb-8">
              Konkretne kroki co robić - dopasowane do Twojego typu
            </p>
            <div className="space-y-6">
              {userArchetype.actionPlan.map((step, index) => (
                <div
                  key={index}
                  className="flex gap-4 p-6 rounded-lg bg-gradient-to-r from-gray-50 to-white border-l-4 hover:shadow-md transition-shadow"
                  style={{ borderLeftColor: userArchetype.color }}
                >
                  <div
                    className="flex-shrink-0 w-12 h-12 rounded-full flex items-center justify-center text-white font-bold text-xl"
                    style={{ backgroundColor: userArchetype.color }}
                  >
                    {index + 1}
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-lg text-ksef-navy mb-2">{step.title}</h3>
                    <p className="text-muted-foreground leading-relaxed">{step.description}</p>
                  </div>
                  <CheckCircle2 className="flex-shrink-0 w-6 h-6 text-green-500" />
                </div>
              ))}
            </div>
          </motion.div>

          {/* Co mówią inni jak Ty */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.6 }}
            className="bg-white rounded-lg shadow-medium p-8"
          >
            <h2 className="font-serif text-3xl font-bold text-ksef-navy mb-2 text-center">Co mówią inni jak Ty</h2>
            <p className="text-muted-foreground text-center mb-8">
              Poznaj doświadczenia przedsiębiorców o podobnym typie
            </p>
            <div className="grid md:grid-cols-3 gap-6">
              {userArchetype.testimonials.map((testimonial, index) => (
                <div
                  key={index}
                  className="p-6 rounded-lg bg-gradient-to-br from-gray-50 to-white border border-gray-200 hover:shadow-lg transition-shadow"
                >
                  <div className="flex items-center gap-3 mb-4">
                    <div
                      className="w-12 h-12 rounded-full flex items-center justify-center text-2xl"
                      style={{ backgroundColor: `${userArchetype.color}20` }}
                    >
                      <Users className="w-6 h-6" style={{ color: userArchetype.color }} />
                    </div>
                    <div>
                      <div className="font-bold text-ksef-navy">{testimonial.name}</div>
                      <div className="text-sm text-muted-foreground">{testimonial.company}</div>
                    </div>
                  </div>
                  <div className="relative">
                    <MessageCircle className="absolute -top-2 -left-2 w-8 h-8 text-gray-300" />
                    <p className="text-gray-700 italic leading-relaxed pl-6">"{testimonial.quote}"</p>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Unlock Bonus section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.65 }}
          >
            <UnlockBonus archetypeName={userArchetype.name} />
          </motion.div>

          {/* Email Capture */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.7 }}
          >
            <EmailCapture archetypeName={userArchetype.name} />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.8 }}
            className="bg-white rounded-lg shadow-medium p-8"
          >
            <div className="space-y-6">
              <SocialShare archetypeName={userArchetype.name} />
              <div className="flex justify-center pt-4 border-t border-gray-200">
                <ChallengeColleague archetypeName={userArchetype.name} userScore={scores.totalScore} />
              </div>
            </div>
          </motion.div>

          {/* Multi-CTA panel */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.9 }}
            className="bg-gradient-to-br from-ksef-navy to-ksef-blue rounded-lg shadow-strong p-8 text-white"
          >
            <h2 className="font-serif text-3xl font-bold mb-2 text-center">Potrzebujesz pomocy?</h2>
            <p className="text-blue-100 text-center mb-8">Skorzystaj z naszych darmowych zasobów</p>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 hover:bg-white/20 transition-colors">
                <Calendar className="w-12 h-12 mb-4 text-ksef-gold" />
                <h3 className="font-bold text-xl mb-2">Darmowa Rozmowa</h3>
                <p className="text-blue-100 mb-4 text-sm leading-relaxed">
                  30 minut z ekspertem - omówimy Twoją sytuację i podpowiemy co robić
                </p>
                <Button className="w-full bg-ksef-gold hover:bg-ksef-gold/90 text-ksef-navy font-bold">Umów się</Button>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 hover:bg-white/20 transition-colors">
                <Video className="w-12 h-12 mb-4 text-ksef-gold" />
                <h3 className="font-bold text-xl mb-2">Webinar Online</h3>
                <p className="text-blue-100 mb-4 text-sm leading-relaxed">
                  Dołącz do cotygodniowego webinaru - pytania i odpowiedzi, przykłady, porady
                </p>
                <Button className="w-full bg-ksef-gold hover:bg-ksef-gold/90 text-ksef-navy font-bold">
                  Zapisz się
                </Button>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 hover:bg-white/20 transition-colors">
                <Calculator className="w-12 h-12 mb-4 text-ksef-gold" />
                <h3 className="font-bold text-xl mb-2">Kalkulator Kosztów</h3>
                <p className="text-blue-100 mb-4 text-sm leading-relaxed">
                  Oblicz ile będzie kosztować i ile zajmie wdrożenie w Twojej firmie
                </p>
                <Button className="w-full bg-ksef-gold hover:bg-ksef-gold/90 text-ksef-navy font-bold">Oblicz</Button>
              </div>
            </div>
          </motion.div>

          {/* Other Archetypes */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 1 }}
            className="space-y-6"
          >
            <h2 className="font-serif text-3xl font-bold text-ksef-navy text-center">Poznaj inne typy</h2>
            <div className="grid md:grid-cols-2 gap-6">
              {ARCHETYPES.filter((a) => a.id !== userArchetype.id).map((archetype) => (
                <ArchetypeCard key={archetype.id} archetype={archetype} />
              ))}
            </div>
          </motion.div>

          {/* Action Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 1.2 }}
            className="flex flex-col sm:flex-row gap-4 justify-center"
          >
            <Button
              onClick={handleRestart}
              size="lg"
              variant="outline"
              className="border-ksef-navy text-ksef-navy hover:bg-ksef-navy hover:text-white bg-transparent"
            >
              <RotateCcw className="w-5 h-5 mr-2" />
              Rozpocznij quiz ponownie
            </Button>
            <Button onClick={() => window.print()} size="lg" className="bg-ksef-blue hover:bg-ksef-blue/90 text-white">
              <Download className="w-5 h-5 mr-2" />
              Drukuj wyniki
            </Button>
          </motion.div>
        </div>
      </div>
    </div>
  )
}
