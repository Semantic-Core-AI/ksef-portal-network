import type React from "react"
import type { Metadata } from "next"
import { Inter, Playfair_Display, JetBrains_Mono } from "next/font/google"
import { Analytics } from "@vercel/analytics/next"
import { Navigation } from "@/components/layout/navigation"
import "./globals.css"

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-sans",
  display: "swap",
})

const playfairDisplay = Playfair_Display({
  subsets: ["latin"],
  variable: "--font-serif",
  display: "swap",
})

const jetbrainsMono = JetBrains_Mono({
  subsets: ["latin"],
  variable: "--font-mono",
  display: "swap",
})

export const metadata: Metadata = {
  title: "Misja KSeF 2026 - Odkryj swój archetyp lidera",
  description:
    "Interaktywny quiz biznesowy o przygotowaniu do KSeF. Sprawdź jaki jesteś liderem transformacji i otrzymaj spersonalizowany plan działania.",
  keywords: "KSeF, e-faktura, quiz biznesowy, transformacja cyfrowa, księgowość",
  openGraph: {
    title: "Misja KSeF 2026 - Odkryj swój archetyp lidera",
    description: "Interaktywny quiz o przygotowaniu do KSeF. 8 pytań, 6 archetypów, Twoja historia.",
    type: "website",
  },
    generator: 'v0.app'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="pl">
      <body className={`${inter.variable} ${playfairDisplay.variable} ${jetbrainsMono.variable} font-sans antialiased`}>
        <Navigation />
        <main className="pt-16">{children}</main>
        <Analytics />
      </body>
    </html>
  )
}
