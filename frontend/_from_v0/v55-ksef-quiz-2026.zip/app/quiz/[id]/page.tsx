"use client"

import { useParams, useRouter } from "next/navigation"
import { useQuizStore } from "@/lib/store"
import { Question1 } from "@/components/quiz/question-1"
import { Question2 } from "@/components/quiz/question-2"
import { Question3 } from "@/components/quiz/question-3"
import { Question4 } from "@/components/quiz/question-4"
import { Question5 } from "@/components/quiz/question-5"
import { Question6 } from "@/components/quiz/question-6"
import { Question7 } from "@/components/quiz/question-7"
import { Question8 } from "@/components/quiz/question-8"

export default function QuizPage() {
  const params = useParams()
  const id = params.id as string
  const questionId = Number.parseInt(id)
  const router = useRouter()
  const { currentQuestion, setAnswer, nextQuestion } = useQuizStore()

  // Redirect if trying to access wrong question
  if (questionId !== currentQuestion) {
    router.push(`/quiz/${currentQuestion}`)
    return null
  }

  const handleAnswer = (answer: any) => {
    setAnswer(questionId as any, answer)
    nextQuestion()

    if (questionId < 8) {
      router.push(`/quiz/${questionId + 1}`)
    } else {
      router.push("/results")
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50 to-purple-50 py-8 px-4">
      {questionId === 1 && <Question1 onAnswer={handleAnswer} />}
      {questionId === 2 && <Question2 onAnswer={handleAnswer} />}
      {questionId === 3 && <Question3 onAnswer={handleAnswer} />}
      {questionId === 4 && <Question4 onAnswer={handleAnswer} />}
      {questionId === 5 && <Question5 onAnswer={handleAnswer} />}
      {questionId === 6 && <Question6 onAnswer={handleAnswer} />}
      {questionId === 7 && <Question7 onAnswer={handleAnswer} />}
      {questionId === 8 && <Question8 onAnswer={handleAnswer} />}
    </div>
  )
}
