"use client"

import type React from "react"

import { useState } from "react"
import { HelpCircle, X, ExternalLink } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { trackFAQEvent } from "@/lib/faq-utils"

interface InlineFAQHelperProps {
  fieldName: string
  quickAnswer: string
  fullFAQLink?: string
  children?: React.ReactNode
}

export function InlineFAQHelper({ fieldName, quickAnswer, fullFAQLink, children }: InlineFAQHelperProps) {
  const [isOpen, setIsOpen] = useState(false)

  const handleOpenChange = (open: boolean) => {
    setIsOpen(open)
    if (open) {
      trackFAQEvent({
        event: "faq_inline_helper_open",
        questionId: fieldName,
      })
    }
  }

  return (
    <Popover open={isOpen} onOpenChange={handleOpenChange}>
      <PopoverTrigger asChild>
        <Button
          variant="ghost"
          size="sm"
          className="h-5 w-5 p-0 rounded-full hover:bg-muted"
          aria-label={`Pomoc dla pola ${fieldName}`}
        >
          <HelpCircle className="h-4 w-4 text-muted-foreground hover:text-primary transition-colors" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80 p-4" align="start" sideOffset={5}>
        <div className="space-y-3">
          <div className="flex items-start justify-between">
            <h4 className="font-semibold text-sm">Szybka pomoc</h4>
            <Button variant="ghost" size="sm" className="h-5 w-5 p-0" onClick={() => setIsOpen(false)}>
              <X className="h-4 w-4" />
            </Button>
          </div>

          <p className="text-sm text-muted-foreground leading-relaxed">{quickAnswer}</p>

          {children && <div className="pt-2 border-t">{children}</div>}

          {fullFAQLink && (
            <Button
              variant="link"
              size="sm"
              className="p-0 h-auto text-primary"
              onClick={() => {
                trackFAQEvent({
                  event: "faq_related_question_click",
                  questionId: fieldName,
                })
              }}
            >
              Zobacz pełne wyjaśnienie
              <ExternalLink className="ml-1 h-3 w-3" />
            </Button>
          )}
        </div>
      </PopoverContent>
    </Popover>
  )
}
