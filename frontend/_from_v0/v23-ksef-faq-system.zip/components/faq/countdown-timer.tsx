"use client"

import { useState, useEffect } from "react"
import { AlertTriangle } from "lucide-react"
import { Card } from "@/components/ui/card"
import { motion } from "framer-motion"

interface TimeLeft {
  days: number
  hours: number
  minutes: number
  seconds: number
}

export function CountdownTimer() {
  const [timeLeft, setTimeLeft] = useState<TimeLeft>({ days: 0, hours: 0, minutes: 0, seconds: 0 })

  useEffect(() => {
    const calculateTimeLeft = () => {
      const deadline = new Date("2026-02-01T00:00:00")
      const now = new Date()
      const difference = deadline.getTime() - now.getTime()

      if (difference > 0) {
        return {
          days: Math.floor(difference / (1000 * 60 * 60 * 24)),
          hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
          minutes: Math.floor((difference / 1000 / 60) % 60),
          seconds: Math.floor((difference / 1000) % 60),
        }
      }

      return { days: 0, hours: 0, minutes: 0, seconds: 0 }
    }

    setTimeLeft(calculateTimeLeft())

    const timer = setInterval(() => {
      setTimeLeft(calculateTimeLeft())
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="w-full bg-gradient-to-r from-red-600/20 to-orange-600/20 backdrop-blur-sm border border-red-500/30 rounded-2xl p-6 mb-8"
    >
      <div className="flex items-center justify-center gap-3 mb-4">
        <AlertTriangle className="h-6 w-6 text-red-400" />
        <h3 className="text-xl md:text-2xl font-serif font-bold text-white">OBOWIĄZKOWE OD 1 LUTEGO 2026</h3>
      </div>

      <p className="text-center text-white/90 text-base md:text-lg mb-6">Czas do obowiązkowego wdrożenia KSeF:</p>

      <div className="grid grid-cols-4 gap-3 md:gap-4 max-w-2xl mx-auto">
        {[
          { value: timeLeft.days, label: "Dni" },
          { value: timeLeft.hours, label: "Godzin" },
          { value: timeLeft.minutes, label: "Minut" },
          { value: timeLeft.seconds, label: "Sekund" },
        ].map((item, index) => (
          <motion.div
            key={item.label}
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="bg-[#1E2A5E] border-[#2C6AA8] p-4 text-center">
              <div className="text-3xl md:text-4xl lg:text-5xl font-bold text-white font-mono">
                {String(item.value).padStart(2, "0")}
              </div>
              <div className="text-xs md:text-sm text-white/70 mt-1 font-medium">{item.label}</div>
            </Card>
          </motion.div>
        ))}
      </div>
    </motion.div>
  )
}
