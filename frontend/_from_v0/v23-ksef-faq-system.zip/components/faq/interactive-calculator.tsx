"use client"

import { useState } from "react"
import { Calculator, TrendingUp } from "lucide-react"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"

export function InteractiveCalculator() {
  const [invoicesPerMonth, setInvoicesPerMonth] = useState(100)
  const [avgInvoiceValue, setAvgInvoiceValue] = useState(1000)
  const [result, setResult] = useState<number | null>(null)

  const calculateCost = () => {
    // Mock calculation: base cost + per invoice cost
    const baseCost = 5000
    const perInvoiceCost = invoicesPerMonth * 2
    const implementationCost = baseCost + perInvoiceCost * 12
    setResult(implementationCost)
  }

  return (
    <Card className="p-6 bg-gradient-to-br from-primary/5 to-secondary/5 border-primary/20">
      <div className="flex items-center gap-2 mb-4">
        <Calculator className="h-6 w-6 text-primary" />
        <h4 className="font-semibold text-lg">Kalkulator kosztów wdrożenia</h4>
      </div>

      <div className="space-y-4">
        <div>
          <Label htmlFor="invoices">Liczba faktur miesięcznie</Label>
          <Input
            id="invoices"
            type="number"
            value={invoicesPerMonth}
            onChange={(e) => setInvoicesPerMonth(Number(e.target.value))}
            min="1"
          />
        </div>

        <div>
          <Label htmlFor="value">Średnia wartość faktury (PLN)</Label>
          <Input
            id="value"
            type="number"
            value={avgInvoiceValue}
            onChange={(e) => setAvgInvoiceValue(Number(e.target.value))}
            min="1"
          />
        </div>

        <Button onClick={calculateCost} className="w-full">
          <TrendingUp className="mr-2 h-4 w-4" />
          Oblicz szacunkowy koszt
        </Button>

        {result !== null && (
          <div className="mt-4 p-4 bg-primary/10 rounded-lg border border-primary/20">
            <p className="text-sm text-muted-foreground mb-1">Szacunkowy koszt roczny:</p>
            <p className="text-2xl font-bold text-primary">{result.toLocaleString("pl-PL")} PLN</p>
          </div>
        )}
      </div>
    </Card>
  )
}
