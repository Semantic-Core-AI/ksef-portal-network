"use client"

import { useState, useEffect } from "react"
import { Copy, Check, Gift, Users, Zap, Share2 } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { motion } from "framer-motion"
import { getReferralStats, copyReferralLink } from "@/lib/referral-system"
import { trackFAQEvent, shareOnSocial } from "@/lib/faq-utils"

export function ReferralProgram() {
  const [copied, setCopied] = useState(false)
  const [stats, setStats] = useState({
    code: "",
    link: "",
    totalReferrals: 0,
    convertedReferrals: 0,
    pendingReferrals: 0,
    totalRewards: 0,
  })

  useEffect(() => {
    const referralStats = getReferralStats()
    setStats(referralStats)
  }, [])

  const handleCopy = async () => {
    const success = await copyReferralLink()
    if (success) {
      setCopied(true)
      trackFAQEvent({ event: "faq_referral_copied", referralCode: stats.code })
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = (platform: "linkedin" | "twitter" | "facebook") => {
    const text = `Sprawdź ten interaktywny system FAQ o KSeF! Dowiedz się wszystkiego o obowiązkowej e-fakturze. Użyj mojego kodu: ${stats.code}`
    shareOnSocial(platform, text, stats.link)
    trackFAQEvent({ event: "faq_referral_shared", platform, referralCode: stats.code })
  }

  return (
    <Card className="bg-gradient-to-br from-primary/5 to-secondary/5 border-2 border-primary/20">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 font-serif text-2xl text-white">
          <Gift className="h-7 w-7 text-accent" />
          Program Poleceń
        </CardTitle>
        <CardDescription className="text-base">Poleć znajomym i odblokowuj ekskluzywne nagrody</CardDescription>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Referral Stats */}
        <div className="grid grid-cols-3 gap-4">
          <motion.div
            className="text-center p-4 bg-white rounded-lg shadow-soft"
            whileHover={{ scale: 1.05 }}
            transition={{ type: "spring", stiffness: 300 }}
          >
            <Users className="h-6 w-6 text-primary mx-auto mb-2" />
            <p className="text-2xl font-bold text-primary">{stats.convertedReferrals}</p>
            <p className="text-sm text-muted-foreground">Poleconych</p>
          </motion.div>

          <motion.div
            className="text-center p-4 bg-white rounded-lg shadow-soft"
            whileHover={{ scale: 1.05 }}
            transition={{ type: "spring", stiffness: 300 }}
          >
            <Zap className="h-6 w-6 text-accent mx-auto mb-2" />
            <p className="text-2xl font-bold text-accent">{stats.totalRewards}</p>
            <p className="text-sm text-muted-foreground">Bonus XP</p>
          </motion.div>

          <motion.div
            className="text-center p-4 bg-white rounded-lg shadow-soft"
            whileHover={{ scale: 1.05 }}
            transition={{ type: "spring", stiffness: 300 }}
          >
            <Gift className="h-6 w-6 text-secondary mx-auto mb-2" />
            <p className="text-2xl font-bold text-secondary">{stats.pendingReferrals}</p>
            <p className="text-sm text-muted-foreground">Oczekujące</p>
          </motion.div>
        </div>

        {/* Referral Code Display */}
        <div className="p-4 bg-white rounded-lg border-2 border-dashed border-primary/30">
          <p className="text-sm font-medium text-muted-foreground mb-2">Twój kod polecający:</p>
          <p className="text-3xl font-bold text-primary font-mono tracking-wider">{stats.code}</p>
        </div>

        {/* Referral Link */}
        <div className="space-y-3">
          <label className="text-sm font-medium">Twój unikalny link polecający:</label>
          <div className="flex gap-2">
            <Input value={stats.link} readOnly className="bg-white text-base font-mono" />
            <Button onClick={handleCopy} size="lg" variant={copied ? "secondary" : "default"}>
              {copied ? <Check className="h-5 w-5" /> : <Copy className="h-5 w-5" />}
            </Button>
          </div>
          {copied && (
            <motion.p
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-sm text-secondary font-medium"
            >
              ✓ Link skopiowany do schowka!
            </motion.p>
          )}
        </div>

        {/* Social Share Buttons */}
        <div className="space-y-3">
          <p className="text-sm font-medium">Udostępnij na:</p>
          <div className="flex gap-2">
            <Button onClick={() => handleShare("linkedin")} variant="outline" className="flex-1" size="lg">
              <Share2 className="mr-2 h-5 w-5" />
              LinkedIn
            </Button>
            <Button onClick={() => handleShare("twitter")} variant="outline" className="flex-1" size="lg">
              <Share2 className="mr-2 h-5 w-5" />
              Twitter
            </Button>
            <Button onClick={() => handleShare("facebook")} variant="outline" className="flex-1" size="lg">
              <Share2 className="mr-2 h-5 w-5" />
              Facebook
            </Button>
          </div>
        </div>

        {/* Rewards Tiers */}
        <div className="space-y-3 pt-4 border-t">
          <p className="text-sm font-medium">Odblokuj nagrody:</p>
          <div className="space-y-2">
            <div className="flex items-center justify-between p-3 bg-white rounded-lg">
              <div className="flex items-center gap-3">
                <Badge variant={stats.convertedReferrals >= 1 ? "default" : "outline"}>1 polecenie</Badge>
                <span className="text-sm">Dostęp do kalkulatora premium</span>
              </div>
              {stats.convertedReferrals >= 1 && <Check className="h-5 w-5 text-secondary" />}
            </div>

            <div className="flex items-center justify-between p-3 bg-white rounded-lg">
              <div className="flex items-center gap-3">
                <Badge variant={stats.convertedReferrals >= 3 ? "default" : "outline"}>3 polecenia</Badge>
                <span className="text-sm">Darmowa konsultacja ekspercka (30 min)</span>
              </div>
              {stats.convertedReferrals >= 3 && <Check className="h-5 w-5 text-secondary" />}
            </div>

            <div className="flex items-center justify-between p-3 bg-white rounded-lg">
              <div className="flex items-center gap-3">
                <Badge variant={stats.convertedReferrals >= 5 ? "default" : "outline"}>5 poleceń</Badge>
                <span className="text-sm">Kompletny pakiet wdrożeniowy KSeF</span>
              </div>
              {stats.convertedReferrals >= 5 && <Check className="h-5 w-5 text-secondary" />}
            </div>
          </div>
        </div>

        {/* How it works */}
        <div className="p-4 bg-accent/10 rounded-lg border border-accent/20">
          <p className="text-sm font-medium mb-2">Jak to działa?</p>
          <ol className="text-sm space-y-1 text-muted-foreground list-decimal list-inside">
            <li>Skopiuj swój unikalny link polecający</li>
            <li>Wyślij go znajomym lub udostępnij w social media</li>
            <li>Gdy ktoś użyje Twojego linku i poda email, otrzymujesz nagrodę</li>
            <li>Im więcej poleceń, tym lepsze nagrody odblokowujesz!</li>
          </ol>
        </div>
      </CardContent>
    </Card>
  )
}
