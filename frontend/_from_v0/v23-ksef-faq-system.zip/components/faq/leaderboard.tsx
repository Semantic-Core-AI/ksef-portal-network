"use client"

import { useState, useEffect } from "react"
import { Trophy, TrendingUp, Flame, Medal } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { getLeaderboardData, getUserProgress } from "@/lib/faq-utils"
import type { LeaderboardEntry } from "@/lib/faq-types"
import { motion } from "framer-motion"

export function Leaderboard() {
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([])
  const [currentUserId, setCurrentUserId] = useState<string>("")

  useEffect(() => {
    const data = getLeaderboardData()
    setLeaderboard(data.slice(0, 10)) // Top 10

    const progress = getUserProgress()
    if (progress.totalXP > 0) {
      setCurrentUserId("current")
    }
  }, [])

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Trophy className="h-6 w-6 text-accent" />
      case 2:
        return <Medal className="h-6 w-6 text-gray-400" />
      case 3:
        return <Medal className="h-6 w-6 text-amber-600" />
      default:
        return <span className="text-lg font-bold text-muted-foreground">#{rank}</span>
    }
  }

  return (
    <Card className="bg-white">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 font-serif text-2xl">
          <TrendingUp className="h-7 w-7 text-primary" />
          Ranking Firm
        </CardTitle>
        <CardDescription className="text-base">
          Zobacz jak Twoja firma wypada na tle innych w przygotowaniach do KSeF
        </CardDescription>
      </CardHeader>

      <CardContent>
        <div className="space-y-2">
          {leaderboard.map((entry, index) => {
            const isCurrentUser = entry.userId === currentUserId

            return (
              <motion.div
                key={entry.userId}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                className={`flex items-center gap-4 p-4 rounded-lg transition-colors ${
                  isCurrentUser
                    ? "bg-gradient-to-r from-primary/10 to-secondary/10 border-2 border-primary"
                    : "bg-gray-50 hover:bg-gray-100"
                }`}
              >
                {/* Rank */}
                <div className="flex-shrink-0 w-12 flex justify-center">{getRankIcon(entry.rank)}</div>

                {/* Company Info */}
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-base truncate">
                    {entry.companyName}
                    {isCurrentUser && (
                      <Badge variant="secondary" className="ml-2">
                        Ty
                      </Badge>
                    )}
                  </p>
                  <div className="flex items-center gap-3 text-sm text-muted-foreground mt-1">
                    <span>{entry.completedQuests} questów</span>
                    <span>•</span>
                    <span className="flex items-center gap-1">
                      <Flame className="h-4 w-4 text-orange-500" />
                      {entry.streak} dni
                    </span>
                  </div>
                </div>

                {/* XP */}
                <div className="text-right">
                  <p className="text-xl font-bold text-primary">{entry.totalXP}</p>
                  <p className="text-sm text-muted-foreground">XP</p>
                </div>
              </motion.div>
            )
          })}
        </div>

        {/* Call to Action */}
        <div className="mt-6 p-4 bg-gradient-to-r from-primary/5 to-secondary/5 rounded-lg text-center">
          <p className="text-sm text-muted-foreground mb-2">Ukończ więcej questów aby wspiąć się wyżej w rankingu!</p>
          <Badge variant="outline" className="text-sm">
            Ranking aktualizowany co godzinę
          </Badge>
        </div>
      </CardContent>
    </Card>
  )
}
