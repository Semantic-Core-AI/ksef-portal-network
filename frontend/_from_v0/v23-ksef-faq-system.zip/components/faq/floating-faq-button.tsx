"use client"

import { useState, useEffect } from "react"
import { HelpCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { motion, AnimatePresence } from "framer-motion"
import { trackFAQEvent } from "@/lib/faq-utils"

interface FloatingFAQButtonProps {
  onClick: () => void
  newTipsCount?: number
}

export function FloatingFAQButton({ onClick, newTipsCount = 3 }: FloatingFAQButtonProps) {
  const [isVisible, setIsVisible] = useState(false)
  const [shouldBounce, setShouldBounce] = useState(false)

  useEffect(() => {
    // Slide in after mount
    setTimeout(() => setIsVisible(true), 500)

    // Bounce animation every 15 seconds
    const bounceInterval = setInterval(() => {
      setShouldBounce(true)
      setTimeout(() => setShouldBounce(false), 1000)
    }, 15000)

    return () => clearInterval(bounceInterval)
  }, [])

  const handleClick = () => {
    trackFAQEvent({ event: "faq_floating_button_click" })
    onClick()
  }

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ scale: 0, opacity: 0 }}
          animate={{
            scale: 1,
            opacity: 1,
            y: shouldBounce ? [0, -10, 0] : 0,
          }}
          exit={{ scale: 0, opacity: 0 }}
          transition={{ duration: 0.3 }}
          className="fixed bottom-6 right-6 z-50"
        >
          <div className="relative">
            <Button
              onClick={handleClick}
              size="lg"
              className="h-14 w-14 rounded-full bg-primary shadow-xl hover:shadow-2xl hover:scale-110 transition-all duration-200 animate-pulse-glow"
              aria-label="Otwórz FAQ"
            >
              <HelpCircle className="h-6 w-6" />
            </Button>

            {newTipsCount > 0 && (
              <Badge
                variant="destructive"
                className="absolute -top-1 -right-1 h-6 w-6 rounded-full p-0 flex items-center justify-center text-xs font-bold"
              >
                {newTipsCount}
              </Badge>
            )}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
