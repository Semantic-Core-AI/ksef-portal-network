"use client"

import { useState } from "react"
import { Share2, Download, Sparkles } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { shareOnSocial, trackFAQEvent, getUserProgress } from "@/lib/faq-utils"
import { motion } from "framer-motion"

export function ViralShareCard() {
  const [shared, setShared] = useState(false)
  const progress = getUserProgress()

  const handleShare = (platform: "linkedin" | "twitter" | "facebook") => {
    const achievements = [
      `Zdobyłem ${progress.totalXP} XP ucząc się o KSeF!`,
      `${progress.streak} dni z rzędu uczę się o e-fakturowaniu!`,
      `Ukończyłem ${progress.earnedBadges.length} questów o KSeF!`,
    ]

    const randomAchievement = achievements[Math.floor(Math.random() * achievements.length)]
    const text = `${randomAchievement} Sprawdź interaktywny system FAQ o KSeF i przygotuj swoją firmę na obowiązkową e-fakturę! #KSeF #eFaktura #Księgowość`

    shareOnSocial(platform, text)
    setShared(true)

    trackFAQEvent({
      event: "faq_viral_share",
      platform,
    })

    setTimeout(() => setShared(false), 3000)
  }

  const handleDownloadCertificate = () => {
    trackFAQEvent({
      event: "faq_certificate_download",
    })
    // In production, generate and download certificate
    alert("Certyfikat zostanie wygenerowany i pobrany!")
  }

  if (progress.totalXP < 100) {
    return null // Only show after earning some XP
  }

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}>
      <Card className="bg-gradient-to-br from-accent/10 to-secondary/10 border-2 border-accent/30">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 font-serif text-xl">
            <Sparkles className="h-6 w-6 text-accent" />
            Pochwal się swoimi osiągnięciami!
          </CardTitle>
          <CardDescription className="text-base">
            Udostępnij swój postęp i zainspiruj innych do nauki o KSeF
          </CardDescription>
        </CardHeader>

        <CardContent className="space-y-4">
          {/* Achievement Stats */}
          <div className="flex gap-3 flex-wrap">
            <Badge variant="secondary" className="text-sm py-1 px-3">
              {progress.totalXP} XP
            </Badge>
            <Badge variant="secondary" className="text-sm py-1 px-3">
              {progress.earnedBadges.length} Questów
            </Badge>
            <Badge variant="secondary" className="text-sm py-1 px-3">
              {progress.streak} Dni Streak
            </Badge>
          </div>

          {/* Share Buttons */}
          <div className="grid grid-cols-2 gap-2">
            <Button onClick={() => handleShare("linkedin")} variant="outline" size="lg" className="bg-white">
              <Share2 className="mr-2 h-5 w-5" />
              LinkedIn
            </Button>
            <Button onClick={() => handleShare("twitter")} variant="outline" size="lg" className="bg-white">
              <Share2 className="mr-2 h-5 w-5" />
              Twitter
            </Button>
          </div>

          {/* Certificate Download */}
          {progress.earnedBadges.length >= 2 && (
            <Button
              onClick={handleDownloadCertificate}
              size="lg"
              className="w-full bg-accent text-accent-foreground hover:bg-accent/90"
            >
              <Download className="mr-2 h-5 w-5" />
              Pobierz Certyfikat Ukończenia
            </Button>
          )}

          {shared && (
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-sm text-center text-secondary font-medium"
            >
              Dziękujemy za udostępnienie! 🎉
            </motion.p>
          )}
        </CardContent>
      </Card>
    </motion.div>
  )
}
