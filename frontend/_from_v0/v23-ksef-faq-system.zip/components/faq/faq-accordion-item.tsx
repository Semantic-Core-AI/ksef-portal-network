"use client"

import { useState, useEffect } from "react"
import {
  ChevronDown,
  ThumbsUp,
  ThumbsDown,
  Eye,
  TrendingUp,
  CheckCircle,
  ExternalLink,
  Calculator,
  Phone,
  Users,
} from "lucide-react"
import { AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import type { FAQQuestion } from "@/lib/faq-types"
import { formatNumber, trackFAQEvent, markQuestionCompleted, isQuestionCompleted } from "@/lib/faq-utils"
import { motion } from "framer-motion"
import { InteractiveCalculator } from "./interactive-calculator"

interface FAQAccordionItemProps {
  question: FAQQuestion
  onRelatedClick: (questionId: string) => void
}

export function FAQAccordionItem({ question, onRelatedClick }: FAQAccordionItemProps) {
  const [isExpanded, setIsExpanded] = useState(false)
  const [showDetailed, setShowDetailed] = useState(false)
  const [userVote, setUserVote] = useState<"positive" | "negative" | null>(null)
  const [showCalculator, setShowCalculator] = useState(false)
  const [readersToday, setReadersToday] = useState(0)
  const isCompleted = isQuestionCompleted(question.id)

  useEffect(() => {
    const baseReaders = Math.floor(question.views / 100)
    const randomReaders = Math.floor(Math.random() * 50) + baseReaders
    setReadersToday(randomReaders)
  }, [question.views])

  const helpfulPercentage = Math.round(
    (question.helpfulVotes.positive / (question.helpfulVotes.positive + question.helpfulVotes.negative)) * 100,
  )

  const handleExpand = (value: string) => {
    const expanded = value === question.id
    setIsExpanded(expanded)

    if (expanded) {
      trackFAQEvent({
        event: "faq_question_expanded",
        questionId: question.id,
        category: question.category,
      })
      markQuestionCompleted(question.id)
    }
  }

  const handleVote = (vote: "positive" | "negative") => {
    setUserVote(vote)
    trackFAQEvent({
      event: "faq_helpful_vote",
      questionId: question.id,
      source: vote,
    })
  }

  const handleCTAClick = (ctaType: string) => {
    trackFAQEvent({
      event: "faq_cta_click",
      ctaType,
      questionId: question.id,
    })
  }

  return (
    <AccordionItem
      value={question.id}
      className="border rounded-lg mb-4 overflow-hidden shadow-soft hover:shadow-medium transition-shadow bg-white"
      data-faq-event="question_item"
      data-question-id={question.id}
      data-category={question.category}
    >
      <AccordionTrigger
        className="px-6 py-5 hover:bg-gray-50 transition-colors [&[data-state=open]]:bg-gray-50"
        onClick={() => handleExpand(isExpanded ? "" : question.id)}
      >
        <div className="flex items-start justify-between w-full text-left pr-4">
          <div className="flex-1">
            <h3 className="font-serif font-semibold text-lg md:text-xl mb-3 pr-4 leading-relaxed text-navy">
              {question.question}
            </h3>
            <div className="flex items-center gap-3 text-sm text-gray-600 flex-wrap">
              <span className="flex items-center gap-1">
                <Eye className="h-4 w-4" />
                {formatNumber(question.views)} wyświetleń
              </span>
              <span className="flex items-center gap-1">
                <ThumbsUp className="h-4 w-4" />
                {helpfulPercentage}% pomocne
              </span>
              {readersToday > 0 && (
                <Badge variant="outline" className="text-xs py-0.5 px-2 border-green-500/30 bg-green-50 text-green-700">
                  <Users className="h-3 w-3 mr-1" />
                  {readersToday} osób czyta dziś
                </Badge>
              )}
              {question.isTrending && (
                <Badge variant="destructive" className="text-xs py-0.5 px-2">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  Trending
                </Badge>
              )}
              {question.expertVerified && (
                <Badge variant="secondary" className="text-xs py-0.5 px-2 bg-secondary text-secondary-foreground">
                  <CheckCircle className="h-3 w-3 mr-1" />
                  Zweryfikowane
                </Badge>
              )}
              {isCompleted && (
                <Badge variant="default" className="text-xs py-0.5 px-2 bg-accent text-accent-foreground">
                  <CheckCircle className="h-3 w-3 mr-1" />
                  Przeczytane
                </Badge>
              )}
            </div>
          </div>
        </div>
      </AccordionTrigger>

      <AccordionContent className="px-6 pb-6">
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="space-y-5 pt-3"
        >
          {/* Quick Answer */}
          <div className="prose prose-base max-w-none">
            <p className="text-base md:text-lg leading-relaxed text-gray-800">{question.quickAnswer}</p>
          </div>

          {question.interactiveElement === "calculator" && !showCalculator && (
            <div className="bg-gray-50 rounded-lg p-5 border-2 border-dashed border-primary/20">
              <div className="flex items-center gap-2 mb-3">
                <Calculator className="h-6 w-6 text-primary" />
                <h4 className="font-semibold text-base md:text-lg">Interaktywny Kalkulator</h4>
              </div>
              <p className="text-base text-muted-foreground mb-4">Oblicz dokładny koszt dla Twojej firmy</p>
              <Button
                size="lg"
                className="w-full bg-accent text-accent-foreground hover:bg-accent/90 text-base"
                onClick={() => setShowCalculator(true)}
                data-faq-event="cta_click"
                data-cta-type="calculator"
              >
                Otwórz kalkulator
              </Button>
            </div>
          )}

          {showCalculator && <InteractiveCalculator />}

          {/* Detailed Answer (Progressive Disclosure) */}
          {question.detailedAnswer && (
            <div className="space-y-3">
              {!showDetailed ? (
                <Button variant="outline" size="lg" onClick={() => setShowDetailed(true)} className="w-full text-base">
                  <ChevronDown className="mr-2 h-5 w-5" />
                  Zobacz szczegółowe wyjaśnienie
                </Button>
              ) : (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  className="prose prose-base max-w-none bg-gray-50 rounded-lg p-5"
                >
                  <div className="text-base md:text-lg leading-relaxed whitespace-pre-line text-gray-800">
                    {question.detailedAnswer}
                  </div>
                </motion.div>
              )}
            </div>
          )}

          {/* Related Questions */}
          {question.relatedQuestions.length > 0 && (
            <div className="space-y-3 pt-3 border-t">
              <h4 className="text-base font-semibold text-gray-700">Powiązane pytania:</h4>
              <div className="grid gap-2">
                {question.relatedQuestions.slice(0, 3).map((relatedId) => (
                  <Button
                    key={relatedId}
                    variant="ghost"
                    size="lg"
                    className="justify-start text-left h-auto py-3 px-4"
                    onClick={() => onRelatedClick(relatedId)}
                    data-faq-event="related_question_click"
                    data-question-id={relatedId}
                  >
                    <ExternalLink className="mr-2 h-4 w-4 flex-shrink-0" />
                    <span className="text-sm md:text-base truncate">{relatedId.replace(/-/g, " ")}</span>
                  </Button>
                ))}
              </div>
            </div>
          )}

          {/* CTA Buttons */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-3 border-t">
            <Button
              variant="default"
              size="lg"
              onClick={() => handleCTAClick("calculator")}
              className="bg-accent text-accent-foreground hover:bg-accent/90 text-base"
              data-faq-event="cta_click"
              data-cta-type="calculator"
            >
              <Calculator className="mr-2 h-5 w-5" />
              Oblicz w kalkulatorze
            </Button>
            <Button
              variant="outline"
              size="lg"
              onClick={() => handleCTAClick("consultation")}
              className="text-base"
              data-faq-event="cta_click"
              data-cta-type="consultation"
            >
              <Phone className="mr-2 h-5 w-5" />
              Umów konsultację
            </Button>
          </div>

          {/* Helpful Voting */}
          <div className="flex items-center justify-between pt-4 border-t">
            <p className="text-base text-gray-600">Czy ta odpowiedź była pomocna?</p>
            <div className="flex items-center gap-3">
              <Button
                variant={userVote === "positive" ? "default" : "outline"}
                size="lg"
                onClick={() => handleVote("positive")}
                className="gap-2"
                data-faq-event="helpful_vote"
                data-vote-type="positive"
              >
                <ThumbsUp className="h-5 w-5" />
                <span className="text-sm">{formatNumber(question.helpfulVotes.positive)}</span>
              </Button>
              <Button
                variant={userVote === "negative" ? "destructive" : "outline"}
                size="lg"
                onClick={() => handleVote("negative")}
                className="gap-2"
                data-faq-event="helpful_vote"
                data-vote-type="negative"
              >
                <ThumbsDown className="h-5 w-5" />
                <span className="text-sm">{formatNumber(question.helpfulVotes.negative)}</span>
              </Button>
            </div>
          </div>

          {/* Trust Signal */}
          <div className="text-center pt-3">
            <p className="text-sm text-gray-500">
              {formatNumber(question.helpfulVotes.positive + question.helpfulVotes.negative)} osób oceniło tę odpowiedź
            </p>
          </div>
        </motion.div>
      </AccordionContent>
    </AccordionItem>
  )
}
