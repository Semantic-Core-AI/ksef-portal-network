"use client"

export function triggerConfetti() {
  // Create confetti effect using canvas
  const canvas = document.createElement("canvas")
  canvas.style.position = "fixed"
  canvas.style.top = "0"
  canvas.style.left = "0"
  canvas.style.width = "100%"
  canvas.style.height = "100%"
  canvas.style.pointerEvents = "none"
  canvas.style.zIndex = "9999"
  document.body.appendChild(canvas)

  const ctx = canvas.getContext("2d")
  if (!ctx) return

  canvas.width = window.innerWidth
  canvas.height = window.innerHeight

  const particles: Array<{
    x: number
    y: number
    vx: number
    vy: number
    color: string
    size: number
    rotation: number
    rotationSpeed: number
  }> = []

  const colors = ["#C7A83B", "#2C6AA8", "#1E2A5E", "#10B981", "#F59E0B"]

  // Create particles
  for (let i = 0; i < 150; i++) {
    particles.push({
      x: Math.random() * canvas.width,
      y: -20,
      vx: (Math.random() - 0.5) * 8,
      vy: Math.random() * 3 + 2,
      color: colors[Math.floor(Math.random() * colors.length)],
      size: Math.random() * 8 + 4,
      rotation: Math.random() * 360,
      rotationSpeed: (Math.random() - 0.5) * 10,
    })
  }

  let animationFrame: number

  function animate() {
    if (!ctx) return
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    particles.forEach((p, index) => {
      p.x += p.vx
      p.y += p.vy
      p.vy += 0.1 // gravity
      p.rotation += p.rotationSpeed

      ctx.save()
      ctx.translate(p.x, p.y)
      ctx.rotate((p.rotation * Math.PI) / 180)
      ctx.fillStyle = p.color
      ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size)
      ctx.restore()

      // Remove particles that are off screen
      if (p.y > canvas.height) {
        particles.splice(index, 1)
      }
    })

    if (particles.length > 0) {
      animationFrame = requestAnimationFrame(animate)
    } else {
      document.body.removeChild(canvas)
    }
  }

  animate()

  // Cleanup after 5 seconds
  setTimeout(() => {
    if (animationFrame) {
      cancelAnimationFrame(animationFrame)
    }
    if (document.body.contains(canvas)) {
      document.body.removeChild(canvas)
    }
  }, 5000)
}
