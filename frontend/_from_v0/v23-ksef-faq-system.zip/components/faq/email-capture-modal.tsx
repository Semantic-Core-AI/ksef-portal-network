"use client"

import type React from "react"

import { useState } from "react"
import { Mail, Gift, CheckCircle } from "lucide-react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { motion, AnimatePresence } from "framer-motion"
import { trackReferralConversion } from "@/lib/referral-system"

interface EmailCaptureModalProps {
  isOpen: boolean
  onClose: () => void
  rewardTitle: string
  rewardDescription?: string
  onSubmit: (email: string) => void
}

export function EmailCaptureModal({
  isOpen,
  onClose,
  rewardTitle,
  rewardDescription,
  onSubmit,
}: EmailCaptureModalProps) {
  const [email, setEmail] = useState("")
  const [consent, setConsent] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [error, setError] = useState("")

  const validateEmail = (email: string) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    if (!email) {
      setError("Proszę podać adres email")
      return
    }

    if (!validateEmail(email)) {
      setError("Proszę podać prawidłowy adres email")
      return
    }

    if (!consent) {
      setError("Proszę zaakceptować zgodę na przetwarzanie danych")
      return
    }

    // Store email in localStorage for demo
    const emails = JSON.parse(localStorage.getItem("ksef_emails") || "[]")
    emails.push({ email, reward: rewardTitle, date: new Date().toISOString() })
    localStorage.setItem("ksef_emails", JSON.stringify(emails))

    trackReferralConversion(email, rewardTitle)

    onSubmit(email)
    setIsSubmitted(true)

    // Auto close after 3 seconds
    setTimeout(() => {
      onClose()
      setIsSubmitted(false)
      setEmail("")
      setConsent(false)
    }, 3000)
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <AnimatePresence mode="wait">
          {!isSubmitted ? (
            <motion.div
              key="form"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2 text-2xl">
                  <Gift className="h-6 w-6 text-accent" />
                  Odbierz swoją nagrodę!
                </DialogTitle>
                <DialogDescription className="text-base">
                  Podaj swój email aby otrzymać: <strong>{rewardTitle}</strong>
                  {rewardDescription && <p className="mt-2 text-sm">{rewardDescription}</p>}
                </DialogDescription>
              </DialogHeader>

              <form onSubmit={handleSubmit} className="space-y-4 mt-4">
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-base">
                    Adres email
                  </Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                    <Input
                      id="email"
                      type="email"
                      placeholder="twoj@email.pl"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="pl-10 h-12 text-base"
                      autoFocus
                    />
                  </div>
                </div>

                <div className="flex items-start space-x-2">
                  <Checkbox
                    id="consent"
                    checked={consent}
                    onCheckedChange={(checked) => setConsent(checked as boolean)}
                  />
                  <label htmlFor="consent" className="text-sm text-muted-foreground leading-tight cursor-pointer">
                    Zgadzam się na przetwarzanie moich danych osobowych w celu otrzymania materiałów edukacyjnych o KSeF
                  </label>
                </div>

                {error && (
                  <motion.p
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="text-sm text-destructive"
                  >
                    {error}
                  </motion.p>
                )}

                <div className="flex gap-3">
                  <Button type="submit" size="lg" className="flex-1 text-base">
                    Pobierz nagrodę
                  </Button>
                  <Button type="button" variant="outline" size="lg" onClick={onClose}>
                    Anuluj
                  </Button>
                </div>
              </form>
            </motion.div>
          ) : (
            <motion.div
              key="success"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-center py-8"
            >
              <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring", duration: 0.5 }}>
                <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
              </motion.div>
              <h3 className="text-2xl font-bold mb-2">Dziękujemy!</h3>
              <p className="text-muted-foreground">
                Nagroda została wysłana na adres: <strong>{email}</strong>
              </p>
            </motion.div>
          )}
        </AnimatePresence>
      </DialogContent>
    </Dialog>
  )
}
