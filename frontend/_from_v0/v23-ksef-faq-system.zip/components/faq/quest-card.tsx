"use client"

import { useState, useEffect } from "react"
import { Check, Lock, Play, Download, Share2, Trophy, GraduationCap, DollarSign, Scale } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { motion } from "framer-motion"
import type { Quest } from "@/lib/faq-types"
import { getQuestProgress, isQuestionCompleted, trackFAQEvent, shareOnSocial } from "@/lib/faq-utils"
import { faqQuestions } from "@/lib/faq-data"
import { triggerConfetti } from "./confetti-animation"
import { EmailCaptureModal } from "./email-capture-modal"

const iconMap = {
  GraduationCap,
  DollarSign,
  Scale,
}

interface QuestCardProps {
  quest: Quest
  onQuestionClick: (questionId: string) => void
}

export function QuestCard({ quest, onQuestionClick }: QuestCardProps) {
  const progress = getQuestProgress(quest.questions)
  const isCompleted = progress === 100
  const [showReward, setShowReward] = useState(false)
  const [showEmailModal, setShowEmailModal] = useState(false)
  const [hasShownConfetti, setHasShownConfetti] = useState(false)

  useEffect(() => {
    if (isCompleted && !hasShownConfetti) {
      triggerConfetti()
      setHasShownConfetti(true)
    }
  }, [isCompleted, hasShownConfetti])

  const IconComponent = iconMap[quest.icon as keyof typeof iconMap] || GraduationCap

  const handleQuestionClick = (questionId: string, index: number) => {
    if (index > 0) {
      const previousCompleted = quest.questions.slice(0, index).every((q) => isQuestionCompleted(q))

      if (!previousCompleted) {
        return
      }
    }

    trackFAQEvent({
      event: "faq_quest_started",
      questionId: quest.id,
    })
    onQuestionClick(questionId)
  }

  const handleShare = () => {
    const text = `Właśnie ukończyłem quest "${quest.title}" i zdobyłem certyfikat! #KSeF #eInvoicing`
    shareOnSocial("linkedin", text)
  }

  const handleDownloadReward = () => {
    trackFAQEvent({
      event: "faq_cta_click",
      ctaType: "download_reward",
      questionId: quest.id,
    })
    setShowEmailModal(true)
  }

  const handleEmailSubmit = (email: string) => {
    console.log("[v0] Email captured:", email, "for reward:", quest.reward.title)
  }

  return (
    <>
      <Card className="overflow-hidden hover:shadow-medium transition-shadow">
        <CardHeader className="bg-gradient-to-r from-primary/10 to-secondary/10 p-6">
          <div className="flex items-start justify-between">
            <div className="space-y-2">
              <CardTitle className="flex items-center gap-2 font-serif text-xl md:text-2xl">
                <IconComponent className="h-7 w-7 text-primary" />
                <span>{quest.title}</span>
              </CardTitle>
              <CardDescription className="text-base">{quest.description}</CardDescription>
            </div>
            <Badge variant="secondary" className="font-semibold text-sm py-1 px-3">
              {quest.badge}
            </Badge>
          </div>
        </CardHeader>

        <CardContent className="pt-6 pb-6 px-6 space-y-5">
          {/* Progress Bar */}
          <div className="space-y-3">
            <div className="flex items-center justify-between text-base">
              <span className="text-muted-foreground">Postęp</span>
              <span className="font-semibold text-primary text-lg">{progress}%</span>
            </div>
            <Progress value={progress} className="h-3" />
          </div>

          {/* Questions List */}
          <div className="space-y-3">
            {quest.questions.map((questionId, index) => {
              const question = faqQuestions.find((q) => q.id === questionId)
              const completed = isQuestionCompleted(questionId)
              const isLocked = index > 0 && !quest.questions.slice(0, index).every((q) => isQuestionCompleted(q))

              if (!question) return null

              return (
                <motion.div
                  key={questionId}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Button
                    variant={completed ? "secondary" : "outline"}
                    className="w-full justify-start text-left h-auto py-4 px-5 whitespace-normal"
                    onClick={() => handleQuestionClick(questionId, index)}
                    disabled={isLocked}
                  >
                    <div className="flex items-start gap-3 w-full">
                      <div className="flex-shrink-0 mt-0.5">
                        {completed ? (
                          <Check className="h-6 w-6 text-secondary" />
                        ) : isLocked ? (
                          <Lock className="h-6 w-6 text-muted-foreground" />
                        ) : (
                          <Play className="h-6 w-6 text-primary" />
                        )}
                      </div>
                      <div className="flex-1">
                        <p className="text-base font-medium leading-snug break-words">
                          Q{index + 1}: {question.question}
                        </p>
                        {completed && (
                          <p className="text-sm text-muted-foreground mt-1">+{quest.xpPerQuestion} XP zdobyte</p>
                        )}
                      </div>
                    </div>
                  </Button>
                </motion.div>
              )
            })}
          </div>

          {/* Reward Section */}
          <div className="pt-4 border-t space-y-4">
            <div className="flex items-start gap-3">
              <Trophy className="h-6 w-6 text-accent flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="font-semibold text-base">Nagroda za ukończenie:</p>
                <p className="text-base text-muted-foreground">{quest.reward.title}</p>
              </div>
            </div>

            {isCompleted ? (
              <div className="space-y-3">
                <Button
                  size="lg"
                  className="w-full bg-accent text-accent-foreground hover:bg-accent/90 text-base"
                  onClick={handleDownloadReward}
                >
                  <Download className="mr-2 h-5 w-5" />
                  Pobierz nagrodę
                </Button>
                <Button variant="outline" size="lg" className="w-full bg-transparent text-base" onClick={handleShare}>
                  <Share2 className="mr-2 h-5 w-5" />
                  Udostępnij osiągnięcie
                </Button>
              </div>
            ) : (
              <Button variant="outline" size="lg" className="w-full bg-transparent text-base" disabled>
                <Lock className="mr-2 h-5 w-5" />
                Ukończ wszystkie pytania aby odblokować
              </Button>
            )}
          </div>

          {/* XP Counter */}
          <div className="flex items-center justify-between text-base pt-3 border-t">
            <span className="text-muted-foreground">Całkowite XP:</span>
            <span className="font-bold text-primary text-lg">
              {quest.questions.filter((q) => isQuestionCompleted(q)).length * quest.xpPerQuestion}
              {isCompleted && ` + ${quest.bonusXP} bonus`} /{" "}
              {quest.questions.length * quest.xpPerQuestion + quest.bonusXP}
            </span>
          </div>
        </CardContent>
      </Card>

      <EmailCaptureModal
        isOpen={showEmailModal}
        onClose={() => setShowEmailModal(false)}
        rewardTitle={quest.reward.title}
        rewardDescription={quest.reward.description}
        onSubmit={handleEmailSubmit}
      />
    </>
  )
}
