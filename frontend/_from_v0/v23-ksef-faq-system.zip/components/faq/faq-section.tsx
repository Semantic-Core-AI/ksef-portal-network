"use client"

import { useState, useMemo } from "react"
import {
  Search,
  Filter,
  Clock,
  TrendingUp,
  Target,
  DollarSign,
  Settings,
  Scale,
  BarChart3,
  Rocket,
  Gamepad2,
  BookOpen,
  Flame,
  Trophy,
  CheckCircle2,
} from "lucide-react"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Accordion } from "@/components/ui/accordion"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { FloatingFAQButton } from "./floating-faq-button"
import { QuestCard } from "./quest-card"
import { FAQAccordionItem } from "./faq-accordion-item"
import { faqQuestions, quests, categories } from "@/lib/faq-data"
import { daysUntilDeadline, trackFAQEvent, getUserProgress } from "@/lib/faq-utils"
import { motion } from "framer-motion"
import { CountdownTimer } from "./countdown-timer"
import { AIChatbot } from "./ai-chatbot"
import { ReferralProgram } from "./referral-program"
import { Leaderboard } from "./leaderboard"
import { ViralShareCard } from "./viral-share-card"

const categoryIconMap = {
  Target,
  DollarSign,
  Settings,
  Scale,
  BarChart3,
  Rocket,
}

export function FAQSection() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState<string>("wszystkie")
  const [sortBy, setSortBy] = useState<"popular" | "recent" | "alphabetical">("popular")
  const [showFAQPanel, setShowFAQPanel] = useState(false)
  const [expandedQuestion, setExpandedQuestion] = useState<string | null>(null)

  const userProgress = getUserProgress()
  const deadline = daysUntilDeadline()

  const filteredQuestions = useMemo(() => {
    let filtered = faqQuestions

    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      filtered = filtered.filter(
        (q) =>
          q.question.toLowerCase().includes(query) ||
          q.quickAnswer.toLowerCase().includes(query) ||
          q.tags.some((tag) => tag.toLowerCase().includes(query)),
      )
    }

    if (selectedCategory !== "wszystkie") {
      filtered = filtered.filter((q) => q.category === selectedCategory)
    }

    switch (sortBy) {
      case "popular":
        filtered.sort((a, b) => b.views - a.views)
        break
      case "recent":
        filtered.sort((a, b) => b.lastUpdated.getTime() - a.lastUpdated.getTime())
        break
      case "alphabetical":
        filtered.sort((a, b) => a.question.localeCompare(b.question, "pl"))
        break
    }

    return filtered
  }, [searchQuery, selectedCategory, sortBy])

  const handleSearchChange = (value: string) => {
    setSearchQuery(value)
    if (value) {
      trackFAQEvent({ event: "faq_search_used", query: value })
    }
  }

  const handleCategoryChange = (category: string) => {
    setSelectedCategory(category)
    trackFAQEvent({ event: "faq_category_switched", category })
  }

  const handleQuestionClick = (questionId: string) => {
    setExpandedQuestion(questionId)
    setTimeout(() => {
      const element = document.getElementById(`faq-${questionId}`)
      element?.scrollIntoView({ behavior: "smooth", block: "center" })
    }, 100)
  }

  return (
    <section className="w-full py-12 md:py-20">
      <div className="container mx-auto px-6 max-w-7xl">
        <CountdownTimer />

        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12 space-y-5"
        >
          <Badge variant="destructive" className="mb-3 text-sm py-1.5 px-3">
            <Clock className="mr-1.5 h-4 w-4" />
            Do wejścia w życie KSeF: {deadline} dni
          </Badge>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-serif font-bold tracking-tight text-balance">
            <span className="text-white">Centrum </span>
            <span className="text-[#C7A83B]">Pytań</span>
            <span className="text-white"> KSeF</span>
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto text-pretty leading-relaxed">
            Wszystko czego potrzebujesz aby przygotować firmę na obowiązkowe e-fakturowanie
          </p>

          {userProgress.totalXP > 0 && (
            <div className="flex items-center justify-center gap-4 text-base">
              <Badge variant="secondary" className="gap-1.5 bg-secondary text-secondary-foreground py-1.5 px-3">
                <Trophy className="h-4 w-4" /> {userProgress.totalXP} XP
              </Badge>
              <Badge variant="secondary" className="gap-1.5 bg-secondary text-secondary-foreground py-1.5 px-3">
                <Flame className="h-4 w-4" /> {userProgress.streak} dni streak
              </Badge>
              <Badge variant="secondary" className="gap-1.5 bg-secondary text-secondary-foreground py-1.5 px-3">
                <CheckCircle2 className="h-4 w-4" /> {userProgress.completedQuestions.length} pytań
              </Badge>
            </div>
          )}
        </motion.div>

        {/* Search Bar */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="max-w-2xl mx-auto mb-10"
        >
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-6 w-6 text-gray-500" />
            <Input
              type="search"
              placeholder="Szukaj pytań... (np. 'koszt wdrożenia', 'termin', 'kary')"
              value={searchQuery}
              onChange={(e) => handleSearchChange(e.target.value)}
              className="pl-12 h-14 text-base md:text-lg bg-white text-gray-900 placeholder:text-gray-500 border-2 border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 rounded-xl shadow-md hover:shadow-lg transition-all"
              data-faq-event="search_input"
            />
          </div>
        </motion.div>

        {userProgress.totalXP > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="grid gap-6 md:grid-cols-2 mb-12"
          >
            <ReferralProgram />
            <Leaderboard />
          </motion.div>
        )}

        {/* Main Tabs */}
        <Tabs defaultValue="quests" className="space-y-8">
          <TabsList className="grid w-full grid-cols-3 max-w-md mx-auto h-12">
            <TabsTrigger value="quests" className="text-base gap-2">
              <Gamepad2 className="h-4 w-4" />
              Questy
            </TabsTrigger>
            <TabsTrigger value="wszystkie" className="text-base gap-2">
              <BookOpen className="h-4 w-4" />
              Wszystkie
            </TabsTrigger>
            <TabsTrigger value="popularne" className="text-base gap-2">
              <Flame className="h-4 w-4" />
              Popularne
            </TabsTrigger>
          </TabsList>

          {/* Quest Tab */}
          <TabsContent value="quests" className="space-y-8">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center mb-8">
              <h2 className="text-3xl md:text-4xl font-serif font-bold mb-3 text-white">
                Zdobądź wiedzę przez zabawę!
              </h2>
              <p className="text-base md:text-lg text-gray-300">Ukończ questy, zdobywaj XP i odblokowuj nagrody</p>
            </motion.div>

            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {quests.map((quest, index) => (
                <motion.div
                  key={quest.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <QuestCard quest={quest} onQuestionClick={handleQuestionClick} />
                </motion.div>
              ))}
            </div>

            <div className="mt-8">
              <ViralShareCard />
            </div>
          </TabsContent>

          {/* All Questions Tab */}
          <TabsContent value="wszystkie" className="space-y-6">
            {/* Category Filter */}
            <div className="flex items-center gap-3 overflow-x-auto pb-2">
              <Button
                variant={selectedCategory === "wszystkie" ? "default" : "outline"}
                size="lg"
                onClick={() => handleCategoryChange("wszystkie")}
                className={`text-base ${selectedCategory === "wszystkie" ? "bg-primary text-primary-foreground" : "bg-white"}`}
              >
                Wszystkie
              </Button>
              {categories.map((cat) => {
                const IconComponent = categoryIconMap[cat.icon as keyof typeof categoryIconMap]
                return (
                  <Button
                    key={cat.id}
                    variant={selectedCategory === cat.id ? "default" : "outline"}
                    size="lg"
                    onClick={() => handleCategoryChange(cat.id)}
                    className={`whitespace-nowrap text-base ${selectedCategory === cat.id ? "bg-primary text-primary-foreground" : "bg-white"}`}
                    data-faq-event="category_filter"
                    data-category={cat.id}
                  >
                    {IconComponent && <IconComponent className="h-5 w-5 mr-2" />}
                    {cat.name} ({cat.count})
                  </Button>
                )
              })}
            </div>

            {/* Sort Options */}
            <div className="flex items-center justify-between">
              <p className="text-base text-gray-300">Znaleziono {filteredQuestions.length} pytań</p>
              <div className="flex items-center gap-2">
                <Filter className="h-5 w-5 text-gray-400" />
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as any)}
                  className="text-base border rounded-md px-3 py-2 bg-white"
                >
                  <option value="popular">Najpopularniejsze</option>
                  <option value="recent">Najnowsze</option>
                  <option value="alphabetical">Alfabetycznie</option>
                </select>
              </div>
            </div>

            {/* Questions Accordion */}
            <Accordion
              type="single"
              collapsible
              value={expandedQuestion || undefined}
              onValueChange={setExpandedQuestion}
            >
              {filteredQuestions.map((question) => (
                <div key={question.id} id={`faq-${question.id}`}>
                  <FAQAccordionItem question={question} onRelatedClick={handleQuestionClick} />
                </div>
              ))}
            </Accordion>

            {filteredQuestions.length === 0 && (
              <div className="text-center py-12">
                <p className="text-gray-300">Nie znaleziono pytań pasujących do wyszukiwania.</p>
                <Button variant="link" onClick={() => setSearchQuery("")} className="mt-2">
                  Wyczyść wyszukiwanie
                </Button>
              </div>
            )}
          </TabsContent>

          {/* Popular Tab */}
          <TabsContent value="popularne" className="space-y-6">
            <div className="flex items-center gap-3 mb-6">
              <TrendingUp className="h-6 w-6 text-primary" />
              <h2 className="text-2xl md:text-3xl font-serif font-bold text-white">Najczęściej czytane pytania</h2>
            </div>

            <Accordion
              type="single"
              collapsible
              value={expandedQuestion || undefined}
              onValueChange={setExpandedQuestion}
            >
              {faqQuestions
                .filter((q) => q.isTrending || q.views > 2000)
                .sort((a, b) => b.views - a.views)
                .slice(0, 20)
                .map((question) => (
                  <div key={question.id} id={`faq-${question.id}`}>
                    <FAQAccordionItem question={question} onRelatedClick={handleQuestionClick} />
                  </div>
                ))}
            </Accordion>
          </TabsContent>
        </Tabs>
      </div>

      {/* Floating FAQ Button */}
      <FloatingFAQButton onClick={() => setShowFAQPanel(!showFAQPanel)} newTipsCount={3} />

      <AIChatbot />
    </section>
  )
}
