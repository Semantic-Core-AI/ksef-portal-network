"use client"

import { useEffect } from "react"
import { initializeReferralSystem } from "@/lib/referral-system"

export function ReferralTracker() {
  useEffect(() => {
    // Initialize referral system on mount
    initializeReferralSystem()
  }, [])

  return null // This is a tracking component, no UI
}
