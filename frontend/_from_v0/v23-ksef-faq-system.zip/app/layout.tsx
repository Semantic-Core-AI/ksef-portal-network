import type React from "react"
import type { Metadata } from "next"
import { Inter, Playfair_Display } from "next/font/google"
import { Analytics } from "@vercel/analytics/next"
import "./globals.css"
import { ReferralTracker } from "@/components/faq/referral-tracker"

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-sans",
  display: "swap",
})

const playfair = Playfair_Display({
  subsets: ["latin"],
  variable: "--font-serif",
  display: "swap",
})

export const metadata: Metadata = {
  title: "KSeF FAQ - Centrum Pytań o e-Fakturowaniu",
  description:
    "Kompleksowy przewodnik po Krajowym Systemie e-Faktur. Dowiedz się wszystkiego o kosztach, wdrożeniu i obowiązkach związanych z KSeF.",
  generator: "v0.app",
  keywords: ["KSeF", "e-faktury", "e-invoicing", "Polska", "VAT", "faktury elektroniczne"],
  openGraph: {
    title: "KSeF FAQ - Centrum Pytań",
    description: "Wszystko o Krajowym Systemie e-Faktur w jednym miejscu",
    type: "website",
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="pl" className={`${inter.variable} ${playfair.variable}`}>
      <body className="font-sans antialiased">
        <ReferralTracker />
        {children}
        <Analytics />
      </body>
    </html>
  )
}
