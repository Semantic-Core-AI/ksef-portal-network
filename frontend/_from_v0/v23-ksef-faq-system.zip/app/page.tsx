import { FAQSection } from "@/components/faq/faq-section"

export default function Home() {
  return (
    <main className="min-h-screen">
      <FAQSection />
    </main>
  )
}
