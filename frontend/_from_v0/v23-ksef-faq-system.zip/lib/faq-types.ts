export interface FAQQuestion {
  id: string
  category: string
  question: string
  quickAnswer: string
  detailedAnswer?: string
  interactiveElement?: "calculator" | "checklist" | "table" | "timeline"
  relatedQuestions: string[]
  views: number
  helpfulVotes: { positive: number; negative: number }
  isTrending: boolean
  lastUpdated: Date
  expertVerified: boolean
  tags: string[]
}

export interface Quest {
  id: string
  title: string
  icon: string // Changed from emoji to icon name for lucide-react
  badge: string
  description: string
  questions: string[]
  reward: {
    type: "pdf" | "checklist" | "voucher"
    title: string
    description: string
    requiresEmail: boolean
  }
  xpPerQuestion: number
  bonusXP: number
}

export interface UserProgress {
  completedQuestions: string[]
  totalXP: number
  earnedBadges: string[]
  activeQuest?: string
  streak: number
  lastVisit: Date
  email?: string
  helpfulVotesGiven: Record<string, "positive" | "negative">
  referralCode?: string
  referredBy?: string
  referralCount: number
  sharedAchievements: string[]
  companyName?: string
  companySize?: string
}

export interface ReferralData {
  code: string
  referredUsers: number
  bonusXP: number
  unlockedRewards: string[]
}

export interface LeaderboardEntry {
  userId: string
  companyName: string
  totalXP: number
  completedQuests: number
  streak: number
  rank: number
}

export type FAQCategory = "podstawy" | "koszty" | "wdrozenie" | "prawo" | "integracje" | "post-wdrozenie"

export interface FAQAnalyticsEvent {
  event: string
  questionId?: string
  category?: string
  ctaType?: string
  source?: string
  platform?: string
  query?: string
}
