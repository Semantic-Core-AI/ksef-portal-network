import type { FAQAnalyticsEvent, UserProgress, ReferralData, LeaderboardEntry } from "./faq-types"

// LocalStorage keys
const STORAGE_KEYS = {
  USER_PROGRESS: "ksef_faq_user_progress",
  COMPLETED_QUESTIONS: "ksef_faq_completed",
  HELPFUL_VOTES: "ksef_faq_votes",
  LAST_VISIT: "ksef_faq_last_visit",
}

// Get user progress from localStorage
export function getUserProgress(): UserProgress {
  if (typeof window === "undefined") {
    return getDefaultProgress()
  }

  try {
    const stored = localStorage.getItem(STORAGE_KEYS.USER_PROGRESS)
    if (stored) {
      const progress = JSON.parse(stored)
      return {
        ...progress,
        lastVisit: new Date(progress.lastVisit),
      }
    }
  } catch (error) {
    console.error("[v0] Error loading user progress:", error)
  }

  return getDefaultProgress()
}

// Save user progress to localStorage
export function saveUserProgress(progress: UserProgress): void {
  if (typeof window === "undefined") return

  try {
    localStorage.setItem(STORAGE_KEYS.USER_PROGRESS, JSON.stringify(progress))
  } catch (error) {
    console.error("[v0] Error saving user progress:", error)
  }
}

// Mark question as completed
export function markQuestionCompleted(questionId: string): UserProgress {
  const progress = getUserProgress()

  if (!progress.completedQuestions.includes(questionId)) {
    progress.completedQuestions.push(questionId)
    progress.totalXP += 10 // Base XP per question
    progress.lastVisit = new Date()

    saveUserProgress(progress)
  }

  return progress
}

// Check if question is completed
export function isQuestionCompleted(questionId: string): boolean {
  const progress = getUserProgress()
  return progress.completedQuestions.includes(questionId)
}

// Calculate quest progress
export function getQuestProgress(questQuestions: string[]): number {
  const progress = getUserProgress()
  const completed = questQuestions.filter((q) => progress.completedQuestions.includes(q)).length

  return Math.round((completed / questQuestions.length) * 100)
}

// Check if quest is completed
export function isQuestCompleted(questQuestions: string[]): boolean {
  return getQuestProgress(questQuestions) === 100
}

// Track analytics event
export function trackFAQEvent(event: FAQAnalyticsEvent): void {
  if (typeof window === "undefined") return

  console.log("[v0] FAQ Analytics Event:", event)

  // In production, send to analytics service
  // Example: gtag('event', event.event, { ...event });
}

// Calculate streak
export function calculateStreak(): number {
  const progress = getUserProgress()
  const lastVisit = progress.lastVisit
  const now = new Date()

  const daysDiff = Math.floor((now.getTime() - lastVisit.getTime()) / (1000 * 60 * 60 * 24))

  if (daysDiff === 0) {
    return progress.streak
  } else if (daysDiff === 1) {
    return progress.streak + 1
  } else {
    return 1 // Reset streak
  }
}

// Get default progress
function getDefaultProgress(): UserProgress {
  return {
    completedQuestions: [],
    totalXP: 0,
    earnedBadges: [],
    streak: 1,
    lastVisit: new Date(),
    helpfulVotesGiven: {},
    referralCode: "",
    referredBy: "",
    referralCount: 0,
    companyName: "",
  }
}

// Format number with Polish locale
export function formatNumber(num: number): string {
  return new Intl.NumberFormat("pl-PL").format(num)
}

// Calculate days until deadline
export function daysUntilDeadline(): number {
  const deadline = new Date("2026-02-01")
  const now = new Date()
  const diff = deadline.getTime() - now.getTime()
  return Math.ceil(diff / (1000 * 60 * 60 * 24))
}

// Share on social media
export function shareOnSocial(platform: "linkedin" | "twitter" | "facebook", text: string, url?: string): void {
  const shareUrl = url || window.location.href
  const encodedText = encodeURIComponent(text)
  const encodedUrl = encodeURIComponent(shareUrl)

  let shareLink = ""

  switch (platform) {
    case "linkedin":
      shareLink = `https://www.linkedin.com/sharing/share-offsite/?url=${encodedUrl}`
      break
    case "twitter":
      shareLink = `https://twitter.com/intent/tweet?text=${encodedText}&url=${encodedUrl}`
      break
    case "facebook":
      shareLink = `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`
      break
  }

  if (shareLink) {
    window.open(shareLink, "_blank", "width=600,height=400")
    trackFAQEvent({ event: "faq_social_share", platform })
  }
}

export function generateReferralCode(): string {
  return Math.random().toString(36).substring(2, 10).toUpperCase()
}

export function getUserReferralCode(): string {
  const progress = getUserProgress()

  if (progress.referralCode) {
    return progress.referralCode
  }

  const newCode = generateReferralCode()
  progress.referralCode = newCode
  saveUserProgress(progress)

  return newCode
}

export function trackReferral(referralCode: string): void {
  if (typeof window === "undefined") return

  const progress = getUserProgress()

  if (!progress.referredBy && referralCode !== progress.referralCode) {
    progress.referredBy = referralCode
    saveUserProgress(progress)

    trackFAQEvent({
      event: "faq_referral_used",
      source: referralCode,
    })
  }
}

export function incrementReferralCount(): void {
  const progress = getUserProgress()
  progress.referralCount = (progress.referralCount || 0) + 1
  progress.totalXP += 50 // Bonus XP for referral
  saveUserProgress(progress)
}

export function getReferralStats(): ReferralData {
  const progress = getUserProgress()
  const referralCount = progress.referralCount || 0

  return {
    code: getUserReferralCode(),
    referredUsers: referralCount,
    bonusXP: referralCount * 50,
    unlockedRewards: referralCount >= 3 ? ["premium_calculator", "expert_consultation"] : [],
  }
}

export function generateAchievementShareUrl(achievement: string, xp: number): string {
  const baseUrl = typeof window !== "undefined" ? window.location.origin : ""
  return `${baseUrl}/api/og?achievement=${encodeURIComponent(achievement)}&xp=${xp}`
}

export function getLeaderboardData(): LeaderboardEntry[] {
  const currentUser = getUserProgress()

  // Mock leaderboard data
  const mockData: LeaderboardEntry[] = [
    { userId: "user1", companyName: "TechCorp Sp. z o.o.", totalXP: 850, completedQuests: 3, streak: 12, rank: 1 },
    { userId: "user2", companyName: "FinanceHub S.A.", totalXP: 720, completedQuests: 3, streak: 8, rank: 2 },
    { userId: "user3", companyName: "RetailPro Polska", totalXP: 680, completedQuests: 2, streak: 15, rank: 3 },
    { userId: "user4", companyName: "LogisticsMaster", totalXP: 590, completedQuests: 2, streak: 5, rank: 4 },
    { userId: "user5", companyName: "ConsultingPlus", totalXP: 540, completedQuests: 2, streak: 7, rank: 5 },
  ]

  // Add current user if they have XP
  if (currentUser.totalXP > 0) {
    const userEntry: LeaderboardEntry = {
      userId: "current",
      companyName: currentUser.companyName || "Twoja Firma",
      totalXP: currentUser.totalXP,
      completedQuests: currentUser.earnedBadges.length,
      streak: currentUser.streak,
      rank: mockData.filter((e) => e.totalXP > currentUser.totalXP).length + 1,
    }

    mockData.push(userEntry)
  }

  return mockData
    .sort((a, b) => b.totalXP - a.totalXP)
    .map((entry, index) => ({
      ...entry,
      rank: index + 1,
    }))
}
