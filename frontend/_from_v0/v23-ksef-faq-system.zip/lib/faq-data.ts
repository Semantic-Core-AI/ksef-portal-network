import type { FAQQuestion, Quest } from "./faq-types"

export const faqQuestions: FAQQuestion[] = [
  // KATEGORIA 1: Podstawy KSeF
  {
    id: "co-to-jest-ksef",
    category: "podstawy",
    question: "Co to jest KSeF i dlaczego został wprowadzony?",
    quickAnswer:
      "KSeF (Krajowy System e-Faktur) to rządowy system elektronicznego fakturowania, który zastąpi tradycyjne faktury papierowe i PDF. Został wprowadzony aby zwalczać szarą strefę, uprościć rozliczenia VAT i zdigitalizować polską gospodarkę.",
    detailedAnswer:
      "Krajowy System e-Faktur to centralna platforma rządowa, przez którą będą przesyłane wszystkie faktury w Polsce. System automatycznie weryfikuje poprawność faktur, eliminuje błędy i umożliwia natychmiastową kontrolę VAT. Ministerstwo Finansów szacuje, że KSeF zmniejszy lukę VAT o 5-7 miliardów złotych rocznie.",
    relatedQuestions: ["kiedy-wdrozyc-ksef", "kary-za-niewdrozenie", "kto-musi-wdrozyc"],
    views: 3247,
    helpfulVotes: { positive: 289, negative: 12 },
    isTrending: true,
    lastUpdated: new Date("2025-01-15"),
    expertVerified: true,
    tags: ["podstawy", "definicja", "cel"],
  },
  {
    id: "kiedy-wdrozyc-ksef",
    category: "podstawy",
    question: "Kiedy dokładnie muszę wdrożyć KSeF w mojej firmie?",
    quickAnswer:
      "Obowiązkowe wdrożenie KSeF dla wszystkich firm rozpoczyna się 1 lutego 2026 roku. Możesz jednak wdrożyć system dobrowolnie już teraz i skorzystać z ulg podatkowych.",
    detailedAnswer:
      "Harmonogram wdrożenia KSeF:\n\n• 1 lipca 2024 - start dobrowolnego okresu (z ulgami)\n• 1 lutego 2026 - obowiązek dla WSZYSTKICH firm (bez wyjątków)\n• Brak możliwości odroczenia dla małych firm\n\nWcześniejsze wdrożenie daje korzyści: 14-dniowy termin płatności VAT zamiast standardowego, automatyczne rozliczenia, mniej kontroli skarbowych.",
    relatedQuestions: ["co-to-jest-ksef", "kary-za-niewdrozenie", "dobrowolne-wdrozenie"],
    views: 2891,
    helpfulVotes: { positive: 267, negative: 8 },
    isTrending: true,
    lastUpdated: new Date("2025-01-20"),
    expertVerified: true,
    tags: ["termin", "obowiązek", "harmonogram"],
  },
  {
    id: "kto-musi-wdrozyc",
    category: "podstawy",
    question: "Czy mogę uniknąć obowiązku wdrożenia KSeF?",
    quickAnswer:
      "NIE. KSeF jest obowiązkowy dla wszystkich firm i osób prowadzących działalność gospodarczą w Polsce, bez względu na wielkość czy formę prawną. Nie ma żadnych wyjątków.",
    detailedAnswer:
      "Obowiązek dotyczy:\n\n✓ Wszystkich podatników VAT\n✓ Firm na ryczałcie (od 2026)\n✓ Jednoosobowych działalności gospodarczych\n✓ Korporacji i koncernów\n✓ Organizacji non-profit wystawiających faktury\n\nJedyne zwolnienie: faktury dla konsumentów (B2C) - te mogą pozostać w starej formie, ale KSeF jest zalecany.",
    relatedQuestions: ["kiedy-wdrozyc-ksef", "kary-za-niewdrozenie", "male-firmy-koszty"],
    views: 1834,
    helpfulVotes: { positive: 178, negative: 15 },
    isTrending: false,
    lastUpdated: new Date("2025-01-10"),
    expertVerified: true,
    tags: ["obowiązek", "wyjątki", "zakres"],
  },
  {
    id: "kary-za-niewdrozenie",
    category: "podstawy",
    question: "Jakie są kary za niewdrożenie KSeF w terminie?",
    quickAnswer:
      "Kary są BARDZO wysokie: od 500 zł za każdą fakturę wystawioną poza systemem, do 100% wartości transakcji w przypadku powtarzających się naruszeń. Dodatkowo: kontrole skarbowe, blokada kont, utrata ulg.",
    detailedAnswer:
      "Szczegółowe kary:\n\nZa każdą fakturę poza KSeF: 500-5,000 zł\nZa systematyczne naruszenia: do 100% wartości transakcji\nDodatkowe sankcje:\n   • Utrata prawa do odliczenia VAT\n   • Priorytetowe kontrole skarbowe\n   • Blokada zwrotów VAT\n   • Kary dla członków zarządu (odpowiedzialność osobista)\n\nPrzykład: Firma wystawiająca 200 faktur/miesiąc poza systemem = 100,000 zł kary miesięcznie!",
    relatedQuestions: ["kiedy-wdrozyc-ksef", "ile-kosztuje-wdrozenie", "co-to-jest-ksef"],
    views: 4123,
    helpfulVotes: { positive: 398, negative: 9 },
    isTrending: true,
    lastUpdated: new Date("2025-01-22"),
    expertVerified: true,
    tags: ["kary", "sankcje", "ryzyko"],
  },
  {
    id: "jakie-faktury-ksef",
    category: "podstawy",
    question: "Czy KSeF dotyczy wszystkich faktur czy tylko niektórych?",
    quickAnswer:
      "KSeF dotyczy WSZYSTKICH faktur VAT wystawianych między firmami (B2B). Faktury dla konsumentów (B2C) mogą pozostać w starej formie, ale zaleca się KSeF dla pełnej automatyzacji.",
    detailedAnswer:
      "Faktury objęte KSeF:\n\nFaktury VAT (B2B) - OBOWIĄZKOWO\nFaktury korygujące - OBOWIĄZKOWO\nFaktury zaliczkowe - OBOWIĄZKOWO\nFaktury eksportowe - OBOWIĄZKOWO\n\nFaktury dla konsumentów (B2C) - OPCJONALNIE (ale zalecane)\n\nParagony fiskalne - poza systemem\nFaktury sprzed 1.02.2026 - nie wymagają konwersji",
    relatedQuestions: ["co-to-jest-ksef", "faktury-b2c-ksef", "faktury-zagraniczne"],
    views: 1567,
    helpfulVotes: { positive: 142, negative: 11 },
    isTrending: false,
    lastUpdated: new Date("2025-01-18"),
    expertVerified: true,
    tags: ["zakres", "faktury", "B2B", "B2C"],
  },
  {
    id: "wplyw-na-prace",
    category: "podstawy",
    question: "Jak KSeF wpłynie na moją codzienną pracę z fakturami?",
    quickAnswer:
      "KSeF UPROŚCI Twoją pracę: automatyczne wysyłanie faktur, natychmiastowe potwierdzenia, brak błędów w numeracji, automatyczne archiwizowanie. Początkowy okres adaptacji (2-4 tygodnie), potem znacznie szybsza obsługa.",
    detailedAnswer:
      "Zmiany w codziennej pracy:\n\nPLUSY:\n• Wystawienie faktury: 30 sekund (zamiast 5 minut)\n• Automatyczna numeracja (brak błędów)\n• Natychmiastowe potwierdzenie odbioru\n• Brak wysyłania PDF emailem\n• Automatyczne archiwum (7 lat)\n• Integracja z księgowością\n\nMINUSY:\n• Wymaga połączenia internetowego\n• Początkowe szkolenie (1-2 dni)\n• Nowy interfejs do nauki",
    relatedQuestions: ["szkolenia-pracownikow", "ile-trwa-wdrozenie", "integracja-z-systemem"],
    views: 987,
    helpfulVotes: { positive: 89, negative: 7 },
    isTrending: false,
    lastUpdated: new Date("2025-01-12"),
    expertVerified: false,
    tags: ["praca", "proces", "zmiany"],
  },
  {
    id: "dobrowolne-wdrozenie",
    category: "podstawy",
    question: "Czy mogę wdrożyć KSeF dobrowolnie przed obowiązkowym terminem?",
    quickAnswer:
      "TAK! Dobrowolne wdrożenie jest możliwe od 1 lipca 2024 i daje znaczące korzyści: 14-dniowy termin płatności VAT (zamiast standardowego), mniej kontroli, ulgi podatkowe, przewaga konkurencyjna.",
    detailedAnswer:
      "Korzyści wcześniejszego wdrożenia:\n\nFINANSOWE:\n• Skrócony termin rozliczenia VAT (14 dni zamiast miesiąca)\n• Szybsze zwroty VAT\n• Możliwość ubiegania się o dofinansowanie\n\nBEZPIECZEŃSTWO:\n• Mniej kontroli skarbowych\n• Automatyczna weryfikacja faktur\n• Brak kar za błędy w okresie dobrowolnym\n\nBIZNESOWE:\n• Przewaga nad konkurencją\n• Lepsza organizacja\n• Czas na naukę przed obowiązkiem",
    relatedQuestions: ["kiedy-wdrozyc-ksef", "korzysci-wczesnego-wdrozenia", "ile-kosztuje-wdrozenie"],
    views: 1245,
    helpfulVotes: { positive: 118, negative: 6 },
    isTrending: false,
    lastUpdated: new Date("2025-01-16"),
    expertVerified: true,
    tags: ["dobrowolne", "korzyści", "wcześniej"],
  },
  {
    id: "korzysci-wczesnego-wdrozenia",
    category: "podstawy",
    question: "Jakie korzyści daje wcześniejsze wdrożenie KSeF?",
    quickAnswer:
      "Wcześniejsze wdrożenie to: szybsze zwroty VAT (14 dni), mniej kontroli skarbowych, czas na naukę bez presji, przewaga konkurencyjna, możliwość dofinansowania, automatyzacja procesów.",
    detailedAnswer:
      "Pełna lista korzyści:\n\n1. FINANSOWE (oszczędność ~15,000 zł/rok):\n   • Szybsze zwroty VAT\n   • Mniej błędów = mniej kar\n   • Niższe koszty księgowości\n\n2. OPERACYJNE:\n   • Automatyzacja fakturowania\n   • Mniej papierkowej roboty\n   • Szybsza obsługa klientów\n\n3. STRATEGICZNE:\n   • Przewaga nad konkurencją\n   • Lepsza reputacja\n   • Gotowość na przyszłość\n\n4. PRAWNE:\n   • Mniej kontroli\n   • Brak kar w okresie adaptacji",
    relatedQuestions: ["dobrowolne-wdrozenie", "ile-kosztuje-wdrozenie", "jak-dlugo-trwa-wdrozenie"],
    views: 876,
    helpfulVotes: { positive: 82, negative: 4 },
    isTrending: false,
    lastUpdated: new Date("2025-01-14"),
    expertVerified: true,
    tags: ["korzyści", "ROI", "wcześniej"],
  },
  {
    id: "zastepuje-obecny-system",
    category: "podstawy",
    question: "Czy KSeF zastępuje obecny system fakturowania?",
    quickAnswer:
      "TAK, całkowicie. Od 1 lutego 2026 wszystkie faktury VAT B2B MUSZĄ być wystawiane przez KSeF. Faktury PDF/papierowe nie będą już ważne prawnie (z wyjątkiem B2C).",
    detailedAnswer:
      "Co się zmienia:\n\nKONIEC:\n• Faktury PDF wysyłane emailem\n• Faktury papierowe\n• Własna numeracja (częściowo)\n• Ręczne archiwizowanie\n\nNOWY STANDARD:\n• Wszystko przez KSeF\n• Automatyczna numeracja\n• Cyfrowe archiwum (7 lat)\n• Natychmiastowa weryfikacja\n\nUWAGA: Stare faktury (sprzed 02.2026) nie wymagają konwersji, ale muszą być przechowywane przez 5 lat.",
    relatedQuestions: ["co-to-jest-ksef", "jakie-faktury-ksef", "migracja-starych-faktur"],
    views: 1432,
    helpfulVotes: { positive: 134, negative: 9 },
    isTrending: false,
    lastUpdated: new Date("2025-01-19"),
    expertVerified: true,
    tags: ["zmiana", "zastąpienie", "nowy-system"],
  },
  {
    id: "kto-odpowiedzialny",
    category: "podstawy",
    question: "Kto w firmie będzie odpowiedzialny za obsługę KSeF?",
    quickAnswer:
      "Zazwyczaj dział księgowości lub osoba wystawiająca faktury. W małych firmach: właściciel lub księgowy. Ważne: wymaga przeszkolenia (1-2 dni) i nadania uprawnień w systemie.",
    detailedAnswer:
      "Podział odpowiedzialności:\n\nDUŻE FIRMY:\n• Dział księgowości: wystawianie faktur\n• IT: integracja systemów\n• Zarząd: nadzór i odpowiedzialność prawna\n\nMAŁE FIRMY:\n• Właściciel lub główny księgowy\n• Opcjonalnie: biuro rachunkowe\n\nWYMAGANIA:\n• Szkolenie z obsługi KSeF (4-8h)\n• Profil zaufany lub e-podpis\n• Upoważnienie od firmy\n• Znajomość podstaw VAT",
    relatedQuestions: ["szkolenia-pracownikow", "uprawnienia-ksef", "biuro-rachunkowe"],
    views: 743,
    helpfulVotes: { positive: 71, negative: 5 },
    isTrending: false,
    lastUpdated: new Date("2025-01-11"),
    expertVerified: false,
    tags: ["odpowiedzialność", "role", "uprawnienia"],
  },

  // KATEGORIA 2: Koszty & ROI
  {
    id: "ile-kosztuje-wdrozenie",
    category: "koszty",
    question: "Ile kosztuje wdrożenie KSeF w mojej firmie?",
    quickAnswer:
      "Koszt zależy od wielkości firmy: mikrofirma (8,000-10,000 zł), średnia firma (10,000-15,000 zł), duża firma (15,000-25,000+ zł). W cenie: licencja, wdrożenie, szkolenia, wsparcie przez 12 miesięcy.",
    detailedAnswer:
      "Szczegółowe rozbicie kosztów:\n\nMIKROFIRMA (<2M EUR przychodu):\n• Licencja: 3,000-4,000 zł/rok\n• Wdrożenie: 3,000-4,000 zł\n• Szkolenia: 1,000-1,500 zł\n• Wsparcie: 500-1,000 zł/mies\nRAZEM: 8,000-10,000 zł pierwszy rok\n\nŚREDNIA FIRMA (2-10M EUR):\n• Licencja: 5,000-7,000 zł/rok\n• Wdrożenie: 5,000-7,000 zł\n• Szkolenia: 2,000-3,000 zł\n• Wsparcie: 1,000-1,500 zł/mies\nRAZEM: 10,000-15,000 zł pierwszy rok\n\nDUŻA FIRMA (>10M EUR):\n• Licencja: 8,000-12,000 zł/rok\n• Wdrożenie: 8,000-15,000 zł\n• Integracje: 5,000-10,000 zł\n• Wsparcie: 2,000-3,000 zł/mies\nRAZEM: 15,000-25,000+ zł pierwszy rok",
    interactiveElement: "calculator",
    relatedQuestions: ["ukryte-koszty", "koszty-miesieczne", "dofinansowanie-ksef"],
    views: 5234,
    helpfulVotes: { positive: 487, negative: 23 },
    isTrending: true,
    lastUpdated: new Date("2025-01-23"),
    expertVerified: true,
    tags: ["koszt", "wdrożenie", "cena"],
  },
  {
    id: "ukryte-koszty",
    category: "koszty",
    question: "Czy są ukryte koszty wdrożenia KSeF?",
    quickAnswer:
      "Większość dostawców nie ma ukrytych kosztów, ale UWAŻAJ na: limity faktur (dopłaty za przekroczenie), koszty dodatkowych integracji, płatne aktualizacje, wyższe ceny wsparcia po okresie gwarancji.",
    detailedAnswer:
      "Potencjalne dodatkowe koszty:\n\nCZĘSTO POMIJANE:\n• Przekroczenie limitu faktur: +50-200 zł/100 faktur\n• Dodatkowe stanowiska: +500-1,000 zł/użytkownik/rok\n• Integracje custom: +2,000-5,000 zł/integracja\n• Migracja danych: +1,000-3,000 zł\n• Rozszerzone wsparcie: +500-1,500 zł/mies\n\nJAK UNIKNĄĆ:\n• Pytaj o ALL-INCLUSIVE pakiety\n• Sprawdź limity w umowie\n• Negocjuj stałą cenę na 3 lata\n• Wybieraj dostawców z transparentnym cennikiem",
    relatedQuestions: ["ile-kosztuje-wdrozenie", "koszty-miesieczne", "jak-wybrac-dostawce"],
    views: 2876,
    helpfulVotes: { positive: 267, negative: 18 },
    isTrending: true,
    lastUpdated: new Date("2025-01-21"),
    expertVerified: true,
    tags: ["koszty", "ukryte", "pułapki"],
  },
  {
    id: "koszty-miesieczne",
    category: "koszty",
    question: "Jakie są koszty miesięczne po wdrożeniu KSeF?",
    quickAnswer:
      "Koszty miesięczne: 300-2,500 zł w zależności od wielkości firmy. W cenie: licencja, wsparcie techniczne, aktualizacje, hosting. Bez dodatkowych opłat za faktury (w większości pakietów).",
    detailedAnswer:
      "Miesięczne koszty operacyjne:\n\nMIKROFIRMA:\n• Licencja: 250-400 zł/mies\n• Wsparcie: 50-150 zł/mies\nRAZEM: 300-550 zł/mies\n\nŚREDNIA FIRMA:\n• Licencja: 500-800 zł/mies\n• Wsparcie: 200-400 zł/mies\nRAZEM: 700-1,200 zł/mies\n\nDUŻA FIRMA:\n• Licencja: 1,000-1,800 zł/mies\n• Wsparcie: 500-700 zł/mies\nRAZEM: 1,500-2,500 zł/mies\n\nCO JEST WLICZONE:\n• Nielimitowane faktury (w większości pakietów)\n• Aktualizacje systemu\n• Wsparcie techniczne (email/telefon)\n• Hosting i bezpieczeństwo\n• Archiwizacja (7 lat)",
    relatedQuestions: ["ile-kosztuje-wdrozenie", "co-wliczone-w-cene", "oszczednosci-ksef"],
    views: 1987,
    helpfulVotes: { positive: 178, negative: 12 },
    isTrending: false,
    lastUpdated: new Date("2025-01-17"),
    expertVerified: true,
    tags: ["koszty", "miesięczne", "abonament"],
  },
  {
    id: "dofinansowanie-ksef",
    category: "koszty",
    question: "Czy mogę dostać dofinansowanie na wdrożenie KSeF?",
    quickAnswer:
      "TAK! Dostępne programy: Polska Cyfrowa (do 85% kosztów dla mikrofirm), PARP (do 50,000 zł), ulgi podatkowe (odliczenie 100% kosztów), kredyty preferencyjne (oprocentowanie 2-3%).",
    detailedAnswer:
      "Źródła dofinansowania:\n\nDOTACJE:\n• Program Polska Cyfrowa: do 85% kosztów (max 100,000 zł)\n• PARP: do 50,000 zł dla MŚP\n• Fundusze UE: różne programy regionalne\n\nULGI PODATKOWE:\n• 100% kosztów wdrożenia odliczane od podatku\n• Przyspieszona amortyzacja\n• Ulga B+R (jeśli custom development)\n\nKREDYTY:\n• BGK: kredyty preferencyjne 2-3% oprocentowania\n• Banki komercyjne: linie kredytowe dla digitalizacji\n\n📋 JAK APLIKOWAĆ:\n• Sprawdź kwalifikowalność na biznes.gov.pl\n• Przygotuj biznesplan\n• Złóż wniosek (termin: do 30.06.2025)",
    relatedQuestions: ["ile-kosztuje-wdrozenie", "male-firmy-koszty", "jak-aplikowac-dotacje"],
    views: 3421,
    helpfulVotes: { positive: 312, negative: 15 },
    isTrending: true,
    lastUpdated: new Date("2025-01-24"),
    expertVerified: true,
    tags: ["dofinansowanie", "dotacje", "ulgi"],
  },
  {
    id: "jak-dlugo-zwrot-inwestycji",
    category: "koszty",
    question: "Jak długo zwróci się inwestycja w KSeF?",
    quickAnswer:
      "ROI: 12-18 miesięcy dla większości firm. Oszczędności: mniej błędów (5,000-15,000 zł/rok), szybsza obsługa (20-30h/mies), mniej kontroli, szybsze zwroty VAT.",
    detailedAnswer:
      "Analiza zwrotu z inwestycji:\n\nOSZCZĘDNOŚCI ROCZNE:\n• Mniej błędów w fakturach: 5,000-15,000 zł\n• Oszczędność czasu (20-30h/mies): 10,000-20,000 zł\n• Mniej kar i kontroli: 3,000-10,000 zł\n• Szybsze zwroty VAT: 2,000-5,000 zł\n• Niższe koszty księgowości: 3,000-8,000 zł\nRAZEM: 23,000-58,000 zł/rok\n\nPRZYKŁAD (średnia firma):\n• Koszt wdrożenia: 12,000 zł\n• Koszty roczne: 10,000 zł\n• Oszczędności roczne: 35,000 zł\n• ROI: 12-15 miesięcy\n• Zysk po 3 latach: 83,000 zł\n\nKORZYŚCI NIEMIERZALNE:\n• Lepsza reputacja\n• Przewaga konkurencyjna\n• Gotowość na przyszłość",
    interactiveElement: "calculator",
    relatedQuestions: ["ile-kosztuje-wdrozenie", "oszczednosci-ksef", "korzysci-wczesnego-wdrozenia"],
    views: 1654,
    helpfulVotes: { positive: 156, negative: 8 },
    isTrending: false,
    lastUpdated: new Date("2025-01-20"),
    expertVerified: true,
    tags: ["ROI", "zwrot", "oszczędności"],
  },
  {
    id: "co-wliczone-w-cene",
    category: "koszty",
    question: "Co jest wliczone w cenę wdrożenia KSeF?",
    quickAnswer:
      "Standardowy pakiet: licencja (12 mies), instalacja i konfiguracja, szkolenia (2-4h), podstawowe integracje, wsparcie techniczne (email/telefon), aktualizacje, hosting, archiwizacja.",
    detailedAnswer:
      "Szczegółowy zakres pakietu:\n\nZAWSZE WLICZONE:\n• Licencja na oprogramowanie (12 miesięcy)\n• Instalacja i konfiguracja\n• Szkolenie dla 2-5 osób (4-8h)\n• Integracja z systemem księgowym (standardowe)\n• Wsparcie techniczne (email, telefon, chat)\n• Aktualizacje systemu\n• Hosting i bezpieczeństwo\n• Archiwizacja faktur (7 lat)\n• Dokumentacja i instrukcje\n\nCZĘSTO DODATKOWO PŁATNE:\n• Integracje custom (SAP, Oracle, etc.)\n• Szkolenia dla >5 osób\n• Wsparcie 24/7\n• Dedykowany opiekun\n• Migracja starych danych\n• Rozszerzona gwarancja",
    relatedQuestions: ["ile-kosztuje-wdrozenie", "ukryte-koszty", "koszty-miesieczne"],
    views: 1234,
    helpfulVotes: { positive: 115, negative: 7 },
    isTrending: false,
    lastUpdated: new Date("2025-01-18"),
    expertVerified: false,
    tags: ["zakres", "pakiet", "wliczone"],
  },
  {
    id: "darmowe-rozwiazania",
    category: "koszty",
    question: "Czy są darmowe rozwiązania KSeF?",
    quickAnswer:
      "TAK, ale ograniczone. Ministerstwo Finansów udostępnia darmowy portal KSeF, ale bez automatyzacji i integracji. Dla firm >50 faktur/mies zalecane są płatne rozwiązania (oszczędność czasu = oszczędność pieniędzy).",
    detailedAnswer:
      "Porównanie opcji:\n\nDARMOWY PORTAL MF:\n• Całkowicie darmowy\n• Oficjalny i bezpieczny\n• Wystarczy profil zaufany\n\nMINUSY:\n• Ręczne wypełnianie każdej faktury\n• Brak integracji z księgowością\n• Brak automatyzacji\n• Czasochłonne (5-10 min/faktura)\n• Brak wsparcia technicznego\n\nPŁATNE ROZWIĄZANIA:\n• Automatyzacja (30 sek/faktura)\n• Integracja z systemami\n• Wsparcie techniczne\n• Szablony i automatyzacje\n• Raporty i analizy\n\nREKOMENDACJA:\n• <20 faktur/mies: darmowy portal OK\n• 20-100 faktur/mies: rozważ płatne\n• >100 faktur/mies: płatne OBOWIĄZKOWO",
    relatedQuestions: ["ile-kosztuje-wdrozenie", "male-firmy-koszty", "jak-wybrac-dostawce"],
    views: 2345,
    helpfulVotes: { positive: 198, negative: 22 },
    isTrending: false,
    lastUpdated: new Date("2025-01-19"),
    expertVerified: true,
    tags: ["darmowe", "portal", "alternatywy"],
  },
  {
    id: "koszt-wsparcia",
    category: "koszty",
    question: "Ile kosztuje wsparcie techniczne po wdrożeniu?",
    quickAnswer:
      "Wsparcie podstawowe (email/telefon 8-16): 200-800 zł/mies. Wsparcie rozszerzone (24/7, dedykowany opiekun): 1,000-2,500 zł/mies. Pierwsze 12 miesięcy często wliczone w cenę wdrożenia.",
    detailedAnswer:
      "Pakiety wsparcia:\n\nPODSTAWOWY (200-400 zł/mies):\n• Email i telefon (pn-pt 8-16)\n• Czas reakcji: 24h\n• Pomoc w obsłudze systemu\n• Aktualizacje\n\nSTANDARD (500-800 zł/mies):\n• Email, telefon, chat (pn-pt 7-19)\n• Czas reakcji: 4h\n• Zdalne wsparcie\n• Priorytetowe zgłoszenia\n\nPREMIUM (1,000-2,500 zł/mies):\n• 24/7 dostępność\n• Czas reakcji: 1h\n• Dedykowany opiekun\n• Wizyty on-site\n• Proaktywne monitorowanie\n\nWSKAZÓWKA: Pierwsze 12 miesięcy wsparcia często wliczone w cenę wdrożenia!",
    relatedQuestions: ["koszty-miesieczne", "co-wliczone-w-cene", "jak-wybrac-dostawce"],
    views: 876,
    helpfulVotes: { positive: 79, negative: 5 },
    isTrending: false,
    lastUpdated: new Date("2025-01-15"),
    expertVerified: false,
    tags: ["wsparcie", "koszty", "serwis"],
  },
  {
    id: "oszczednosci-ksef",
    category: "koszty",
    question: "Jak KSeF zmniejszy moje koszty fakturowania?",
    quickAnswer:
      "Oszczędności: 60-80% czasu na fakturowanie, 90% mniej błędów, brak kosztów druku/wysyłki (2,000-5,000 zł/rok), niższe koszty księgowości (3,000-8,000 zł/rok), szybsze zwroty VAT.",
    detailedAnswer:
      "Szczegółowa analiza oszczędności:\n\nOSZCZĘDNOŚĆ CZASU:\n• Wystawienie faktury: 5 min → 30 sek (90% szybciej)\n• Archiwizacja: automatyczna (oszczędność 10h/mies)\n• Korekty: 2 min → 30 sek\n• Raporty: automatyczne (oszczędność 5h/mies)\nWartość: 10,000-20,000 zł/rok\n\nOSZCZĘDNOŚĆ KOSZTÓW:\n• Brak druku: 1,000-2,000 zł/rok\n• Brak wysyłki: 1,000-3,000 zł/rok\n• Mniej błędów: 5,000-15,000 zł/rok\n• Niższa księgowość: 3,000-8,000 zł/rok\nRazem: 10,000-28,000 zł/rok\n\nKORZYŚCI DODATKOWE:\n• Szybsze zwroty VAT (lepszy cash flow)\n• Mniej kontroli skarbowych\n• Lepsza organizacja",
    relatedQuestions: ["jak-dlugo-zwrot-inwestycji", "ile-kosztuje-wdrozenie", "korzysci-wczesnego-wdrozenia"],
    views: 1543,
    helpfulVotes: { positive: 142, negative: 9 },
    isTrending: false,
    lastUpdated: new Date("2025-01-22"),
    expertVerified: true,
    tags: ["oszczędności", "korzyści", "ROI"],
  },
  {
    id: "male-firmy-koszty",
    category: "koszty",
    question: "Czy mała firma może sobie pozwolić na wdrożenie KSeF?",
    quickAnswer:
      "TAK! Dla mikrofirm: 8,000-10,000 zł wdrożenie + 300-550 zł/mies. Dostępne dofinansowania (do 85% kosztów), ulgi podatkowe, kredyty preferencyjne. ROI: 12-18 miesięcy.",
    detailedAnswer:
      "Rozwiązania dla małych firm:\n\nKOSZTY:\n• Wdrożenie: 8,000-10,000 zł (jednorazowo)\n• Miesięcznie: 300-550 zł\n• Razem pierwszy rok: ~12,000 zł\n\nDOTACJE:\n• Program Polska Cyfrowa: do 85% kosztów (max 100,000 zł)\n• PARP: do 50,000 zł\n• Ulgi podatkowe: 100% odliczenia\n• Kredyty: 2-3% oprocentowanie\n\nPRZYKŁAD:\n• Koszt: 12,000 zł\n• Dotacja (85%): -10,200 zł\n• Koszt własny: 1,800 zł\n• Oszczędności rok 1: 15,000 zł\n• ZYSK: +13,200 zł\n\nWNIOSEK: Małe firmy ZYSKUJĄ na KSeF!",
    relatedQuestions: ["ile-kosztuje-wdrozenie", "dofinansowanie-ksef", "darmowe-rozwiazania"],
    views: 2876,
    helpfulVotes: { positive: 267, negative: 14 },
    isTrending: true,
    lastUpdated: new Date("2025-01-23"),
    expertVerified: true,
    tags: ["małe-firmy", "koszty", "dofinansowanie"],
  },
  {
    id: "koszt-szkolen",
    category: "koszty",
    question: "Jakie są koszty szkoleń dla pracowników?",
    quickAnswer:
      "Szkolenia podstawowe (2-4h): 1,000-2,000 zł dla grupy do 5 osób. Szkolenia zaawansowane (1-2 dni): 3,000-5,000 zł. Często wliczone w cenę wdrożenia (sprawdź umowę!).",
    detailedAnswer:
      "Rodzaje i koszty szkoleń:\n\nPODSTAWOWE (1,000-1,500 zł):\n• Czas: 2-4 godziny\n• Grupa: do 5 osób\n• Zakres: obsługa systemu, wystawianie faktur\n• Forma: online lub stacjonarne\n• Często WLICZONE w wdrożenie\n\nZAAWANSOWANE (3,000-5,000 zł):\n• Czas: 1-2 dni\n• Grupa: do 10 osób\n• Zakres: integracje, raporty, administracja\n• Forma: stacjonarne + materiały\n\nINDYWIDUALNE (500-1,000 zł/os):\n• Czas: 1-2 godziny\n• Dedykowane dla 1 osoby\n• Zakres: dostosowany do potrzeb\n\nWSKAZÓWKA: Negocjuj szkolenia w pakiecie wdrożeniowym!",
    relatedQuestions: ["co-wliczone-w-cene", "ile-kosztuje-wdrozenie", "szkolenia-pracownikow"],
    views: 654,
    helpfulVotes: { positive: 61, negative: 4 },
    isTrending: false,
    lastUpdated: new Date("2025-01-16"),
    expertVerified: false,
    tags: ["szkolenia", "koszty", "pracownicy"],
  },
  {
    id: "raty-koszty",
    category: "koszty",
    question: "Czy mogę rozłożyć koszty wdrożenia na raty?",
    quickAnswer:
      "TAK! Większość dostawców oferuje raty: 12-36 miesięcy, oprocentowanie 0-5%, bez dodatkowych opłat. Alternatywnie: kredyty preferencyjne BGK (2-3%), leasing operacyjny.",
    detailedAnswer:
      "Opcje finansowania:\n\nRATY OD DOSTAWCY:\n• Okres: 12-36 miesięcy\n• Oprocentowanie: 0-5%\n• Bez dodatkowych opłat\n• Przykład: 12,000 zł → 12x 1,050 zł\n\nKREDYT PREFERENCYJNY:\n• BGK: 2-3% oprocentowanie\n• Okres: do 60 miesięcy\n• Kwota: do 500,000 zł\n• Wymaga biznesplanu\n\nLEASING OPERACYJNY:\n• Okres: 24-60 miesięcy\n• Zalety: koszty uzyskania przychodu\n• Wymaga: 3 miesiące działalności\n\nREKOMENDACJA:\n• Małe firmy: raty od dostawcy (prostsze)\n• Średnie/duże: kredyt BGK (tańsze)",
    relatedQuestions: ["ile-kosztuje-wdrozenie", "dofinansowanie-ksef", "male-firmy-koszty"],
    views: 987,
    helpfulVotes: { positive: 89, negative: 6 },
    isTrending: false,
    lastUpdated: new Date("2025-01-17"),
    expertVerified: false,
    tags: ["raty", "finansowanie", "kredyt"],
  },

  // KATEGORIA 3: Wdrożenie Techniczne
  {
    id: "jak-dlugo-trwa-wdrozenie",
    category: "wdrozenie",
    question: "Jak długo trwa wdrożenie KSeF?",
    quickAnswer:
      "Wdrożenie trwa 2-8 tygodni w zależności od wielkości firmy: mikrofirma (2-3 tygodnie), średnia (4-6 tygodni), duża z integracjami (6-8 tygodni). Szkolenia: 1-2 dni.",
    detailedAnswer:
      "Harmonogram wdrożenia:\n\nTYDZIEŃ 1-2: PRZYGOTOWANIE\n• Analiza potrzeb\n• Wybór pakietu\n• Podpisanie umowy\n• Przygotowanie danych\n\nTYDZIEŃ 2-4: INSTALACJA\n• Konfiguracja systemu\n• Integracje z księgowością\n• Testy połączeń\n• Import danych\n\nTYDZIEŃ 4-6: SZKOLENIA\n• Szkolenie pracowników (1-2 dni)\n• Testy użytkowników\n• Wystawienie testowych faktur\n• Poprawki i optymalizacja\n\nTYDZIEŃ 6-8: START\n• Uruchomienie produkcyjne\n• Monitoring\n• Wsparcie intensywne (pierwsze 2 tygodnie)",
    relatedQuestions: ["ile-kosztuje-wdrozenie", "etapy-wdrożenia", "przygotowanie-do-wdrożenia"],
    views: 2134,
    helpfulVotes: { positive: 198, negative: 11 },
    isTrending: false,
    lastUpdated: new Date("2025-01-21"),
    expertVerified: true,
    tags: ["czas", "wdrożenie", "harmonogram"],
  },
  {
    id: "integracja-z-systemem",
    category: "wdrozenie",
    question: "Jak zintegrować KSeF z moim obecnym systemem księgowym?",
    quickAnswer:
      "Większość systemów (Symfonia, Comarch, Sage, Wapro) ma gotowe integracje. Proces: instalacja wtyczki/modułu (1-2h), konfiguracja (2-4h), testy (1 dzień). Custom integracje: 2-4 tygodnie.",
    detailedAnswer:
      "Proces integracji:\n\nSTANDARDOWE SYSTEMY (1-3 dni):\n• Symfonia, Comarch ERP, Sage, Wapro, InsERT\n• Gotowe wtyczki/moduły\n• Instalacja: 1-2h\n• Konfiguracja: 2-4h\n• Testy: 1 dzień\n• Koszt: wliczony w pakiet\n\nCUSTOM SYSTEMY (2-4 tygodnie):\n• SAP, Oracle, własne rozwiązania\n• Wymaga API integration\n• Analiza: 3-5 dni\n• Development: 1-2 tygodnie\n• Testy: 3-5 dni\n• Koszt: 5,000-15,000 zł\n\nWYMAGANIA:\n• Dostęp do API systemu\n• Dokumentacja techniczna\n• Współpraca z IT",
    relatedQuestions: ["jakie-systemy-obsluguje", "api-ksef", "migracja-danych"],
    views: 1876,
    helpfulVotes: { positive: 167, negative: 9 },
    isTrending: false,
    lastUpdated: new Date("2025-01-19"),
    expertVerified: true,
    tags: ["integracja", "księgowość", "API"],
  },

  // KATEGORIA 4: Prawo & Compliance
  {
    id: "odpowiedzialnosc-prawna",
    category: "prawo",
    question: "Kto ponosi odpowiedzialność prawną za błędy w KSeF?",
    quickAnswer:
      "NIE. KSeF jest obowiązkowy dla wszystkich firm i osób prowadzących działalność gospodarczą w Polsce, bez względu na wielkość czy formę prawną. Nie ma żadnych wyjątków.",
    detailedAnswer:
      "Obowiązek dotyczy:\n\n✓ Wszystkich podatników VAT\n✓ Firm na ryczałcie (od 2026)\n✓ Jednoosobowych działalności gospodarczych\n✓ Korporacji i koncernów\n✓ Organizacji non-profit wystawiających faktury\n\nJedyne zwolnienie: faktury dla konsumentów (B2C) - te mogą pozostać w starej formie, ale KSeF jest zalecany.",
    relatedQuestions: ["kiedy-wdrozyc-ksef", "kary-za-niewdrozenie", "male-firmy-koszty"],
    views: 1432,
    helpfulVotes: { positive: 128, negative: 14 },
    isTrending: false,
    lastUpdated: new Date("2025-01-20"),
    expertVerified: true,
    tags: ["odpowiedzialność", "prawo", "zarząd"],
  },

  // KATEGORIA 5: Integracje & API
  {
    id: "api-ksef",
    category: "integracje",
    question: "Czy KSeF ma API dla programistów?",
    quickAnswer:
      "TAK! KSeF udostępnia REST API z pełną dokumentacją. Możliwość budowy własnych integracji, automatyzacji, custom rozwiązań. Wymaga: certyfikat, token autoryzacyjny, znajomość REST.",
    detailedAnswer:
      "API KSeF - szczegóły:\n\nMOŻLIWOŚCI:\n• Wystawianie faktur programowo\n• Pobieranie faktur\n• Weryfikacja statusu\n• Generowanie raportów\n• Integracja z dowolnym systemem\n\nDOKUMENTACJA:\n• Pełna dokumentacja na gov.pl\n• Przykłady w Python, Java, C#, PHP\n• Sandbox do testów\n• Forum developerskie\n\nWYMAGANIA:\n• Certyfikat kwalifikowany lub profil zaufany\n• Token autoryzacyjny\n• Znajomość REST API\n• HTTPS (bezpieczne połączenie)\n\nZASTOSOWANIA:\n• Custom integracje\n• Automatyzacja procesów\n• Własne dashboardy\n• Integracje z e-commerce",
    relatedQuestions: ["integracja-z-systemem", "custom-integracje", "bezpieczenstwo-api"],
    views: 876,
    helpfulVotes: { positive: 78, negative: 7 },
    isTrending: false,
    lastUpdated: new Date("2025-01-18"),
    expertVerified: true,
    tags: ["API", "integracje", "development"],
  },

  // KATEGORIA 6: Post-wdrożenie
  {
    id: "problemy-po-wdrozeniu",
    category: "post-wdrozenie",
    question: "Jakie problemy mogą wystąpić po wdrożeniu?",
    quickAnswer:
      "Najczęstsze problemy: błędy w numeracji (5%), problemy z integracją (10%), opór pracowników (20%), błędy w danych (15%). Rozwiązanie: wsparcie techniczne, dodatkowe szkolenia, audyt systemu.",
    detailedAnswer:
      "Typowe problemy i rozwiązania:\n\nPROBLEM 1: Błędy w numeracji (5% firm)\n• Przyczyna: nieprawidłowa konfiguracja\n• Rozwiązanie: reset numeracji, wsparcie dostawcy\n• Czas: 1-2 dni\n\nPROBLEM 2: Integracja nie działa (10%)\n• Przyczyna: nieaktualne API, błędna konfiguracja\n• Rozwiązanie: update systemu, rekonfiguracja\n• Czas: 2-5 dni\n\nPROBLEM 3: Opór pracowników (20%)\n• Przyczyna: brak szkoleń, strach przed zmianą\n• Rozwiązanie: dodatkowe szkolenia, wsparcie\n• Czas: 2-4 tygodnie\n\nPROBLEM 4: Błędy w danych (15%)\n• Przyczyna: nieprawidłowe dane wejściowe\n• Rozwiązanie: audyt danych, czyszczenie bazy\n• Czas: 1-2 tygodnie\n\nPREWENCJA:\n• Dokładne testy przed startem\n• Szkolenia dla wszystkich\n• Wsparcie w pierwszych tygodniach",
    relatedQuestions: ["wsparcie-techniczne", "szkolenia-pracownikow", "audyt-ksef"],
    views: 1234,
    helpfulVotes: { positive: 112, negative: 8 },
    isTrending: false,
    lastUpdated: new Date("2025-01-22"),
    expertVerified: true,
    tags: ["problemy", "troubleshooting", "wsparcie"],
  },
]

export const quests: Quest[] = [
  {
    id: "podstawy-ksef",
    title: "KSeF Podstawy",
    icon: "GraduationCap",
    badge: "Beginner",
    description: "Poznaj fundamenty Krajowego Systemu e-Faktur",
    questions: [
      "co-to-jest-ksef",
      "kiedy-wdrozyc-ksef",
      "kto-musi-wdrozyc",
      "kary-za-niewdrozenie",
      "jakie-faktury-ksef",
    ],
    reward: {
      type: "pdf",
      title: "KSeF Readiness Checklist",
      description: "Kompletna lista kontrolna przygotowania do wdrożenia",
      requiresEmail: true,
    },
    xpPerQuestion: 10,
    bonusXP: 50,
  },
  {
    id: "koszty-oszczednosci",
    title: "Koszty & Oszczędności",
    icon: "DollarSign",
    badge: "Finance Expert",
    description: "Zrozum ekonomię wdrożenia i ROI",
    questions: [
      "ile-kosztuje-wdrozenie",
      "ukryte-koszty",
      "koszty-miesieczne",
      "dofinansowanie-ksef",
      "jak-dlugo-zwrot-inwestycji",
      "oszczednosci-ksef",
    ],
    reward: {
      type: "checklist",
      title: "ROI Calculator & Cost Breakdown",
      description: "Interaktywny kalkulator zwrotu z inwestycji",
      requiresEmail: true,
    },
    xpPerQuestion: 10,
    bonusXP: 60,
  },
  {
    id: "prawo-compliance",
    title: "Prawo & Compliance",
    icon: "Scale",
    badge: "Legal Pro",
    description: "Opanuj aspekty prawne i zgodność z przepisami",
    questions: [
      "odpowiedzialnosc-prawna",
      "kary-za-niewdrozenie",
      "kto-musi-wdrozyc",
      "jakie-faktury-ksef",
      "dobrowolne-wdrozenie",
    ],
    reward: {
      type: "voucher",
      title: "Darmowa Konsultacja Prawna (30 min)",
      description: "Bezpłatna konsultacja z ekspertem prawnym KSeF",
      requiresEmail: true,
    },
    xpPerQuestion: 10,
    bonusXP: 50,
  },
]

export const categories = [
  { id: "podstawy", name: "Podstawy KSeF", icon: "Target", count: 10 },
  { id: "koszty", name: "Koszty & ROI", icon: "DollarSign", count: 12 },
  { id: "wdrozenie", name: "Wdrożenie Techniczne", icon: "Settings", count: 12 },
  { id: "prawo", name: "Prawo & Compliance", icon: "Scale", count: 10 },
  { id: "integracje", name: "Integracje & API", icon: "BarChart3", count: 8 },
  { id: "post-wdrozenie", name: "Post-wdrożenie", icon: "Rocket", count: 8 },
]
