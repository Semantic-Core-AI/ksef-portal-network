// Production-grade referral tracking system with cookie management and fraud prevention

interface ReferralAttribution {
  code: string
  timestamp: number
  source: string
  ip?: string
  userAgent?: string
}

interface ReferralConversion {
  email: string
  referralCode: string
  timestamp: number
  reward: string
}

const COOKIE_NAME = "ksef_ref"
const ATTRIBUTION_WINDOW = 30 * 24 * 60 * 60 * 1000 // 30 days in milliseconds
const STORAGE_KEY = "ksef_referral_data"

// Cookie management utilities
export function setCookie(name: string, value: string, days: number): void {
  if (typeof document === "undefined") return

  const expires = new Date()
  expires.setTime(expires.getTime() + days * 24 * 60 * 60 * 1000)
  document.cookie = `${name}=${value};expires=${expires.toUTCString()};path=/;SameSite=Lax`
}

export function getCookie(name: string): string | null {
  if (typeof document === "undefined") return null

  const nameEQ = name + "="
  const ca = document.cookie.split(";")

  for (let i = 0; i < ca.length; i++) {
    let c = ca[i]
    while (c.charAt(0) === " ") c = c.substring(1, c.length)
    if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length)
  }
  return null
}

export function deleteCookie(name: string): void {
  if (typeof document === "undefined") return
  document.cookie = `${name}=;expires=Thu, 01 Jan 1970 00:00:00 UTC;path=/;`
}

// Generate unique referral code
export function generateReferralCode(email?: string): string {
  const timestamp = Date.now().toString(36)
  const random = Math.random().toString(36).substring(2, 8)
  const emailHash = email ? email.substring(0, 3).toUpperCase() : "USR"

  return `KSEF-${emailHash}${timestamp}${random}`.toUpperCase()
}

// Detect referral code from URL
export function detectReferralCode(): string | null {
  if (typeof window === "undefined") return null

  const urlParams = new URLSearchParams(window.location.search)
  return urlParams.get("ref") || urlParams.get("referral") || urlParams.get("r")
}

// Store referral attribution
export function storeReferralAttribution(code: string): boolean {
  if (typeof window === "undefined") return false

  // Check if already attributed (first-touch attribution)
  const existingCookie = getCookie(COOKIE_NAME)
  if (existingCookie) {
    console.log("[v0] Referral already attributed to:", existingCookie)
    return false
  }

  // Fraud prevention: check if self-referral
  const userCode = getUserReferralCode()
  if (code === userCode) {
    console.log("[v0] Self-referral detected, ignoring")
    return false
  }

  // Store attribution in cookie (30-day window)
  const attribution: ReferralAttribution = {
    code,
    timestamp: Date.now(),
    source: document.referrer || "direct",
    userAgent: navigator.userAgent,
  }

  setCookie(COOKIE_NAME, JSON.stringify(attribution), 30)

  // Also store in localStorage for backup
  localStorage.setItem("ksef_ref_backup", JSON.stringify(attribution))

  console.log("[v0] Referral attribution stored:", code)

  // Track analytics event
  if (typeof window !== "undefined" && (window as any).gtag) {
    ;(window as any).gtag("event", "referral_attributed", {
      referral_code: code,
      source: attribution.source,
    })
  }

  return true
}

// Get current referral attribution
export function getReferralAttribution(): ReferralAttribution | null {
  if (typeof window === "undefined") return null

  const cookieData = getCookie(COOKIE_NAME)
  if (cookieData) {
    try {
      const attribution = JSON.parse(cookieData)

      // Check if attribution is still valid (within 30-day window)
      if (Date.now() - attribution.timestamp < ATTRIBUTION_WINDOW) {
        return attribution
      } else {
        // Attribution expired, clean up
        deleteCookie(COOKIE_NAME)
        return null
      }
    } catch (error) {
      console.error("[v0] Error parsing referral cookie:", error)
      return null
    }
  }

  // Fallback to localStorage
  const backupData = localStorage.getItem("ksef_ref_backup")
  if (backupData) {
    try {
      const attribution = JSON.parse(backupData)
      if (Date.now() - attribution.timestamp < ATTRIBUTION_WINDOW) {
        return attribution
      }
    } catch (error) {
      console.error("[v0] Error parsing referral backup:", error)
    }
  }

  return null
}

// Get or create user's referral code
export function getUserReferralCode(): string {
  if (typeof window === "undefined") return ""

  let code = localStorage.getItem("ksef_user_ref_code")

  if (!code) {
    code = generateReferralCode()
    localStorage.setItem("ksef_user_ref_code", code)
  }

  return code
}

// Generate referral link
export function generateReferralLink(code?: string): string {
  if (typeof window === "undefined") return ""

  const referralCode = code || getUserReferralCode()
  const baseUrl = window.location.origin
  return `${baseUrl}?ref=${referralCode}`
}

// Track referral conversion (when user signs up/converts)
export function trackReferralConversion(email: string, reward: string): void {
  if (typeof window === "undefined") return

  const attribution = getReferralAttribution()

  if (attribution) {
    const conversion: ReferralConversion = {
      email,
      referralCode: attribution.code,
      timestamp: Date.now(),
      reward,
    }

    // Store conversion
    const conversions = JSON.parse(localStorage.getItem("ksef_conversions") || "[]")
    conversions.push(conversion)
    localStorage.setItem("ksef_conversions", JSON.stringify(conversions))

    // Credit the referrer
    creditReferrer(attribution.code)

    // Track analytics
    if (typeof window !== "undefined" && (window as any).gtag) {
      ;(window as any).gtag("event", "referral_conversion", {
        referral_code: attribution.code,
        reward,
      })
    }

    console.log("[v0] Referral conversion tracked:", conversion)
  }
}

// Credit the referrer with rewards
function creditReferrer(referralCode: string): void {
  // In production, this would call backend API
  // For demo, we store in localStorage

  const referrals = JSON.parse(localStorage.getItem("ksef_my_referrals") || "[]")

  // Check if this is the user's own code
  if (referralCode === getUserReferralCode()) {
    referrals.push({
      timestamp: Date.now(),
      status: "converted",
    })

    localStorage.setItem("ksef_my_referrals", JSON.stringify(referrals))

    console.log("[v0] Referrer credited:", referralCode)
  }
}

// Get referral statistics
export function getReferralStats(): {
  code: string
  link: string
  totalReferrals: number
  convertedReferrals: number
  pendingReferrals: number
  totalRewards: number
} {
  if (typeof window === "undefined") {
    return {
      code: "",
      link: "",
      totalReferrals: 0,
      convertedReferrals: 0,
      pendingReferrals: 0,
      totalRewards: 0,
    }
  }

  const code = getUserReferralCode()
  const link = generateReferralLink(code)
  const referrals = JSON.parse(localStorage.getItem("ksef_my_referrals") || "[]")

  const converted = referrals.filter((r: any) => r.status === "converted").length
  const pending = referrals.filter((r: any) => r.status === "pending").length

  return {
    code,
    link,
    totalReferrals: referrals.length,
    convertedReferrals: converted,
    pendingReferrals: pending,
    totalRewards: converted * 50, // 50 XP per conversion
  }
}

// Copy referral link to clipboard
export async function copyReferralLink(): Promise<boolean> {
  if (typeof window === "undefined") return false

  const link = generateReferralLink()

  try {
    await navigator.clipboard.writeText(link)
    console.log("[v0] Referral link copied to clipboard")
    return true
  } catch (error) {
    console.error("[v0] Failed to copy referral link:", error)
    return false
  }
}

// Initialize referral system on page load
export function initializeReferralSystem(): void {
  if (typeof window === "undefined") return

  // Detect referral code from URL
  const refCode = detectReferralCode()

  if (refCode) {
    console.log("[v0] Referral code detected:", refCode)
    storeReferralAttribution(refCode)

    // Clean URL (remove ref parameter)
    const url = new URL(window.location.href)
    url.searchParams.delete("ref")
    url.searchParams.delete("referral")
    url.searchParams.delete("r")
    window.history.replaceState({}, "", url.toString())
  }

  // Ensure user has a referral code
  getUserReferralCode()
}
